/* ��Ԫ�������� ���ֿ�
 *
 * ��Ԫ 2016��10��17��15:24:38
*/

#include <fstream>
#include <iomanip>
#include <stdlib.h>
#include <string.h>
#include "wsobk.h"

#if !defined(_MSC_VER)
#define strcpy_s strcpy
#define strcat_s strcat
#endif

const CWSOBK::Zobrist CWSOBK::ZOBRIST;    // ɢ�м�ֵ��
const int CWSOBK::IN_BOARD[256] = {
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0,
    0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0,
    0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0,
    0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0,
    0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0,
    0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0,
    0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0,
    0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0,
    0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0,
    0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0
};

uint32_t CWSOBK::MirrorLock1(void)
{
    int i, sq;
    ZobristStruct zob;

    zob.Key = zob.Lock0 = zob.Lock1 = 0;
    for (i = 0; i < 256; ++i) {
        if (Board[i] != 0) {
            sq = (i & 0xf0) | (14 - (i & 0xf));   // ˮƽ��ת
            zob.Xor(ZOBRIST.Table[Board[i]][sq]);
        }
    }
    if (PlayerColor != PC_RED) {
        zob.Xor(ZOBRIST.Player);
    }
    return zob.Lock1;
}

void CWSOBK::from_fen(const char * fen)
{
    int pcNum[PC_MAX] = { 0, 0 };
    int x = 3, y = 3, i;
    uint16_t sq;
    uint16_t pc;

    this->Empties();
    // ����fen
    for (; *fen != '\0' && *fen != ' ' && y < 16; ++fen) {
        switch (*fen) {
        case 'k':	pc = (pcNum[PC_BK] < 1 ? PC_BK : 0);	break;
        case 'a':	pc = (pcNum[PC_BA] < 2 ? PC_BA : 0);	break;
        case 'b':	pc = (pcNum[PC_BB] < 2 ? PC_BB : 0);	break;
        case 'n':	pc = (pcNum[PC_BN] < 2 ? PC_BN : 0);	break;
        case 'r':	pc = (pcNum[PC_BR] < 2 ? PC_BR : 0);	break;
        case 'c':	pc = (pcNum[PC_BC] < 2 ? PC_BC : 0);	break;
        case 'p':	pc = (pcNum[PC_BP] < 5 ? PC_BP : 0);	break;

        case 'K':	pc = (pcNum[PC_RK] < 1 ? PC_RK : 0);	break;
        case 'A':	pc = (pcNum[PC_RA] < 2 ? PC_RA : 0);	break;
        case 'B':	pc = (pcNum[PC_RB] < 2 ? PC_RB : 0);	break;
        case 'N':	pc = (pcNum[PC_RN] < 2 ? PC_RN : 0);	break;
        case 'R':	pc = (pcNum[PC_RR] < 2 ? PC_RR : 0);	break;
        case 'C':	pc = (pcNum[PC_RC] < 2 ? PC_RC : 0);	break;
        case 'P':	pc = (pcNum[PC_RP] < 5 ? PC_RP : 0);	break;

        case '/':	pc = 0;	++y;	x = 2;	/* ѭ������1�������i-1ͬ */		break;
        default:	pc = 0;	i = *fen - '0';	x += (i > 0 && i < 10 ? i - 1 : 0);	break;
        }
        sq = SEAT_GET(x, y);
        if (pc != 0 && x < 16 && IN_BOARD[sq]) {
            ++pcNum[pc];
            pc += pcNum[pc] - 1;  // ʶ����
            this->Board[sq] = pc;
            this->Zobr.Xor(ZOBRIST.Table[pc][sq]);
        }
        ++x;
    }
    if (*(fen + 1) == 'b') {
        this->ChangeSide();   // �������ӷ�
    }
}

void CWSOBK::gen_cpp(const char * file, const char *out_file)
{
    std::ifstream f(file, std::ios::in | std::ios::binary);
    std::streamoff size;
    unsigned char *buf;
    char outfileh[256];
    char outfile[256];

    if (!f) {
        return;
    }
    f.seekg(0, std::ios::end);
    size = f.tellg();
    if (size % sizeof(BookItem)) {
        f.close();
        return;
    }
    buf = new unsigned char[size];
    f.seekg(0, std::ios::beg);
    f.read((char *)buf, size);
    f.close();
    strcpy_s(outfileh, out_file);
    strcat_s(outfileh, ".h");
    std::ofstream outfh(outfileh, std::ios::out);
    outfh << "#ifndef WSOBK_DAT_H" << std::endl;
    outfh << "#define WSOBK_DAT_H" << std::endl;
    outfh << "extern const unsigned char wsobk_tab[];" << std::endl;
    outfh << "extern const unsigned long wsobk_bytes;" << std::endl;
    outfh << "#endif" << std::endl;
    outfh.close();

    strcpy_s(outfile, out_file);
    strcat_s(outfile, ".cpp");
    std::ofstream outf(outfile, std::ios::out);
    outf << "#include \"" << outfileh << "\"" << std::endl;
    outf << "const unsigned char wsobk_tab[] = {\n\t";
    for (uint32_t i = 0; i < size; ++i) {
        outf << "0x" << std::hex << std::setw(2) << std::setfill('0') << (int)buf[i] << ",";
        if (i % 20 == 19) outf << "\n\t";
    }
    outf << "\n};\n";
    outf << "const unsigned long wsobk_bytes = sizeof(wsobk_tab);" << std::endl;
    outf.close();
    delete[]buf;
}

// ���뿪�ֿ��ļ�
int32_t CWSOBK::load(const char *file) {
    std::ifstream f(file, std::ios::in | std::ios::binary);
    std::streamoff size;

    if (!f) {
        return 0;
    }
    f.seekg(0, std::ios::end);
    size = f.tellg();
    if (size % sizeof(BookItem)) {
        f.close();
        return 0;
    }
    BookTable = new BookItem[size / sizeof(BookItem)];
    f.seekg(0, std::ios::beg);
    f.read((char*)BookTable, size);
    f.close();
    BookSize = (uint32_t)(size / sizeof(BookItem));
    return BookSize;
}

int32_t CWSOBK::load(const unsigned char * dat, unsigned long len)
{
    if (len % sizeof(BookItem)) {
        return 0;
    }
    BookSize = (int32_t)(len / sizeof(BookItem));
    BookTable = new BookItem[BookSize];
    memcpy(BookTable, dat, len);
    return BookSize;
}

// ���ֲ��ҿ��ֿ�
CWSOBK::BookItem *CWSOBK::BinaryChop(uint32_t lock) {
    uint32_t beg = 0, end = BookSize - 1;
    uint32_t i = 0;

    while (beg <= end) {
        i = beg + (end - beg) / 2;     // (beg + end) / 2 �������

        if (BookTable[i].Lock == lock) {
            break;
        }
        else if (BookTable[i].Lock > lock) {
            if (i == 0) {
                return (BookItem*)0;  // �Ѿ��ҵ����ֿ⿪ͷ����ô���ܼ����ˣ�i���޷��ŵ�
            }
            end = i - 1;
        }
        else {
            if (i >= BookSize) {       // �Ѿ��ҵ����ֿ��β����ô���ܼ�����
                return (BookItem*)0;
            }
            beg = i + 1;
        }
    }
    if (beg > end) {
        return (BookItem*)0;
    }
    while ((i > 0) && (BookTable[i - 1].Lock == lock)) {
        --i;
    }
    return BookTable + i;
}

// ���ֿ��߷�����
void CWSOBK::BookSort(uint16_t *mvs, int *vls, int num) {
    int i, j, v;
    uint16_t m;

    for (i = 0; i < num - 1; ++i) {
        for (j = i + 1; j < num; ++j) {
            if (vls[j] > vls[i]) {
                v = vls[j];
                m = mvs[j];
                vls[j] = vls[i];
                mvs[j] = mvs[i];
                vls[i] = v;
                mvs[i] = m;
            }
        }
    }
}

// �������ֿ�
uint16_t CWSOBK::search(const char *fen) {
    int  vl, vls[MAX_MOVE_NUM];
    uint16_t mv, mvs[MAX_MOVE_NUM];
    BookItem *pBook, *pEnd;
    uint32_t n, lock;
    uint16_t src, dst;
    int mirror;

    if (!this->BookSize) {
        return 0;
    }

    from_fen(fen);
    mirror = 0;
    lock = Zobr.Lock1;
    pBook = BinaryChop(lock);
    if (pBook == 0) {
        mirror = 1;
        lock = MirrorLock1();
        pBook = BinaryChop(lock);
    }
    if (pBook == 0) {
        return 0;
    }
    pEnd = this->BookTable + this->BookSize;
    vl = 0;
    for (n = 0; (n < MAX_MOVE_NUM) && (pBook < pEnd); ++pBook) {
        if (pBook->Lock != lock) {
            break;
        }
        mv = pBook->Mv;
        if (mirror) {
            src = (MOVE_SRC(mv) & 0xf0) | (14 - (MOVE_SRC(mv) & 0xf));
            dst = (MOVE_DST(mv) & 0xf0) | (14 - (MOVE_DST(mv) & 0xf));
            mv = MOVE_GET(src, dst);
        }

        vl += pBook->vl;
        vls[n] = pBook->vl;
        mvs[n] = mv;
        ++n;
    }
    if (vl <= 0) {
        return 0;
    }

    BookSort(mvs, vls, n);
    return mvs[0];
}
