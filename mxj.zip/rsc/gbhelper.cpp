#include <cassert>
#include <iomanip>
#include <sstream>
#include <string>
#include <map>

#include "movegen.h"
#include "gbhelper.h"
#include "position.h"

using namespace std;


static const char* gb_level = "ƽ";
static const char* gb_front = "ǰ";
static const char* gb_mid = "��";
static const char* gb_rear = "��";

static const char* gb_da_zero = "��";
static const char* gb_da_one = "һ";
static const char* gb_da_two = "��";
static const char* gb_da_three = "��";
static const char* gb_da_four = "��";
static const char* gb_da_five = "��";
static const char* gb_da_six = "��";
static const char* gb_da_seven = "��";
static const char* gb_da_eight = "��";
static const char* gb_da_nine = "��";

static const char* gb_zero = "0";
static const char* gb_one = "��";
static const char* gb_two = "��";
static const char* gb_three = "��";
static const char* gb_four = "��";
static const char* gb_five = "��";
static const char* gb_six = "��";
static const char* gb_seven = "��";
static const char* gb_eight = "��";
static const char* gb_nine = "��";


const static  char* gb_number[][10] = { { gb_da_zero, gb_da_one, gb_da_two, gb_da_three, gb_da_four,
gb_da_five, gb_da_six, gb_da_seven, gb_da_eight, gb_da_nine },
gb_zero, gb_one, gb_two, gb_three, gb_four, gb_five,
gb_six, gb_seven, gb_eight, gb_nine };

const static  char* gb_file_no[][9] = { { gb_da_nine, gb_da_eight, gb_da_seven, gb_da_six,
gb_da_five, gb_da_four, gb_da_three, gb_da_two, gb_da_one },
gb_one, gb_two, gb_three, gb_four, gb_five,
gb_six, gb_seven, gb_eight, gb_nine };

// map��ʼ��
const map<int, string>::value_type pc_gb_value[14] =
{
	map<int, string>::value_type(W_PAWN, "��"),
	map<int, string>::value_type(B_PAWN, "��"),
	map<int, string>::value_type(W_ADVISOR, "��"),
	map<int, string>::value_type(B_ADVISOR, "ʿ"),
	map<int, string>::value_type(W_BISHOP, "��"),
	map<int, string>::value_type(B_BISHOP, "��"),
	map<int, string>::value_type(W_KNIGHT, "��"),
	map<int, string>::value_type(B_KNIGHT, "��"),
	map<int, string>::value_type(W_CANNON, "��"),
	map<int, string>::value_type(B_CANNON, "��"),
	map<int, string>::value_type(W_ROOK, "��"),
	map<int, string>::value_type(B_ROOK, "��"),
	map<int, string>::value_type(W_KING, "˧"),
	map<int, string>::value_type(B_KING, "��")

};
const static map<int, string> mapPcGb(pc_gb_value, pc_gb_value + 14);

const map<string, int>::value_type gb_pt_value[11] =
{
	map<string, int>::value_type("��", PAWN),
	map<string, int>::value_type("��", PAWN),
	map<string, int>::value_type("��", ADVISOR),
	map<string, int>::value_type("ʿ", ADVISOR),
	map<string, int>::value_type("��", BISHOP),
	map<string, int>::value_type("��", BISHOP),
	map<string, int>::value_type("��", KNIGHT),
	map<string, int>::value_type("��", CANNON),
	map<string, int>::value_type("��", ROOK),
	map<string, int>::value_type("˧", KING),
	map<string, int>::value_type("��", KING)

};

const static map<string, int> mapGbPt(gb_pt_value, gb_pt_value + 11);

const map<int, string>::value_type pt_c25_value[14] =
{
	map<int, string>::value_type(W_PAWN, "P"),
	map<int, string>::value_type(B_PAWN, "P"),
	map<int, string>::value_type(W_ADVISOR, "A"),
	map<int, string>::value_type(B_ADVISOR, "A"),
	map<int, string>::value_type(W_BISHOP, "B"),
	map<int, string>::value_type(B_BISHOP, "B"),
	map<int, string>::value_type(W_KNIGHT, "N"),
	map<int, string>::value_type(B_KNIGHT, "N"),
	map<int, string>::value_type(W_CANNON, "C"),
	map<int, string>::value_type(B_CANNON, "C"),
	map<int, string>::value_type(W_ROOK, "R"),
	map<int, string>::value_type(B_ROOK, "R"),
	map<int, string>::value_type(W_KING, "K"),
	map<int, string>::value_type(B_KING, "K")

};

const static map<int, string> mapPtC25(pt_c25_value, pt_c25_value + 14);


const map<string, int>::value_type white_gb_file_value[9] =
{
	map<string, int>::value_type("һ", FILE_I),
	map<string, int>::value_type("��", FILE_H),
	map<string, int>::value_type("��", FILE_G),
	map<string, int>::value_type("��", FILE_F),
	map<string, int>::value_type("��", FILE_E),
	map<string, int>::value_type("��", FILE_D),
	map<string, int>::value_type("��", FILE_C),
	map<string, int>::value_type("��", FILE_B),
	map<string, int>::value_type("��", FILE_A),

};

const static map<string, int> mapWhiteGbFile(white_gb_file_value, white_gb_file_value + 9);


const map<string, int>::value_type black_gb_file_value[9] =
{
	map<string, int>::value_type("��", FILE_I),
	map<string, int>::value_type("��", FILE_H),
	map<string, int>::value_type("��", FILE_G),
	map<string, int>::value_type("��", FILE_F),
	map<string, int>::value_type("��", FILE_E),
	map<string, int>::value_type("��", FILE_D),
	map<string, int>::value_type("��", FILE_C),
	map<string, int>::value_type("��", FILE_B),
	map<string, int>::value_type("��", FILE_A),

};

const static map<string, int> mapBlackGbFile(black_gb_file_value, black_gb_file_value + 9);

const static map<string, int> mapGbFile[2] = { mapWhiteGbFile, mapBlackGbFile };


const map<string, int>::value_type white_gb_num_value[9] =
{
	map<string, int>::value_type("һ", 1),
	map<string, int>::value_type("��", 2),
	map<string, int>::value_type("��", 3),
	map<string, int>::value_type("��", 4),
	map<string, int>::value_type("��", 5),
	map<string, int>::value_type("��", 6),
	map<string, int>::value_type("��", 7),
	map<string, int>::value_type("��", 8),
	map<string, int>::value_type("��", 9),

};

const static map<string, int> mapWhiteGbNum(white_gb_num_value, white_gb_num_value + 9);


const map<string, int>::value_type black_gb_num_value[9] =
{
	map<string, int>::value_type("��", 9),
	map<string, int>::value_type("��", 8),
	map<string, int>::value_type("��", 7),
	map<string, int>::value_type("��", 6),
	map<string, int>::value_type("��", 5),
	map<string, int>::value_type("��", 4),
	map<string, int>::value_type("��", 3),
	map<string, int>::value_type("��", 2),
	map<string, int>::value_type("��", 1),

};

const static map<string, int> mapBlackGbNum(black_gb_num_value, black_gb_num_value + 9);

const static map<string, int> mapGbNum[2] = { mapWhiteGbNum, mapBlackGbNum };

