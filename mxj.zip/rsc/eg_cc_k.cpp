#include "endgame.h"


//�ڷ�û��ʿ���۷� 
//�ڷ����û��2��ʿ���۷�
//�ڷ���2�����Ϲ��ӱ���������ӷǵ��ߵ�����Ҳ�û�б����۷�
//�ڷ�����¶�����۷�
//�ڷ������2��ʿ��û�����ʿ���۷�
template<EndgameType E/*, typename T = eg_type<E>*/>
template<Color c>
inline void Endgame<E>::cc_k_total(const Position& pos, Score& score) const {
	Value v = VALUE_ZERO;
	const Color Them = c == WHITE ? BLACK : WHITE;
	
	int ad = pos.count(c, ADVISOR);
	if (ad == 0) {
		v += -KNIGHT_END_30P;
	}
	else if (ad == 1) {
		v += -BISHOP_END_30P;
	}
	else {
		if (!pos.is_advisor_cavel(c)) {
			v += -BISHOP_END_10P;
		}
	}
	if (pos.pawn_validcount<c>() >= 2
		&& (equal_z(pos.pieces_pawn_crnb<c>() & FlankBoardBC[LEFT]) || equal_z(pos.pieces_pawn_crnb<c>() & FlankBoardBC[RIGHT]))) {
		v += -PAWN_END_10P;
	}
	if (!pos.is_king_clear<c, 0>()) {
		v += -PAWN_END_10P;
	}

	update_score(score, c,  v);
}

template<>
Value Endgame<KCCK>::operator()(const Position& pos, Score& score) const {
	strongSide == WHITE ? cc_k_total<WHITE>(pos, score) : cc_k_total<BLACK>(pos, score);


	FUN_IMPL_DIFF_PIECES_ALL(kcc_k)
}

template<EndgameType E/*, typename T = eg_type<E>*/>
template<Color strong> inline Value Endgame<E>::kcc_k_0p_0p(const Position& pos, Score& score) const {
	I_AM_WEAK

	auto ba = pos.ba_number<weak>();
	switch (ba)
	{
	case BA_ZERO:
	case BA_AD:
	case BA_DA:
	case BA_BS:
	case BA_BA:
	case BA_BDA:
		goto almostWin;
	case BA_DB:
	case BA_DBA:
	case BA_DBDA:
	default:
		if (pos.count(strong, BISHOP) == 2 || pos.count(strong, ADVISOR) > 0)
			goto almostWin;
		break;
	}


	return 	update_score_limit(score, -KNIGHT_END_140P);

almostWin:
	return VALUE_NONE;


}

template<EndgameType E/*, typename T = eg_type<E>*/>
template<Color strong> inline Value Endgame<E>::kcc_k_1p_0p(const Position& pos, Score& score) const {
	return VALUE_NONE;
}

template<EndgameType E/*, typename T = eg_type<E>*/>
template<Color strong> inline Value Endgame<E>::kcc_k_2p_0p(const Position& pos, Score& score) const {
	return VALUE_NONE;
}


template<EndgameType E/*, typename T = eg_type<E>*/>
template<Color strong> inline Value Endgame<E>::kcc_k_0p_1p(const Position& pos, Score& score) const {
	return kcc_k_0p_0p<strong>(pos, score);
}

template<EndgameType E/*, typename T = eg_type<E>*/>
template<Color strong> inline Value Endgame<E>::kcc_k_1p_1p(const Position& pos, Score& score) const {
	return kcc_k_1p_0p<strong>(pos, score);
}

template<EndgameType E/*, typename T = eg_type<E>*/>
template<Color strong> inline Value Endgame<E>::kcc_k_2p_1p(const Position& pos, Score& score) const {
	return kcc_k_2p_0p<strong>(pos, score);
}


template<EndgameType E/*, typename T = eg_type<E>*/>
template<Color strong> inline Value Endgame<E>::kcc_k_0p_2p(const Position& pos, Score& score) const {
	I_AM_WEAK
	if (pos.is_pawns_partner_midhigh<weak>()) {
		int nb = pos.pawn_nobottomcount<weak>();
		//������������ ˫��������������       ����ʿ��ȫ������
		if (nb == 2) {
			if (pos.full_ba(weak) || (pos.zero_ba(strong) && pos.zero_ba(weak)))
				return value_draw_zoom<2>(pos, score);
		}
		return 	update_score(pos, score, strong, -BISHOP_END_30P * nb);
	}

	return kcc_k_0p_1p<strong>(pos, score);
}

template<EndgameType E/*, typename T = eg_type<E>*/>
template<Color strong> inline Value Endgame<E>::kcc_k_1p_2p(const Position& pos, Score& score) const {
	I_AM_WEAK
	if (pos.is_pawns_partner_midhigh<weak>()) {
		int nb = pos.pawn_nobottomcount<weak>();
		return 	update_score(pos, score, strong, -BISHOP_END_20P * nb);
	}

	return kcc_k_1p_1p<strong>(pos, score);
}

template<EndgameType E/*, typename T = eg_type<E>*/>
template<Color strong> inline Value Endgame<E>::kcc_k_2p_2p(const Position& pos, Score& score) const {
	return VALUE_NONE;
}

