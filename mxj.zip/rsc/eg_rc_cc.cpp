#include "endgame.h"


template<EndgameType E/*, typename T = eg_type<E>*/>
template<Color c>
inline void Endgame<E>::rc_cc_total(const Position& pos, Score& score) const {
	Value v = VALUE_ZERO;
	const Color Them = c == WHITE ? BLACK : WHITE;

	//ǿ��������¶�����ӷ�
	if(pos.is_king_mid_clear<c>())
		v += BISHOP_END_40P;

	//���������ڵף��۷�
	if (!pos.is_king_bottom(Them))
		v += BISHOP_END_40P;

	update_score(score, c, v);

	ba_adjust_strong<c>(pos, score, VALUE_BA_ADJUST_MAX_UL);

}

template<>
Value Endgame<KRCKCC>::operator()(const Position& pos, Score& score) const {
	strongSide == WHITE ? rc_cc_total<WHITE>(pos, score) : rc_cc_total<BLACK>(pos, score);
	FUN_IMPL_DIFF_PIECES_ALL(krc_kcc)
}

template<EndgameType E/*, typename T = eg_type<E>*/>
template<Color strong> inline Value Endgame<E>::krc_kcc_0p_0p(const Position& pos, Score& score) const {
	I_AM_WEAK

	if (pos.pawn_bottomcount<strong>() > 0)
		return VALUE_NONE;

	//�����ڳ�������AB�У��������ڲ������ʿ�󣬳���ʤ��
	BitboardC bc = pos.pieces(strong, CANNON) & BottomBC & HomeSideBC[weak] & AreaSide2File;
	if (not_z(bc)) {
		Square csq = lsb(bc);
		assert(csq != SQ_NONE);
		Flank fl = square_flank(csq);
		assert(fl != MIDDLE);
		if (not_z(pos.pieces(weak, BISHOP) & BottomBC & FlankBoardBC[fl]) && not_z(pos.pieces(weak, ADVISOR) & BottomBC & FlankBoardBC[fl]))
			return VALUE_NONE;
	}
	return value_draw_zoom<4>(pos, score);


	////����ȫʿ�����ڵ��ߣ� ����û���ϱ���
	////����˫�����¶�·or����·����
	//if (pos.full_ba(weak) && pos.pawn_bottomcount<strong>() == 0 && pos.is_king_bottom(weak)){
	//	const Square* pl = pos.squares(weak, CANNON);
	//	Square csq1 = *pl++;
	//	assert(csq1 != SQ_NONE);
	//	Square csq2 = *pl;
	//	assert(csq2 != SQ_NONE);

	//	if (rank_of(csq1) == relative_rank<weak>(RANK_1) || rank_of(csq1) == relative_rank<weak>(RANK_2)) {
	//		int cn = popcount(pos.btw_bc(csq1, csq2));
	//		if (cn == 1)
	//			return value_draw_zoom<4>(pos, score);
	//	}
	//}
	//return VALUE_NONE;
}

template<EndgameType E/*, typename T = eg_type<E>*/>
template<Color strong> inline Value Endgame<E>::krc_kcc_1p_0p(const Position& pos, Score& score) const {
	return 	VALUE_NONE;
}

template<EndgameType E/*, typename T = eg_type<E>*/>
template<Color strong> inline Value Endgame<E>::krc_kcc_2p_0p(const Position& pos, Score& score) const {
	return 	VALUE_NONE;
}

template<EndgameType E/*, typename T = eg_type<E>*/>
template<Color strong> inline Value Endgame<E>::krc_kcc_0p_1p(const Position& pos, Score& score) const {
	return 	VALUE_NONE;
}

template<EndgameType E/*, typename T = eg_type<E>*/>
template<Color strong> inline Value Endgame<E>::krc_kcc_1p_1p(const Position& pos, Score& score) const {
	return 	VALUE_NONE;
}

template<EndgameType E/*, typename T = eg_type<E>*/>
template<Color strong> inline Value Endgame<E>::krc_kcc_2p_1p(const Position& pos, Score& score) const {
	return 	VALUE_NONE;
}

template<EndgameType E/*, typename T = eg_type<E>*/>
template<Color strong> inline Value Endgame<E>::krc_kcc_0p_2p(const Position& pos, Score& score) const {
	return 	VALUE_NONE;
}

template<EndgameType E/*, typename T = eg_type<E>*/>
template<Color strong> inline Value Endgame<E>::krc_kcc_1p_2p(const Position& pos, Score& score) const {
	return 	VALUE_NONE;
}

template<EndgameType E/*, typename T = eg_type<E>*/>
template<Color strong> inline Value Endgame<E>::krc_kcc_2p_2p(const Position& pos, Score& score) const {
	return 	VALUE_NONE;
}
