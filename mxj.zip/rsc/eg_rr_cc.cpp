#include "endgame.h"


template<EndgameType E/*, typename T = eg_type<E>*/>
template<Color c>
inline void Endgame<E>::rr_cc_total(const Position& pos, Score& score) const {
	Value v = VALUE_ZERO;
	const Color Them = c == WHITE ? BLACK : WHITE;

	//�����ڵף��۷�
	if (!pos.is_king_bottom(Them))
		v = BISHOP_END_110P;

	update_score(score, c, v);

	ba_adjust_strong<c>(pos, score, VALUE_BA_ADJUST_MAX_UL);

}

template<>
Value Endgame<KRRKCC>::operator()(const Position& pos, Score& score) const {
	strongSide == WHITE ? rr_cc_total<WHITE>(pos, score) : rr_cc_total<BLACK>(pos, score);

	FUN_IMPL_DIFF_PIECES_ALL(krr_kcc)
}

template<EndgameType E/*, typename T = eg_type<E>*/>
template<Color strong> inline Value Endgame<E>::krr_kcc_0p_0p(const Position& pos, Score& score) const {
	I_AM_WEAK
	//�������ڵ���
	if (pos.full_ba(weak) && pos.pawn_bottomcount<strong>() == 0 && pos.is_king_bottom(weak)) {
		//˫��Ӧ���¶�·����·����
		const Square* pl = pos.squares(weak, CANNON);
		Square csq1 = *pl++;
		assert(csq1 != SQ_NONE);
		Square csq2 = *pl;
		assert(csq2 != SQ_NONE);

		BitboardC bc = pos.btw_bc(csq1, csq2);
		if (popcount(bc) == 1 && (rank_of(csq1) == relative_rank<weak>(RANK_1) || rank_of(csq1) == relative_rank<weak>(RANK_2)))
			return 	update_score_limit(score,  -KNIGHT_END_40P);
	}
	return VALUE_NONE;
	

}
//����ʤ˫�ڵ�ȱ��		���߱�ʤ˫��˫��
template<EndgameType E/*, typename T = eg_type<E>*/>
template<Color strong> inline Value Endgame<E>::krr_kcc_1p_0p(const Position& pos, Score& score) const {
	return VALUE_NONE;

}

template<EndgameType E/*, typename T = eg_type<E>*/>
template<Color strong> inline Value Endgame<E>::krr_kcc_2p_0p(const Position& pos, Score& score) const {
	return VALUE_NONE;
}

template<EndgameType E/*, typename T = eg_type<E>*/>
template<Color strong> inline Value Endgame<E>::krr_kcc_0p_1p(const Position& pos, Score& score) const {
	return krr_kcc_0p_0p<strong>(pos, score);
}

template<EndgameType E/*, typename T = eg_type<E>*/>
template<Color strong> inline Value Endgame<E>::krr_kcc_1p_1p(const Position& pos, Score& score) const {
	return VALUE_NONE;
}

template<EndgameType E/*, typename T = eg_type<E>*/>
template<Color strong> inline Value Endgame<E>::krr_kcc_2p_1p(const Position& pos, Score& score) const {
	return VALUE_NONE;
}


template<EndgameType E/*, typename T = eg_type<E>*/>
template<Color strong> inline Value Endgame<E>::krr_kcc_0p_2p(const Position& pos, Score& score) const {
	I_AM_WEAK
	
	if (pos.is_pawns_partner_midhigh<weak>()) {
		if(pos.count(weak, ADVISOR) == 2 && pos.is_king_bottom(weak) && pos.pawn_bottomcount<strong>() == 0)
			return 	update_score_limit(score,  -KNIGHT_END_40P);
	}

	return krr_kcc_0p_0p<strong>(pos, score);


}

template<EndgameType E/*, typename T = eg_type<E>*/>
template<Color strong> inline Value Endgame<E>::krr_kcc_1p_2p(const Position& pos, Score& score) const {
	return VALUE_NONE;
}

template<EndgameType E/*, typename T = eg_type<E>*/>
template<Color strong> inline Value Endgame<E>::krr_kcc_2p_2p(const Position& pos, Score& score) const {
	return VALUE_NONE;
}


