/*
Stockfish, a UCI chess playing engine derived from Glaurung 2.1
Copyright (C) 2004-2008 Tord Romstad (Glaurung author)
Copyright (C) 2008-2015 Marco Costalba, Joona Kiiski, Tord Romstad

Stockfish is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.


Stockfish is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#ifndef BITBOARD_H_INCLUDED
#define BITBOARD_H_INCLUDED

#include <string>

#include "types.h"

namespace Bitbases {

	void init();
	bool probe(Square wksq, Square wpsq, Square bksq, Color Us);

}

namespace Bitboards {

	void init();
	const std::string pretty(Bitboard b);

	void print(Bitboard b);
	void print_r(Bitboard b);
	void print(Bitboard b, Color c);

}

//const Bitboard DarkSquares = 0xAA55AA55AA55AA55ULL;

const Bitboard FileABB = 0x01008040201ULL;
const Bitboard FileBBB = FileABB << 1;
const Bitboard FileCBB = FileABB << 2;
const Bitboard FileDBB = FileABB << 3;
const Bitboard FileEBB = FileABB << 4;
const Bitboard FileFBB = FileABB << 5;
const Bitboard FileGBB = FileABB << 6;
const Bitboard FileHBB = FileABB << 7;
const Bitboard FileIBB = FileABB << 8;

const Bitboard Rank1BB = 0x01FF;
const Bitboard Rank2BB = Rank1BB << (9 * 1);
const Bitboard Rank3BB = Rank1BB << (9 * 2);
const Bitboard Rank4BB = Rank1BB << (9 * 3);
const Bitboard Rank5BB = Rank1BB << (9 * 4);
//const Bitboard Rank6BB = Rank1BB << (9 * 5);
//const Bitboard Rank7BB = Rank1BB << (9 * 6);
//const Bitboard Rank8BB = Rank1BB << (9 * 7);

const Bitboard LegalAllOneBB = 0x1FFFFFFFFFFFULL;// 35184372088831
const Bitboard IllegalAllOneBB = 0xFFFFE00000000000ULL;// -35184372088832

const Bitboard FortBB = 14708792;	//�Ź�λ����
const Bitboard DualAdvisorBB = 40;	//˫ʿ��ԭλ λ����
const Bitboard LeftAdvisorUpKingBB = 8240;	//��ʿ֧�� ��������ʿ��ԭλ
const Bitboard AdvisorCavelBB = 10485760;	//2�����ʿλ��
const Bitboard RightAdvisorUpKingBB = 8216;	//��ʿ֧�� ��������ʿ��ԭλ




extern Bitboard SquareBB[SQUARE_NB];
extern Bitboard FileBB[FILE_NB];
extern Bitboard RankBB[RANK_NB];
extern Bitboard AdjacentFilesBB[FILE_NB];
extern Bitboard InFrontBB[COLOR_NB][RANK_NB];

inline Bitboard operator&(Bitboard b, Square s) {
	assert(is_ok(s));
	return b & SquareBB[s];
}

inline Bitboard operator|(Bitboard b, Square s) {
	assert(is_ok(s));
	return b | SquareBB[s];
}


inline Bitboard operator^(Bitboard b, Square s) {
	assert(is_ok(s));
	return b ^ SquareBB[s];
}

inline Bitboard& operator|=(Bitboard& b, Square s) {
	assert(is_ok(s));
	return b |= SquareBB[s];
}

inline Bitboard& operator^=(Bitboard& b, Square s) {
	assert(is_ok(s));
	return b ^= SquareBB[s];
}

inline bool more_than_one(Bitboard b) {
	return b & (b - 1);
}


/// rank_bb() and file_bb() return a bitboard representing all the squares on
/// the given file or rank.

inline Bitboard rank_bb(Rank r) {
	assert(is_ok(r));
	return RankBB[r];
}

inline Bitboard rank_bb(Square s) {
	assert(is_ok(s));
	return RankBB[rank_of(s)];
}

inline Bitboard file_bb(File f) {
	assert(is_ok(f));
	return FileBB[f];
}

inline Bitboard file_bb(Square s) {
	assert(is_ok(s));
	return FileBB[file_of(s)];
}


/// shift() moves a bitboard one step along direction Delta. Mainly for pawns

template<Square Delta>
inline Bitboard shift(Bitboard b) {
	return  Delta == NORTH ? b << 9 : Delta == SOUTH ? b >> 9
		: Delta == NORTH_EAST ? (b & ~FileIBB) << 10 : Delta == SOUTH_EAST ? (b & ~FileIBB) >> 8
		: Delta == NORTH_WEST ? (b & ~FileABB) << 8 : Delta == SOUTH_WEST ? (b & ~FileABB) >> 10
		: Delta == EAST ? (b & ~FileIBB) << 1 : Delta == WEST ? (b & ~FileABB) >> 1
		: 0;
}


/// adjacent_files_bb() returns a bitboard representing all the squares on the
/// adjacent files of the given one.

inline Bitboard adjacent_files_bb(File f) {
	assert(is_ok(f));
	return AdjacentFilesBB[f];
}


/// between_bb() returns a bitboard representing all the squares between the two
/// given ones. For instance, between_bb(SQ_C3, SQ_F6) returns a bitboard with
/// the bits for square d5 and e6 set. If s1 and s2 are not on the same rank, file
/// or diagonal, 0 is returned.

//inline Bitboard between_bb(Square s1, Square s2) {
//  return BetweenBB[s1][s2];
//}


/// in_front_bb() returns a bitboard representing all the squares on all the ranks
/// in front of the given one, from the point of view of the given color. For
/// instance, in_front_bb(BLACK, RANK_2) will return the squares on ranks 1 and 2.

inline Bitboard in_front_bb(Color c, Rank r) {
	assert(is_ok(c) && is_ok(r));
	return InFrontBB[c][r];
}



/// popcount() counts the number of non-zero bits in a bitboard
inline int popcount(Bitboard b) {
#ifndef USE_POPCNT
	extern uint8_t PopCnt16[1 << 16];
	union { Bitboard bb; uint16_t u[4]; } v = { b };
	return PopCnt16[v.u[0]] + PopCnt16[v.u[1]] + PopCnt16[v.u[2]] + PopCnt16[v.u[3]];
#elif defined(_MSC_VER) || defined(__INTEL_COMPILER)
	return (int)_mm_popcnt_u64(b);		//CPUID Flags: POPCNT
										//#elif defined(_MSC_VER)
										//	return (int)__popcnt64(b);
#else // Assumed gcc or compatible compiler
	return __builtin_popcountll(b);
#endif
}

/// lsb() and msb() return the least/most significant bit in a non-zero bitboard

#if defined(__GNUC__)

inline Square lsb(Bitboard b) {
	assert(b);
	return Square(__builtin_ctzll(b));
}
inline Square msb(Bitboard b) {
	assert(b);
	return Square(63 ^ __builtin_clzll(b));
}

#elif defined(_WIN64) && defined(_MSC_VER)

inline Square lsb(Bitboard b) {
	assert(b);
	unsigned long idx;
	_BitScanForward64(&idx, b);
	return (Square)idx;
}

inline Square msb(Bitboard b) {
	assert(b);
	unsigned long idx;
	_BitScanReverse64(&idx, b);
	return (Square)idx;
}

#else

#define NO_BSF // Fallback on software implementation for other cases

Square lsb(Bitboard b);
Square msb(Bitboard b);

#endif


/// pop_lsb() finds and clears the least significant bit in a non-zero bitboard

inline Square pop_lsb(Bitboard* b) {
	const Square s = lsb(*b);
	*b &= *b - 1;
	return s;
}


/// frontmost_sq() and backmost_sq() return the square corresponding to the
/// most/least advanced bit relative to the given color.

inline Square frontmost_sq(Color c, Bitboard b) { return c == WHITE ? msb(b) : lsb(b); }
inline Square  backmost_sq(Color c, Bitboard b) { return c == WHITE ? lsb(b) : msb(b); }


#endif // #ifndef BITBOARD_H_INCLUDED