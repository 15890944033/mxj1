#include "endgame.h"

template<>
Value Endgame<KRRKRR>::operator()(const Position& pos, Score& score) const {
	//if (pos.full_ba(WHITE) && pos.full_ba(BLACK)) {
	//	if (abs(pos.pawn_validcount<WHITE>() - pos.pawn_validcount<BLACK>()) <= 1) {
	//		return value_draw_zoom<2>(score);
	//	}
	//}
	FUN_IMPL_SAME_PIECES_ALL(krr_krr)
}

template<EndgameType E/*, typename T = eg_type<E>*/>
template<Color strong> inline Value Endgame<E>::krr_krr_0p_0p(const Position& pos, Score& score) const {
	I_AM_WEAK

	if (pos.count(strong, ADVISOR) == 2 && pos.count(weak, ADVISOR) == 2
		&& pos.is_king_bottom(strong) && pos.is_king_bottom(weak))
		return value_draw_zoom<2>(pos, score);

	return VALUE_NONE;
}

template<EndgameType E/*, typename T = eg_type<E>*/>
template<Color strong> inline Value Endgame<E>::krr_krr_1p_0p(const Position& pos, Score& score) const {
	I_AM_WEAK
	//Value v = rook_mid_high<strong>(pos) + pawn_close_king<strong>(pos) - rook_mid_high<weak>(pos) ;
	if(pos.full_ba(weak))
		return 	update_score_limit(score, -PAWN_END_40P);

	return VALUE_NONE;

}

template<EndgameType E/*, typename T = eg_type<E>*/>
template<Color strong> inline Value Endgame<E>::krr_krr_1p_1p(const Position& pos, Score& score) const {
	//I_AM_WEAK

	return VALUE_NONE;

}

template<EndgameType E/*, typename T = eg_type<E>*/>
template<Color strong> inline Value Endgame<E>::krr_krr_2p_0p(const Position& pos, Score& score) const {
	//I_AM_WEAK
	return VALUE_NONE;
}

template<EndgameType E/*, typename T = eg_type<E>*/>
template<Color strong> inline Value Endgame<E>::krr_krr_2p_1p(const Position& pos, Score& score) const {
	//I_AM_WEAK

	return VALUE_NONE;

}

template<EndgameType E/*, typename T = eg_type<E>*/>
template<Color strong> inline Value Endgame<E>::krr_krr_2p_2p(const Position& pos, Score& score) const {
	return VALUE_NONE;
}
