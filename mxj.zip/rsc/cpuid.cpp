#include "cpuid.h"

const InstructionSet::InstructionSet_Internal InstructionSet::CPU_Rep;
