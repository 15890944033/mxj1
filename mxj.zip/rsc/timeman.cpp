/*
Stockfish, a UCI chess playing engine derived from Glaurung 2.1
Copyright (C) 2004-2008 Tord Romstad (Glaurung author)
Copyright (C) 2008-2015 Marco Costalba, Joona Kiiski, Tord Romstad
Copyright (C) 2015-2017 Marco Costalba, Joona Kiiski, Gary Linscott, Tord Romstad

Stockfish is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

Stockfish is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#include <algorithm>

#include "search.h"
#include "timeman.h"
#include "uci.h"

TimeManagement Time; // Our global time management object

namespace {

	enum TimeType { OptimumTime, MaxTime };

	template<TimeType type>
	int remaining(int myTime, int myInc, int moveOverhead, int movesToGo,
		int moveNum, int byo, bool ponder) {

		if (myTime <= 0)
			return 0;

		myTime = int(myTime * (1.0 + byo / 37500.0));	//ÿ��3�룬��8% 

		double ratio; // Which ratio of myTime we are going to use

		// Usage of increment follows quadratic distribution with the maximum at move 25
		double inc = myInc * std::max(36.7, 80 - 0.08 * (moveNum - 25) * (moveNum - 25));

		// In moves-to-go we distribute time according to a quadratic function with
		// the maximum around move 20 for 40 moves in y time case.
		if (movesToGo)
		{
			ratio = (type == OptimumTime ? 1.0 : 6.0) / std::min(50, movesToGo);

			if (moveNum <= 40)
				ratio *= 1.1 - 0.001 * (moveNum - 20) * (moveNum - 20);
			else
				ratio *= 1.5;

			ratio *= 1 + inc / (myTime * 8.5);
		}
		// Otherwise we increase usage of remaining time as the game goes on
		else
		{
			double k = 1 + 20 * moveNum / (770.0 + moveNum);
			ratio = (type == OptimumTime ? 0.0153 : 0.6) * (k + inc / myTime);


			//if (moveNum <= 7)
			//	ratio = 0.85 * 0.1 * 0.125 * (0.92 + moveNum / 100.0);			//0.010625
			//else if(moveNum <= 39)
			//	ratio = 0.85 * 0.9 * 0.03125 * (1.1 - moveNum / 400.0);			//0.02391 
			//else
			//	ratio = 0.4 * 0.025 * (1.0 - moveNum / 800.0);					//0.01
			//
			//ratio *= 1 + inc / (myTime * 8.5);
			//if (type != OptimumTime)
			//	ratio *= 3.2;
		}

		double time = std::min(0.95, ratio) * std::max(0, myTime - moveOverhead);

		if (myInc == 0 && byo == 0) {
			time *= (moveNum < 60 ? 0.7 : 0.5);
		}

		if (type == OptimumTime && ponder)
			time *= 1.25;

		return (int) time;
	}

} // namespace



void TimeManagement::init(Search::LimitsType& limits, Color us, int ply)
{
	int moveOverhead = Options["Move Overhead"];
	int npmsec = Options["Nodes Time"];
	bool ponder = Options["Ponder"];

	// If we have to play in 'nodes as time' mode, then convert from time
	// to nodes, and use resulting values in time management formulas.
	// WARNING: Given npms (nodes per millisecond) must be much lower then
	// the real engine speed to avoid time losses.
	if (npmsec)
	{
		if (!availableNodes) // Only once at game start
			availableNodes = npmsec * limits.time[us]; // Time is in msec

													   // Convert from millisecs to nodes
		limits.time[us] = (int)availableNodes;
		limits.inc[us] *= npmsec;
		limits.npmsec = npmsec;
	}

	int moveNum = (ply + 1) / 2;

	startTime = limits.startTime;

	assert(limits.byo >= 0);

	optimumTime = remaining<OptimumTime>(limits.time[us], limits.inc[us], moveOverhead,
		limits.movestogo, moveNum, limits.byo, ponder);
	maximumTime = remaining<MaxTime>(limits.time[us], limits.inc[us], moveOverhead,
		limits.movestogo, moveNum, limits.byo, ponder);
}
