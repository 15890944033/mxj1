#define _CRT_SECURE_NO_WARNINGS //disable warning on sprintf and strncpy

#include <iostream>
#include <cstdlib>
#include <cstdio>
#include <cstring>
#include "pfobk.h"

int32_t CPFOBK::Open(const std::string &obk_file)
{
    return sqlite3_open_v2(obk_file.c_str(), &db, SQLITE_OPEN_READONLY, 0);
}

void CPFOBK::Close()
{
    sqlite3_close(db);
}

std::vector<CPFOBK::book_entry> CPFOBK::GetBookEntry(const std::string &fen)
{
    std::vector<book_entry> sr;
    int result;
    char *errmsg = NULL;
    char **dbResult;
    int nRow, nColumn;
    int i, j;
    int index;
    char szSql[1024] = { 0 };
    book_entry entry;

    if (db)
    {
        Position pos;
        pos.fromFen(fen);

        sprintf(szSql, "select * from [pfBook] where vkey=%lld order by vscore desc;", pos.hashkey);

        //std::cout << szSql << std::endl;
        result = sqlite3_get_table(db, szSql, &dbResult, &nRow, &nColumn, &errmsg);
        if (SQLITE_OK == result)
        {
            index = nColumn;
            for (i = 0; i < nRow; i++)
            {
                if (i > 127) break;
                for (j = 0; j < nColumn; j++)
                {
                    if (j == 2)entry.move = atoi(dbResult[index]);
                    else if (j == 3)entry.score = atoi(dbResult[index]);
                    else if (j == 4)entry.win_count = atoi(dbResult[index]);
                    else if (j == 5)entry.draw_count = atoi(dbResult[index]);
                    else if (j == 6)entry.lost_count = atoi(dbResult[index]);
                    else if (j == 7)entry.valid = atoi(dbResult[index]);
                    else if (j == 8 && dbResult[index])strncpy(entry.comments, dbResult[index], 64);
                    index++;
                }

                entry.move ^= 6541;
                //std::cout << std::hex << entry.move << std::dec <<  " " << entry.score << " " << entry.win_count << " " << entry.draw_count << " " << entry.lost_count << std::endl;
                sr.push_back(entry);
            }
        }

        if (sr.size() == 0)
        {
            Position pos_mirror;
            pos.mirror(pos_mirror);

            sprintf(szSql, "select * from [pfBook] where vkey=%lld order by vscore desc;", pos_mirror.hashkey);

            //std::cout << szSql << std::endl;
            result = sqlite3_get_table(db, szSql, &dbResult, &nRow, &nColumn, &errmsg);
            if (SQLITE_OK == result)
            {
                index = nColumn;
                for (i = 0; i < nRow; i++)
                {
                    if (i > 127) break;
                    for (j = 0; j < nColumn; j++)
                    {
                        if (j == 2)entry.move = atoi(dbResult[index]);
                        else if (j == 3)entry.score = atoi(dbResult[index]);
                        else if (j == 4)entry.win_count = atoi(dbResult[index]);
                        else if (j == 5)entry.draw_count = atoi(dbResult[index]);
                        else if (j == 6)entry.lost_count = atoi(dbResult[index]);
                        else if (j == 7)entry.valid = atoi(dbResult[index]);
                        else if (j == 8 && dbResult[index])strncpy(entry.comments, dbResult[index], 64);
                        index++;
                    }

                    entry.move ^= 6541;
                    entry.move = pos_mirror.MIRROR_MOVE(entry.move);
                    //std::cout << std::hex << entry.move << std::dec <<  " " << entry.score << " " << entry.win_count << " " << entry.draw_count << " " << entry.lost_count << std::endl;
                    sr.push_back(entry);
                }
            }

        }

        sqlite3_free_table(dbResult);
    }

    return sr;
}

