/*
Stockfish, a UCI chess playing engine derived from Glaurung 2.1
Copyright (C) 2004-2008 Tord Romstad (Glaurung author)
Copyright (C) 2008-2015 Marco Costalba, Joona Kiiski, Tord Romstad

Stockfish is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

Stockfish is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#ifndef TYPES_H_INCLUDED
#define TYPES_H_INCLUDED
#include <cassert>
#include <cctype>
#include <climits>
#include <cstdint>
#include <cstdlib>




#if defined(_WIN32) || defined(_WIN64)
#ifndef NOMINMAX
#define  NOMINMAX		//suppress the min and max definitions in Windef.h.
#endif
#endif

#if defined(_MSC_VER)
// Disable some silly and noisy warning from MSVC compiler
#pragma warning(disable: 4127) // Conditional expression is constant
#pragma warning(disable: 4146) // Unary minus operator applied to unsigned type
#pragma warning(disable: 4800) // Forcing value to bool 'true' or 'false'
#pragma warning(disable: 4996) // Forcing value to bool 'true' or 'false'
#endif

#define  INTERNAL_KNIFE_TABLE		//�ڲ��ɵ��� �оֿ�

#define	EDITION_MAXTHREADS	128
const int MAX_THREADS = EDITION_MAXTHREADS;
const int DEF_THREADS = EDITION_MAXTHREADS;

#if EDITION_MAXTHREADS == 2
const char sachessEdition[] = "DUAL";
const char Edition[] = " Dual Cores Edition ";

#elif EDITION_MAXTHREADS == 4
const char  sachessEdition[] = "QUAD";
const char Edition[] = " Quad Cores Edition ";

#elif EDITION_MAXTHREADS == 6
const char  sachessEdition[] = "SIXX";
const char Edition[] = " Six Cores Edition ";

#elif EDITION_MAXTHREADS == 8
const char  sachessEdition[] = "OCTG";
const char Edition[] = " Octg Cores Edition ";

#elif EDITION_MAXTHREADS == 12
const char  sachessEdition[] = "TWLV";
const char Edition[] = " 12 Cores Edition ";

#elif EDITION_MAXTHREADS == 16
const char  sachessEdition[] = "HEXA";
const char Edition[] = " Hexa Cores Edition ";

#elif EDITION_MAXTHREADS == 24
const char  sachessEdition[] = "TWFR";
const char Edition[] = " 24 Cores Edition ";

#elif EDITION_MAXTHREADS == 32
const char  sachessEdition[] = "THTW";
const char Edition[] = " 32 Cores Edition ";

#elif EDITION_MAXTHREADS == 48
const char  sachessEdition[] = "FTEI";
const char Edition[] = " 48 Cores Edition ";

#elif EDITION_MAXTHREADS == 64
const char  sachessEdition[] = "SIXF";
const char Edition[] = " 64 Cores Edition ";

#elif EDITION_MAXTHREADS == 128
const char  sachessEdition[] = "OTET";
const char Edition[] = " 128 Cores Edition ";

#elif EDITION_MAXTHREADS == 256
const char  sachessEdition[] = "TFSX";
const char Edition[] = " 256 Cores Edition ";

#else
const char  sachessEdition[] = "SING";
const char Edition[] = " Single Cores Edition ";

#endif 


#if defined(_WIN64)

#if EDITION_MAXTHREADS > 8

#define  USE_SSE4
#define  USE_POPCNT
//#define  USE_PEXT

#endif 

#endif

#if defined(_WIN64) && defined(_MSC_VER) // No Makefile used
#  include <intrin.h> // Microsoft header for _BitScanForward64()
#  define IS_64BIT
#endif

#if defined(USE_POPCNT) && (defined(__INTEL_COMPILER) || defined(_MSC_VER))
#  include <nmmintrin.h> // Intel and Microsoft header for _mm_popcnt_u64()
#endif

#if !defined(NO_PREFETCH) && (defined(__INTEL_COMPILER) || defined(_MSC_VER))
#  include <xmmintrin.h> // Intel and Microsoft header for _mm_prefetch()
#endif


#ifdef USE_POPCNT
const bool HasPopCnt = true;
#else
const bool HasPopCnt = false;
#endif

#ifdef USE_SSE4
const bool HasSSE4 = true;
#else
const bool HasSSE4 = false;
#endif



#ifdef IS_64BIT
const bool Is64Bit = true;
#else
const bool Is64Bit = false;
#endif

typedef uint64_t Key;
typedef uint64_t Bitboard;

const int MAX_MOVES = 128;
const int MAX_PLY = 128;
const int MAX_GAME_STEP = 1024;		//����ܲ���


const int  FILE_COUNT = 9;
const int  RANK_COUNT = 10;
//const int  min_bv = 4;		//��С��ֵ



enum Move : int {
	MOVE_NONE,
	MOVE_NULL = 129		//10000001
};

enum MoveType {
	NORMAL,
	//PROMOTION = 1 << 14,
	//ENPASSANT = 2 << 14,
	//CASTLING  = 3 << 14
};

enum Color {
	WHITE, BLACK, NO_COLOR, COLOR_NB = 2
};

enum Phase {
	PHASE_ENDGAME,
	PHASE_HALF_MIDGAME = 64,
	PHASE_MIDGAME = 128,
	MG = 0, EG = 1, PHASE_NB = 2
};

enum ScaleFactor {
	SCALE_FACTOR_DRAW = 0,
	SCALE_FACTOR_ONEPAWN = 48,
	SCALE_FACTOR_NORMAL = 64,
	SCALE_FACTOR_MAX = 1024,
	SCALE_FACTOR_NONE = 4096
};

enum Bound {
	BOUND_NONE,
	BOUND_UPPER,
	BOUND_LOWER,
	BOUND_EXACT = BOUND_UPPER | BOUND_LOWER
};

enum Value {
	VALUE_ZERO = 0,
	VALUE_DRAW = 0,
	VALUE_KNOWN_WIN = 10000,

	VALUE_MATE = 30000,
	VALUE_WIN_CYCLE_CATCH = 30001,		//���ֳ�׽
	VALUE_WIN_CYCLE_CHECK = 30002,		//���ֳ���
										//������࣬����500��
	VALUE_INFINITE = 32001,
	VALUE_NONE = 32002,
	VALUE_NOCYCLE = 32003,
	//����>=32767
	VALUE_MATE_IN_MAX_PLY = (int)VALUE_MATE - 2 * MAX_PLY,
	VALUE_MATED_IN_MAX_PLY = -(int)VALUE_MATE + 2 * MAX_PLY,

	PawnValueMg    = 168,    PawnValueEg     = 486,     //���ķ�ֵ
	BishopValueMg  = 416,    BishopValueEg   = 306,     //��ķ�ֵ
	AdvisorValueMg = 422,    AdvisorValueEg  = 307,     //ʿ�ķ�ֵ
	KnightValueMg  = 1407,   KnightValueEg   = 1840,	//���ķ�ֵ	// KnightValueEg must > CannonValueEg
	CannonValueMg  = 1720,   CannonValueEg   = 1780,    //�ڵķ�ֵ
	RookValueMg    = 3471,   RookValueEg     = 3947,    //���ķ�ֵ

	PawnCrValueMg = (int)PawnValueMg + 100,	        //�оֹ��ӱ�
	PawnDangerValueMg = (int)AdvisorValueMg + 100,	//�о�Σ�ձ�����������ʿ����
	

	RookVsNoRookWithPawn =(int) PawnValueEg + 103,		//����һ����������Ӷ��޳��ı������� �����б�
	RookVsNoRookWithoutPawn = 117,					//����һ����������Ӷ��޳��ı������� �����ޱ�
	RookWithPawnVsNoAdvisor = (int)PawnValueMg +100,     //��������ʿ ���оַ�ֵ��100
	KnightWithPawnVsNoAdvisor =(int) PawnValueMg +100,   //��������ʿ ���оַ�ֵ��100
	RootWithCannonWithAdvisorVsRootWithKnight=(int) AdvisorValueEg + 100,   //����ʿ�Գ������ڲоַ�ֵ��50
	RookWithCannonWithAdvisorVsRootNoAdvisor =(int) AdvisorValueEg + 150,  //����ʿ�Գ���ʿ��ʿ��ֵ��150
	RookWithPawnVsRootWithCannon = (int)PawnValueEg + 100,
	KnightWithPawnNoAdvisorVsCannonWithPawnNoAdvisor = (int)KnightValueEg +250,
};


/* [EVALUATE][VERIFIED] These variables are used in evaluate. */
const int RookMobility[] = { -112, -73, -50, -34, -22, -12, -3, 4, 11, 17, 22, 27, 32, 36, 40, 43, 47, 50 };
const int KnightMobility[] = { -112, -41, -8, 15, 33, 47, 60, 70, 80 };
const int KnightMobilityFactor = 16;
const int CannonControlFactor = 0;
const int CentroidKingPenalty = 100;

const int LinkedRooks = 16;
const int LinkedCannons = 16;
const int LinkedKnight = 16;
const int LinkedBishop = 16;
const int LinkedAdvisor = 16;
const int LinkedPawns = 400;

const int KingAttackWeights[8] = { 0, 0, 1, 1, 5, 0, 0, 8 };
const int kingAdjacentCountWeight = 4;
const int PinnedKingWeight = 8;
const int noRookWeight = 4;
const int geDefenseWeight = 1;
const int attackNoDefenseWeight = 16;
const int RookPawnContactCheck = 12;
const int DefensiveKillUnit = 48;

const int CannonDistanceFactor = 1;
const int xExposedCannonFactor = 7;
const int yExposedCannonFactor = 7;
const int ExposedCannonLimit = 112;

const int CannonPinUnit = 20;
const int pinRookFactor = 32;
const int pinKnightFactor = 72;
const int RookInRibLine = 6;
const int NoDefensedKingDoor = 6;
const int AttackedKingDoor = 6;
const int CannonPinLimit = 99;

const int RookCheck = 8;
const int CannonCheck = 4;
const int KnightCheck = 4;
const int PawnCheck = 2;

const int RookContactCheck = 16;
const int CannonContactCheck = 8;
const int KnightContactCheck = 6;
const int PawnContactCheck = 64;
/* [EVALUATE][VERIFIED] End section. */


enum PieceType {
	//NO_PIECE_TYPE, PAWN, KNIGHT, BISHOP, ROOK, QUEEN, KING,
	NO_PIECE_TYPE, PAWN, BISHOP, ADVISOR, KNIGHT, CANNON, ROOK, KING,
	ALL_PIECES = 0,
	PIECE_TYPE_NB = 8
};

enum Piece {
	NO_PIECE,
	W_PAWN = 1, W_BISHOP, W_ADVISOR, W_KNIGHT, W_CANNON, W_ROOK, W_KING,
	B_PAWN = 9, B_BISHOP, B_ADVISOR, B_KNIGHT, B_CANNON, B_ROOK, B_KING,
	PIECE_NB = 16, PIECE_HALF = 8
};

extern Value PieceValue[PHASE_NB][PIECE_NB];// ��������
constexpr int ATTACKER_PIECES = (1 << ROOK) | (1 << CANNON) | (1 << KNIGHT) | (1 << PAWN);
constexpr int PRIME_PIECES = (1 << ROOK) | (1 << CANNON) | (1 << KNIGHT);
constexpr int SLIDER_PIECES = (1 << KING) | (1 << ROOK) | (1 << CANNON) | (1 << PAWN);
constexpr int DIAGONAL_PIECES = (1 << KNIGHT) | (1 << BISHOP) | (1 << ADVISOR);

// �����ڡ����������ɹ��ӹ���������
constexpr int PIECE_IS_ATTACKER(int pt) { return (1 << pt) & ATTACKER_PIECES; }

// �����ڡ�������Ҫ��������
constexpr int PIECE_IS_PRIME(int pt) { return (1 << pt) & PRIME_PIECES; }

// ���������ڡ�����ֱ�����ߵ�����
constexpr int PIECE_IS_SLIDER(int pt) { return (1 << pt) & SLIDER_PIECES; }

// ������ʿ��б�����ߵ�����
constexpr int PIECE_IS_DIAGONAL(int pt) { return (1 << pt) & DIAGONAL_PIECES; }


enum Depth : int {

	ONE_PLY = 1,

	DEPTH_ZERO = 0 *(int) ONE_PLY,
	DEPTH_QS_CHECKS = 0 *(int) ONE_PLY,
	DEPTH_QS_NO_CHECKS = -5 * (int)ONE_PLY,
	//DEPTH_QS_RECAPTURES = -5 * ONE_PLY,

	DEPTH_NONE = -6 *(int) ONE_PLY,
	DEPTH_MAX = 2 * MAX_PLY * (int)ONE_PLY
};

static_assert(!(ONE_PLY & (ONE_PLY - 1)), "ONE_PLY is not a power of 2");

enum Direct {
	NORTH_DIR = 0,
	SOUTH_DIR = 1,
	WEST_DIR = 2,
	EAST_DIR = 3,
};


enum Square {
	

	SQ_A0, SQ_B0, SQ_C0, SQ_D0, SQ_E0, SQ_F0, SQ_G0, SQ_H0, SQ_I0,
	SQ_A1, SQ_B1, SQ_C1, SQ_D1, SQ_E1, SQ_F1, SQ_G1, SQ_H1, SQ_I1,
	SQ_A2, SQ_B2, SQ_C2, SQ_D2, SQ_E2, SQ_F2, SQ_G2, SQ_H2, SQ_I2,
	SQ_A3, SQ_B3, SQ_C3, SQ_D3, SQ_E3, SQ_F3, SQ_G3, SQ_H3, SQ_I3,
	SQ_A4, SQ_B4, SQ_C4, SQ_D4, SQ_E4, SQ_F4, SQ_G4, SQ_H4, SQ_I4,
	SQ_A5, SQ_B5, SQ_C5, SQ_D5, SQ_E5, SQ_F5, SQ_G5, SQ_H5, SQ_I5,
	SQ_A6, SQ_B6, SQ_C6, SQ_D6, SQ_E6, SQ_F6, SQ_G6, SQ_H6, SQ_I6,
	SQ_A7, SQ_B7, SQ_C7, SQ_D7, SQ_E7, SQ_F7, SQ_G7, SQ_H7, SQ_I7,
	SQ_A8, SQ_B8, SQ_C8, SQ_D8, SQ_E8, SQ_F8, SQ_G8, SQ_H8, SQ_I8,
	SQ_A9, SQ_B9, SQ_C9, SQ_D9, SQ_E9, SQ_F9, SQ_G9, SQ_H9, SQ_I9,
	SQ_NONE,
	SQUARE_NB = 90,
	SQUARE_HALF = 45,

	NORTH = 9,
	EAST = 1,
	SOUTH = -int(NORTH),
	WEST = -int(EAST),

	NORTH_NORTH = int(NORTH) + int(NORTH),
	NORTH_EAST = int(NORTH) + int(EAST),
	SOUTH_EAST = int(SOUTH) + int(EAST),
	SOUTH_SOUTH = int(SOUTH) + int(SOUTH),
	SOUTH_WEST = int(SOUTH) + int(WEST),
	NORTH_WEST = int(NORTH) + int(WEST),
	WEST_WEST = int(WEST) + int(WEST),
	EAST_EAST = int(EAST) + int(EAST),

	SOUTH_WEST_WEST = int(SOUTH_WEST) + int(WEST),
	NORTH_WEST_WEST = NORTH_WEST + int(WEST),
	SOUTH_SOUTH_WEST = int(SOUTH_SOUTH) + int(WEST),
	NORTH_NORTH_WEST = NORTH_NORTH + int(WEST),
	SOUTH_EAST_EAST = SOUTH_EAST + int(EAST),
	NORTH_EAST_EAST = NORTH_EAST + int(EAST),
	SOUTH_SOUTH_EAST = SOUTH_SOUTH + int(EAST),
	NORTH_NORTH_EAST = NORTH_NORTH + int(EAST),

};

enum File : int {
	//FILE_A, FILE_B, FILE_C, FILE_D, FILE_E, FILE_F, FILE_G, FILE_H, FILE_NB
	FILE_A, FILE_B, FILE_C, FILE_D, FILE_E, FILE_F, FILE_G, FILE_H, FILE_I, FILE_NB

};

enum Rank : int {
	//RANK_0, RANK_1, RANK_2, RANK_3, RANK_4, RANK_5, RANK_6, RANK_7, RANK_NB
	RANK_0, RANK_1, RANK_2, RANK_3, RANK_4, RANK_5, RANK_6, RANK_7, RANK_8, RANK_9, RANK_NB

};



enum Score : int { SCORE_ZERO };

enum Flank { LEFT = 0, RIGHT = 1, MIDDLE };

enum BishopAdvisorNum {
	BA_ZERO,	//0
	BA_BS,		//bishop
	BA_AD,		//advisor	
	BA_BA,		//bishop + advisor
	BA_DB,		//double b
	BA_DA,		//double a
	BA_DBA,		//double b + a 
	BA_BDA,		//double a + b 
	BA_DBDA		//double b + double a 
};


enum CycleType {	//ѭ������
	CT_NO,		//��ѭ��
	CT_1 = 1,		//2��ѭ��
	CT_2 = 2,		//4��ѭ��
	CT_4 = 4,		//8��ѭ��
	CT_10 = 10,		//10��ѭ��
	CT_12 = 12,		//12��ѭ��
	CT_18 = 18,
	CT_24 = 24,
	CT_28 = 28,
    CT_32 = 32,
	CT_36 = 36,
	CT_64 = 64,

	CT_MAX = CT_28		//���ѭ���غ����� Ŀǰ��8�غ� 
};

enum KnightDirect {
	KDirect_1, KDirect_2, KDirect_3, KDirect_4, KDirect_5, KDirect_6, KDirect_7, KDirect_8
};

enum IndexPieceType : int16_t {
	IPT_NULL = 0,

};


const uint8_t	c_arr_int_file[SQUARE_NB] = {
	0, 1, 2, 3, 4, 5, 6, 7, 8,
	0, 1, 2, 3, 4, 5, 6, 7, 8,
	0, 1, 2, 3, 4, 5, 6, 7, 8,
	0, 1, 2, 3, 4, 5, 6, 7, 8,
	0, 1, 2, 3, 4, 5, 6, 7, 8,
	0, 1, 2, 3, 4, 5, 6, 7, 8,
	0, 1, 2, 3, 4, 5, 6, 7, 8,
	0, 1, 2, 3, 4, 5, 6, 7, 8,
	0, 1, 2, 3, 4, 5, 6, 7, 8,
	0, 1, 2, 3, 4, 5, 6, 7, 8

};

const uint8_t	c_arr_int_rank[SQUARE_NB] = {
	0, 0, 0, 0, 0, 0, 0, 0, 0,
	1, 1, 1, 1, 1, 1, 1, 1, 1,
	2, 2, 2, 2, 2, 2, 2, 2, 2,
	3, 3, 3, 3, 3, 3, 3, 3, 3,
	4, 4, 4, 4, 4, 4, 4, 4, 4,
	5, 5, 5, 5, 5, 5, 5, 5, 5,
	6, 6, 6, 6, 6, 6, 6, 6, 6,
	7, 7, 7, 7, 7, 7, 7, 7, 7,
	8, 8, 8, 8, 8, 8, 8, 8, 8,
	9, 9, 9, 9, 9, 9, 9, 9, 9

};

// ������ܷ����ʵ��������ľ���(���ҶԳ�)
const Square sqMirror[SQUARE_NB] = {
	SQ_I0, SQ_H0, SQ_G0, SQ_F0, SQ_E0, SQ_D0, SQ_C0, SQ_B0, SQ_A0,
	SQ_I1, SQ_H1, SQ_G1, SQ_F1, SQ_E1, SQ_D1, SQ_C1, SQ_B1, SQ_A1,
	SQ_I2, SQ_H2, SQ_G2, SQ_F2, SQ_E2, SQ_D2, SQ_C2, SQ_B2, SQ_A2,
	SQ_I3, SQ_H3, SQ_G3, SQ_F3, SQ_E3, SQ_D3, SQ_C3, SQ_B3, SQ_A3,
	SQ_I4, SQ_H4, SQ_G4, SQ_F4, SQ_E4, SQ_D4, SQ_C4, SQ_B4, SQ_A4,
	SQ_I5, SQ_H5, SQ_G5, SQ_F5, SQ_E5, SQ_D5, SQ_C5, SQ_B5, SQ_A5,
	SQ_I6, SQ_H6, SQ_G6, SQ_F6, SQ_E6, SQ_D6, SQ_C6, SQ_B6, SQ_A6,
	SQ_I7, SQ_H7, SQ_G7, SQ_F7, SQ_E7, SQ_D7, SQ_C7, SQ_B7, SQ_A7,
	SQ_I8, SQ_H8, SQ_G8, SQ_F8, SQ_E8, SQ_D8, SQ_C8, SQ_B8, SQ_A8,
	SQ_I9, SQ_H9, SQ_G9, SQ_F9, SQ_E9, SQ_D9, SQ_C9, SQ_B9, SQ_A9
};

// ������ܷ����ʵ���������б�Գ�
const Square sqLeanMirror[SQUARE_NB] = {
	SQ_I9, SQ_H9, SQ_G9, SQ_F9, SQ_E9, SQ_D9, SQ_C9, SQ_B9, SQ_A9,
	SQ_I8, SQ_H8, SQ_G8, SQ_F8, SQ_E8, SQ_D8, SQ_C8, SQ_B8, SQ_A8,
	SQ_I7, SQ_H7, SQ_G7, SQ_F7, SQ_E7, SQ_D7, SQ_C7, SQ_B7, SQ_A7,
	SQ_I6, SQ_H6, SQ_G6, SQ_F6, SQ_E6, SQ_D6, SQ_C6, SQ_B6, SQ_A6,
	SQ_I5, SQ_H5, SQ_G5, SQ_F5, SQ_E5, SQ_D5, SQ_C5, SQ_B5, SQ_A5,
	SQ_I4, SQ_H4, SQ_G4, SQ_F4, SQ_E4, SQ_D4, SQ_C4, SQ_B4, SQ_A4,
	SQ_I3, SQ_H3, SQ_G3, SQ_F3, SQ_E3, SQ_D3, SQ_C3, SQ_B3, SQ_A3,
	SQ_I2, SQ_H2, SQ_G2, SQ_F2, SQ_E2, SQ_D2, SQ_C2, SQ_B2, SQ_A2,
	SQ_I1, SQ_H1, SQ_G1, SQ_F1, SQ_E1, SQ_D1, SQ_C1, SQ_B1, SQ_A1,
	SQ_I0, SQ_H0, SQ_G0, SQ_F0, SQ_E0, SQ_D0, SQ_C0, SQ_B0, SQ_A0

};

const Rank rnRelative[][RANK_NB] = {
	{RANK_0, RANK_1, RANK_2, RANK_3, RANK_4, RANK_5, RANK_6, RANK_7, RANK_8, RANK_9, } , 
	{ RANK_9, RANK_8, RANK_7, RANK_6, RANK_5, RANK_4, RANK_3, RANK_2, RANK_1, RANK_0, }
}; 

// �������¶ԳƵ�����
const Square sqVerMirror[SQUARE_NB] = {
	SQ_A9, SQ_B9, SQ_C9, SQ_D9, SQ_E9, SQ_F9, SQ_G9, SQ_H9, SQ_I9,
	SQ_A8, SQ_B8, SQ_C8, SQ_D8, SQ_E8, SQ_F8, SQ_G8, SQ_H8, SQ_I8,
	SQ_A7, SQ_B7, SQ_C7, SQ_D7, SQ_E7, SQ_F7, SQ_G7, SQ_H7, SQ_I7,
	SQ_A6, SQ_B6, SQ_C6, SQ_D6, SQ_E6, SQ_F6, SQ_G6, SQ_H6, SQ_I6,
	SQ_A5, SQ_B5, SQ_C5, SQ_D5, SQ_E5, SQ_F5, SQ_G5, SQ_H5, SQ_I5,
	SQ_A4, SQ_B4, SQ_C4, SQ_D4, SQ_E4, SQ_F4, SQ_G4, SQ_H4, SQ_I4,
	SQ_A3, SQ_B3, SQ_C3, SQ_D3, SQ_E3, SQ_F3, SQ_G3, SQ_H3, SQ_I3,
	SQ_A2, SQ_B2, SQ_C2, SQ_D2, SQ_E2, SQ_F2, SQ_G2, SQ_H2, SQ_I2,
	SQ_A1, SQ_B1, SQ_C1, SQ_D1, SQ_E1, SQ_F1, SQ_G1, SQ_H1, SQ_I1,
	SQ_A0, SQ_B0, SQ_C0, SQ_D0, SQ_E0, SQ_F0, SQ_G0, SQ_H0, SQ_I0
};

struct ExtMove {
	Move move;
	int value;
	//bool threat;
	operator Move() const { return move; }
	void operator=(Move m) { move = m; }
	// Inhibit unwanted implicit conversions to Move
	// with an ambiguity that yields to a compile error.
	//operator float() const;
};

inline bool operator<(const ExtMove& f, const ExtMove& s) {
	return f.value < s.value;
}

inline bool is_ok(Rank r) {
	return r >= RANK_0 && r < RANK_NB;
}

inline bool is_ok(File f) {
	return f >= FILE_A && f < FILE_NB;
}

inline bool is_ok(Square s) {
	return s >= SQ_A0 && s < SQUARE_NB;
}

inline constexpr bool is_ok(Color c) {
	return c == WHITE || c == BLACK;
}

inline constexpr bool is_ok(PieceType pt) {
	return pt >= PAWN && pt < PIECE_TYPE_NB;
}

inline constexpr bool is_ok(Piece p) {
	return p >= W_PAWN && p < PIECE_NB && p != 8;
}

inline Square from_sq(Move m) {
	//assert(is_ok(m));
	//return Square((m >> 6) & 0x3F);
	return Square(m & 127);
}

inline Square to_sq(Move m) {
	//assert(is_ok(m));
	//return Square(m & 0x3F);
	return Square(m >> 7);
}

inline int from_to(Move m) {
	return m & 0x3FFF;
}

inline bool is_ok(Move m) {
	return from_sq(m) != to_sq(m); // Catch MOVE_NULL and MOVE_NONE
}

inline Score make_score(int mg, int eg) {
	return Score((mg << 16) + eg);
}

/// Extracting the signed lower and upper 16 bits is not so trivial because
/// according to the standard a simple cast to short is implementation defined
/// and so is a right shift of a signed integer.
inline Value mg_value(Score s) {

	union { uint16_t u; int16_t s; } mg = { uint16_t(unsigned(s + 0x8000) >> 16) };
	return Value(mg.s);
}

inline Value eg_value(Score s) {

	union { uint16_t u; int16_t s; } eg = { uint16_t(unsigned(s)) };
	return Value(eg.s);
}

inline IndexPieceType make_ipt(PieceType pt, int idx) {
	return IndexPieceType((idx << 8) + pt);
}

#define ENABLE_BASE_OPERATORS_ON(T)                             \
inline T operator+(T d1, T d2) { return T(int(d1) + int(d2)); } \
inline T operator-(T d1, T d2) { return T(int(d1) - int(d2)); } \
inline T operator-(T d) { return T(-int(d)); }                  \
inline T& operator+=(T& d1, T d2) { return d1 = d1 + d2; }      \
inline T& operator-=(T& d1, T d2) { return d1 = d1 - d2; }      \


#define ENABLE_FULL_OPERATORS_ON(T)                             \
ENABLE_BASE_OPERATORS_ON(T)                                     \
inline T operator*(int i, T d) { return T(i * int(d)); }        \
inline T operator*(T d, int i) { return T(int(d) * i); }        \
inline T& operator++(T& d) { return d = T(int(d) + 1); }        \
inline T& operator--(T& d) { return d = T(int(d) - 1); }        \
inline T operator/(T d, int i) { return T(int(d) / i); }        \
inline int operator/(T d1, T d2) { return int(d1) / int(d2); }  \
inline T& operator*=(T& d, int i) { return d = T(int(d) * i); } \
inline T& operator/=(T& d, int i) { return d = T(int(d) / i); }

ENABLE_FULL_OPERATORS_ON(Value)
ENABLE_FULL_OPERATORS_ON(PieceType)
ENABLE_FULL_OPERATORS_ON(Piece)
ENABLE_FULL_OPERATORS_ON(Color)
ENABLE_FULL_OPERATORS_ON(Depth)
ENABLE_FULL_OPERATORS_ON(Square)
ENABLE_FULL_OPERATORS_ON(File)
ENABLE_FULL_OPERATORS_ON(Rank)
ENABLE_FULL_OPERATORS_ON(Flank)

ENABLE_BASE_OPERATORS_ON(Score)

#undef ENABLE_FULL_OPERATORS_ON
#undef ENABLE_BASE_OPERATORS_ON

/// Additional operators to add integers to a Value
inline Value operator+(Value v, int i) { return Value(int(v) + i); }
inline Value operator-(Value v, int i) { return Value(int(v) - i); }
inline Value& operator+=(Value& v, int i) { return v = v + i; }
inline Value& operator-=(Value& v, int i) { return v = v - i; }
inline Value operator*(Value v, double d) { return Value(int(double(v) * d)); }
inline Value& operator*=(Value& v, double d) { return v = Value(int(double(v) * d)); }

/// Only declared but not defined. We don't want to multiply two scores due to
/// a very high risk of overflow. So user should explicitly convert to integer.
//inline Score operator*( Score s1, Score s2);

/// Division of a Score must be handled separately for each term
inline Score operator/(Score s, int i) {
	return make_score(mg_value(s) / i, eg_value(s) / i);
}

/// Multiplication of a Score by an integer. We check for overflow in debug mode.
inline Score operator*(Score s, int i) {
	Score result = Score(int(s) * i);

	assert(eg_value(result) == (i * eg_value(s)));
	assert(mg_value(result) == (i * mg_value(s)));
	assert((i == 0) || (result / i) == s);

	return result;
}

inline Score operator*(Score s, double d) {
	Score result = make_score((int)(mg_value(s) * d), (int)(eg_value(s) * d));

	//assert(eg_value(result) == (d * eg_value(s)));
	//assert(mg_value(result) == (d * mg_value(s)));
	//assert((d == 0) || (result / d) == s);

	return result;
}

extern int	 NoCaptureDraw;		//�������к͵Ļغ���	40-200
extern Value PieceValue[PHASE_NB][PIECE_NB];
extern Value PawnPosValue[COLOR_NB][SQUARE_NB];

inline Color operator~(Color c) {
	assert(is_ok(c));
	return Color(c ^ BLACK);	// Toggle color
}

inline Flank operator~(Flank fl) {
	return fl == MIDDLE ? fl : Flank(fl ^ RIGHT);
}

inline Square operator~(Square s) {
	//return Square(s ^ SQ_A7); // Vertical flip SQ_A0 -> SQ_A7
	assert(is_ok(s));
	return sqVerMirror[s];
}

inline Piece operator~(Piece pc) {
	return Piece(pc ^ 8);	// Swap color of piece B_KNIGHT -> W_KNIGHT
}

inline File operator~(File f)
{
	assert(is_ok(f));
	return File(FILE_I - f);
}

inline Rank operator~(Rank r)
{
	assert(is_ok(r));
	return Rank(RANK_9 - r);
}

inline Value mate_in(int ply) {
	return VALUE_MATE - ply;
}

inline Value mated_in(int ply) {
	return -VALUE_MATE + ply;
}

inline Square make_square(File f, Rank r) {
	//return Square((r << 3) | f);

	//assert(is_ok(f) && is_ok(r));
	return Square((r << 3) + r + f);

}

inline constexpr Piece make_piece(Color c, PieceType pt) {
	return Piece((c << 3) + pt);
}

inline constexpr PieceType type_of(Piece pc) {
	return PieceType(pc & 7);
}

inline constexpr bool is_pt(Piece pc, PieceType pt) {
	return (pc & pt) == pt;
}

//PAWN KNIGHT CANNON ROOK
inline constexpr bool attack_pt(PieceType pt) {
	return (pt >= KNIGHT && pt <= ROOK) || pt == PAWN;
}

inline Color color_of(Piece pc) {
	assert(is_ok(pc));
	return Color(pc >> 3);
}


inline File file_of(Square s) {
	assert(is_ok(s));
	//return File((int)s % 9);
	return File(c_arr_int_file[s]);
}

inline Rank rank_of(Square s) {
	//return Rank(s >> 3);
	assert(is_ok(s));
	return Rank(c_arr_int_rank[s]);

}

inline Square mirror(const Square s)
{
	assert(is_ok(s));
	return sqMirror[s];
}

inline  Square lean_mirror(const Square s)
{
	assert(is_ok(s));
	return sqLeanMirror[s];
}

inline Square relative_square(Color c, Square s) {
	//return Square(s ^ (c * 56));
	assert(is_ok(c) && is_ok(s));
	return c == WHITE ? s : ~s;

}

template<Color c>
inline Square relative_square(Square s) {
	return relative_square(c, s);
}

inline Square bishop_eye(Square s1, Square s2) {
	return Square((s1 + s2) >> 1);
}


inline Rank relative_rank(Color c, Rank r) {
	assert(is_ok(c) && is_ok(r));
	return c == WHITE ? r : ~r;
	//return rnRelative[c][r];

}

template<Color c>
inline Rank relative_rank(Rank r) {
	assert(is_ok(c) && is_ok(r));
	return c == WHITE ? r : ~r;

	//return rnRelative[c][r];
}

template<Color c>
inline Rank relative_rank(Square s) {
	assert(is_ok(c) && is_ok(s));
	return relative_rank<c>(rank_of(s));
}

inline Rank relative_rank(Color c, Square s) {
	assert(is_ok(c) && is_ok(s));
	return relative_rank(c, rank_of(s));
}

inline File relative_file(File f) {
	assert(is_ok(f));
	return f <= FILE_E ? f : ~f;
}

inline File relative_file(Square s) {
	assert(is_ok(s));
	return relative_file(file_of(s));
}


inline Move make_move(Square from, Square to) {
	//return Move(to | (from << 6));
	//assert(is_ok(from) );
	return Move((to << 7) + from);

}


#if defined(IS_64BIT)

typedef  __m128i BitboardC;

inline bool not_z(const BitboardC b) {
#if defined(USE_SSE4)

	return _mm_testz_si128(b, b) == 0;		//CPUID Flags: SSE4.1
#else
	return b.m128i_u64[0] | b.m128i_u64[1];
#endif

}

inline BitboardC merge64(const Bitboard white, const Bitboard black) {
	return _mm_set_epi64x(black, white);	//CPUID Flags: SSE2
}


inline Bitboard low64(const BitboardC bc) {
	return _mm_cvtsi128_si64(bc);		//CPUID Flags: SSE2
}

inline Bitboard high64(const BitboardC bc) {
	return _mm_cvtsi128_si64(_mm_unpackhi_epi64(bc, bc));		//CPUID Flags : SSE2	SSE2
}

inline Bitboard half64(const BitboardC bc, const Color c) {
	//return c == WHITE ? low64(bc) : high64(bc);

	return bc.m128i_u64[c];
}

#else

typedef union BitboardC {
	Bitboard	m128i_u64[2];

}BitboardC;


inline bool not_z(const BitboardC b) {
	return b.m128i_u64[0] | b.m128i_u64[1];
}


inline BitboardC merge64(const Bitboard w, const Bitboard b) {
	BitboardC bc;
	bc.m128i_u64[0] = w;
	bc.m128i_u64[1] = b;
	return bc;
}


inline Bitboard low64(const BitboardC bc) {
	return bc.m128i_u64[0];
}

inline Bitboard high64(const BitboardC bc) {
	return bc.m128i_u64[1];
}

inline Bitboard half64(const BitboardC bc, const Color c) {
	return bc.m128i_u64[c];
}

#endif

inline bool equal_z(const BitboardC b) {
	//return !not_z(b);

#if defined(IS_64BIT) && defined(USE_SSE4)
	return (bool)_mm_testz_si128(b, b);		//CPUID Flags: SSE4.1
#else
	return b.m128i_u64[0] == 0 && b.m128i_u64[1] == 0;

#endif

}

//
//inline Square operator|(File f, Rank r)
//{
//	return Square(((r << 3) + r) + f);
//}


// ���̵�������λ�ã��׷����Ǻڷ�
inline Color square_color(const Square s) {
	assert(is_ok(s));
	return Color(s >= SQUARE_HALF);
}

inline Color rank_color(const Rank r) {
	assert(is_ok(r));
	return Color(r > RANK_4);
}

inline bool is_half_legal(const Square s) {
	assert(is_ok(s));
	return s >= SQ_A0 && s < SQUARE_HALF;
}

// ����鷵��ֵ�Ϸ���
template<KnightDirect kd>
inline Square knight_dst(const Square s) {
	assert(is_ok(s));
	switch (kd)
	{
	case KDirect_1:
		return Square(s - 2 * FILE_COUNT - 1);
	case KDirect_2:
		return Square(s - FILE_COUNT - 2);
	case KDirect_3:
		return Square(s + FILE_COUNT - 2);
	case KDirect_4:
		return Square(s + 2 * FILE_COUNT - 1);
	case KDirect_5:
		return Square(s - 2 * FILE_COUNT + 1);
	case KDirect_6:
		return Square(s - FILE_COUNT + 2);
	case KDirect_7:
		return Square(s + FILE_COUNT + 2);
	default:
		assert(kd == KDirect_8);
		return Square(s + 2 * FILE_COUNT + 1);
	}

	assert(0);
	return SQ_NONE;
}

inline Flank square_flank(const File f) {
	return f < FILE_E ? LEFT : f > FILE_E ? RIGHT : MIDDLE;
}

inline Flank square_flank(const Square s) {
	return square_flank(file_of(s));
}

inline bool square_middle(const Square s) {
	return file_of(s) == FILE_E;
}

inline bool is_same_file(const Square s1, const Square s2) {
	return file_of(s1) == file_of(s2);
}

inline bool is_same_file(const Square s1, const Square s2, const Square s3) {
	return file_of(s1) == file_of(s2) && file_of(s1) == file_of(s3);
}

inline bool is_same_rank(const Square s1, const Square s2) {
	return rank_of(s1) == rank_of(s2);
}

inline bool is_same_rank(const Square s1, const Square s2, const Square s3) {
	return rank_of(s1) == rank_of(s2) && rank_of(s1) == rank_of(s3);
}

//ͬ�л�ͬ�� ����TRUE
inline bool is_same_row(const Square s1, const Square s2) {
	return file_of(s1) == file_of(s2) || rank_of(s1) == rank_of(s2);
}

//ͬ�����Ҳ���м�
inline bool same_flank(const Square s1, const Square s2) {
	return square_flank(s1) == square_flank(s2);
}

inline int file_distance(File f1, File f2) {
	assert(is_ok(f1) && is_ok(f2));
	return abs(f1 - f2);
}

inline int file_distance(Square s1, Square s2) {
	assert(is_ok(s1) && is_ok(s2));
	return file_distance(file_of(s1), file_of(s2));
}


inline int rank_distance(Rank r1, Rank r2) {
	assert(is_ok(r1) && is_ok(r2));
	return abs(r1 - r2);
}

inline int rank_distance(Square s1, Square s2) {
	assert(is_ok(s1) && is_ok(s2));
	return rank_distance(rank_of(s1), rank_of(s2));
}

inline bool bottom_rank(Rank r) {
	return r == RANK_0 || r == RANK_9;
}

inline bool bottom_rank(Square s) {
	return bottom_rank(rank_of(s));
}

inline char file_to_char(File f) {
	return char(f - FILE_A + int('a'));
}

inline constexpr File char_to_file(char c) {
	return File(c - 'a' + FILE_A);
}

inline char rank_to_char(Rank r) {
	return  char(r - RANK_0 + int('0'));
	//	return  r == RANK_9 ?  'A' : char(r - RANK_0 + int('1'));
}

inline constexpr Rank char_to_rank(char c) {
	return Rank(c - '0' + RANK_0);
}

// ����֮��ľ���  �о�����о��� s1 != s2 ��С����Ϊ1
inline uint8_t kp_distance(Square s1, Square s2) {
	assert(is_ok(s1) && is_ok(s2));
	return file_distance(s1, s2) + rank_distance(s1, s2);
}

//ȡ��������32λ���е�4������SQ
inline Square pop_kp(uint32_t& kp) {
	Square s = Square(kp & 0xFF);
	kp >>= 8;
	return s;
}
//�ֽڰ�������reverse  10000000 => 00000001
inline uint32_t reverse_32bit(uint32_t b) {
	static const unsigned char BitReverseTable256[256] =
	{
#   define R2(n)     n,     n + 2*64,     n + 1*64,     n + 3*64
#   define R4(n) R2(n), R2(n + 2*16), R2(n + 1*16), R2(n + 3*16)
#   define R6(n) R4(n), R4(n + 2*4 ), R4(n + 1*4 ), R4(n + 3*4 )
		R6(0), R6(2), R6(1), R6(3)
	};

	uint32_t c;
	unsigned char * p = (unsigned char *)&b;
	unsigned char * q = (unsigned char *)&c;
	q[3] = BitReverseTable256[p[0]];
	q[2] = BitReverseTable256[p[1]];
	q[1] = BitReverseTable256[p[2]];
	q[0] = BitReverseTable256[p[3]];
	return c;

}

inline uint8_t reverse_5bit(uint8_t b) {
	b = uint8_t((b * 0x0202020202ULL & 0x010884422010ULL) % 1023);
	return b >> 3;
}

//˫���Ƿ�����
inline bool bishop_link(const Square s1, const Square s2) {
	return  rank_distance(s1, s2) == 2 && file_distance(s1, s2) == 2;
}

inline constexpr bool no_advisor(const BishopAdvisorNum ba) {
	return ba <= BA_BS || ba == BA_DB;
}

//�Ƿ�c������  ==0 WHITE���� 
template<Color c>
inline bool is_advantage(const Value v) {
	return c == WHITE ? v >= 0 : v < 0;
}

template<Color c>
inline bool is_advantage(const Score score) {
	return is_advantage<c>(eg_value(score));
}

const Value VALUE_CRON_PAWNS = PawnValueEg * 0.37;
const Value VALUE_PAWNS_VALID = PawnValueEg * 0.4;		    //��Ч��
const Value VALUE_BA_ADJUST_MAX_UL = PawnValueEg * 2.14;    //ʿ�󷽵������������  
const Value VALUE_ADV_LOWLIMIT = PawnValueEg * 0.95;		//���Ʒ�������

const Value PAWN_END_10P = PawnValueEg * 0.1;
const Value PAWN_END_12P = PawnValueEg * 0.12;
const Value PAWN_END_20P = PawnValueEg * 0.2;
const Value PAWN_END_25P = PawnValueEg * 0.25;
const Value PAWN_END_30P = PawnValueEg * 0.3;
const Value PAWN_END_33P = PawnValueEg * 0.33;
const Value PAWN_END_40P = PawnValueEg * 0.4;
const Value PAWN_END_45P = PawnValueEg * 0.45;
const Value PAWN_END_50P = PawnValueEg * 0.5;
const Value PAWN_END_55P = PawnValueEg * 0.55;
const Value PAWN_END_60P = PawnValueEg * 0.6;
const Value PAWN_END_67P = PawnValueEg * 0.67;
const Value PAWN_END_70P = PawnValueEg * 0.7;
const Value PAWN_END_73P = PawnValueEg * 0.73;
const Value PAWN_END_76P = PawnValueEg * 0.76;
const Value PAWN_END_80P = PawnValueEg * 0.8;
const Value PAWN_END_81P = PawnValueEg * 0.81;
const Value PAWN_END_84P = PawnValueEg * 0.84;
const Value PAWN_END_90P = PawnValueEg * 0.9;
const Value PAWN_END_95P = PawnValueEg * 0.95;
const Value PAWN_END_105P = PawnValueEg * 1.05;
const Value PAWN_END_110P = PawnValueEg * 1.1;
const Value PAWN_END_115P = PawnValueEg * 1.15;
const Value PAWN_END_120P = PawnValueEg * 1.2;
const Value PAWN_END_125P = PawnValueEg * 1.25;
const Value PAWN_END_130P = PawnValueEg * 1.3;
const Value PAWN_END_140P = PawnValueEg * 1.4;
const Value PAWN_END_150P = PawnValueEg * 1.5;
const Value PAWN_END_155P = PawnValueEg * 1.55;
const Value PAWN_END_160P = PawnValueEg * 1.6;
const Value PAWN_END_165P = PawnValueEg * 1.65;
const Value PAWN_END_170P = PawnValueEg * 1.7;
const Value PAWN_END_177P = PawnValueEg * 1.77;
const Value PAWN_END_180P = PawnValueEg * 1.8;
const Value PAWN_END_190P = PawnValueEg * 1.9;
const Value PAWN_END_200P = PawnValueEg * 2.0;
const Value PAWN_END_220P = PawnValueEg * 2.2;
const Value PAWN_END_230P = PawnValueEg * 2.3;
const Value PAWN_END_238P = PawnValueEg * 2.38;
const Value PAWN_END_260P = PawnValueEg * 2.6;
const Value PAWN_END_265P = PawnValueEg * 2.65;
const Value PAWN_END_270P = PawnValueEg * 2.7;
const Value PAWN_END_310P = PawnValueEg * 3.1;

const Value BISHOP_END_10P = BishopValueEg * 0.1;
const Value BISHOP_END_12P = BishopValueEg * 0.12;
const Value BISHOP_END_20P = BishopValueEg * 0.2;
const Value BISHOP_END_25P = BishopValueEg * 0.25;
const Value BISHOP_END_30P = BishopValueEg * 0.3;
const Value BISHOP_END_33P = BishopValueEg * 0.33;
const Value BISHOP_END_40P = BishopValueEg * 0.4;
const Value BISHOP_END_45P = BishopValueEg * 0.45;
const Value BISHOP_END_50P = BishopValueEg * 0.5;
const Value BISHOP_END_55P = BishopValueEg * 0.55;
const Value BISHOP_END_60P = BishopValueEg * 0.6;
const Value BISHOP_END_67P = BishopValueEg * 0.67;
const Value BISHOP_END_70P = BishopValueEg * 0.7;
const Value BISHOP_END_73P = BishopValueEg * 0.73;
const Value BISHOP_END_76P = BishopValueEg * 0.76;
const Value BISHOP_END_80P = BishopValueEg * 0.8;
const Value BISHOP_END_81P = BishopValueEg * 0.81;
const Value BISHOP_END_84P = BishopValueEg * 0.84;
const Value BISHOP_END_90P = BishopValueEg * 0.9;
const Value BISHOP_END_95P = BishopValueEg * 0.95;
const Value BISHOP_END_105P = BishopValueEg * 1.05;
const Value BISHOP_END_110P = BishopValueEg * 1.1;
const Value BISHOP_END_115P = BishopValueEg * 1.15;
const Value BISHOP_END_120P = BishopValueEg * 1.2;
const Value BISHOP_END_125P = BishopValueEg * 1.25;
const Value BISHOP_END_130P = BishopValueEg * 1.3;
const Value BISHOP_END_140P = BishopValueEg * 1.4;
const Value BISHOP_END_150P = BishopValueEg * 1.5;
const Value BISHOP_END_155P = BishopValueEg * 1.55;
const Value BISHOP_END_160P = BishopValueEg * 1.6;
const Value BISHOP_END_165P = BishopValueEg * 1.65;
const Value BISHOP_END_170P = BishopValueEg * 1.7;
const Value BISHOP_END_177P = BishopValueEg * 1.77;
const Value BISHOP_END_180P = BishopValueEg * 1.8;
const Value BISHOP_END_190P = BishopValueEg * 1.9;
const Value BISHOP_END_200P = BishopValueEg * 2.0;
const Value BISHOP_END_210P = BishopValueEg * 2.1;
const Value BISHOP_END_220P = BishopValueEg * 2.2;
const Value BISHOP_END_230P = BishopValueEg * 2.3;
const Value BISHOP_END_238P = BishopValueEg * 2.38;
const Value BISHOP_END_260P = BishopValueEg * 2.6;
const Value BISHOP_END_265P = BishopValueEg * 2.65;
const Value BISHOP_END_270P = BishopValueEg * 2.7;
const Value BISHOP_END_310P = BishopValueEg * 3.1;


const Value KNIGHT_END_20P = KnightValueEg * 0.2;
const Value KNIGHT_END_30P = KnightValueEg * 0.3;
const Value KNIGHT_END_40P = KnightValueEg * 0.4;
const Value KNIGHT_END_50P = KnightValueEg * 0.5;
const Value KNIGHT_END_60P = KnightValueEg * 0.6;
const Value KNIGHT_END_70P = KnightValueEg * 0.7;
const Value KNIGHT_END_80P = KnightValueEg * 0.8;
const Value KNIGHT_END_90P = KnightValueEg * 0.9;
const Value KNIGHT_END_140P = KnightValueEg * 1.4;

#endif // #ifndef TYPES_H_INCLUDED