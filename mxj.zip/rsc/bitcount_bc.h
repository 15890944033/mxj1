
#if !defined(BITCOUNT_BC_H_INCLUDED)
#define BITCOUNT_BC_H_INCLUDED

#include <cassert>
#include "types.h"
#include "bitboard.h"


#if !defined(USE_POPCNT)

	assert(false);
	return low64(b) != 0; // Avoid 'b not used' warning

#elif defined(_MSC_VER) && defined(__INTEL_COMPILER)

	return _mm_popcnt_u64(low64(b)) + _mm_popcnt_u64(high64(b));

#elif defined(_MSC_VER)

	

#else

	// TODO: ������࣬���ﻹ��Ҫ���� high64(b)
	unsigned long ret;
	__asm__("popcnt %1, %0" : "=r" (ret) : "r" (low64(b)));
	return ret;

#endif

#endif