#include "endgame.h"

template<EndgameType E/*, typename T = eg_type<E>*/>
template<Color c>
inline void Endgame<E>::rr_rcc_total(const Position& pos, Score& score) const {
	Value v = VALUE_ZERO;
	const Color Them = c == WHITE ? BLACK : WHITE;

	int adWeak = pos.count(Them, ADVISOR);

	int nbpStrong = pos.pawn_nobottomcount<c>();
	//int nbpWeak = pos.pawn_nobottomcount<Them>();
	int vpWeak = pos.pawn_validcount<Them>();

	if (adWeak == 2 && (!pos.full_ba(c) || vpWeak > 0)) {
		int vpStrong = pos.pawn_validcount<c>();

		if (nbpStrong == 0)
			v += vpWeak > 0 ? -BishopValueEg : -BISHOP_END_80P;
		else if (vpStrong == 0 && !pos.full_ba(c))
			v += vpWeak > 0 ? -BishopValueEg : -BISHOP_END_40P;

	}

	//�����ڵף��۷�
	if (!pos.is_king_bottom(Them))
		v = BISHOP_END_110P;

	update_score(score, c,  v);
}

template<>
Value Endgame<KRRKRCC>::operator()(const Position& pos, Score& score) const {

	strongSide == WHITE ? rr_rcc_total<WHITE>(pos, score) : rr_rcc_total<BLACK>(pos, score);

	FUN_IMPL_DIFF_PIECES_ALL(krr_krcc)
}

//˫��ʤ����˫�� ���ͳ���˫ʿ
template<EndgameType E/*, typename T = eg_type<E>*/>
template<Color strong> inline Value Endgame<E>::krr_krcc_0p_0p(const Position& pos, Score& score) const {
	I_AM_WEAK
		auto baStrong = pos.ba_number<strong>();
	auto baWeak = pos.ba_number<weak>();

	//�͵���� 
	if (baWeak >= BA_DA) {
		if (is_advantage<strong>(score)) {
			return value_draw_zoom<2>(pos, score);
		}
	}


	return VALUE_NONE;
}

template<EndgameType E/*, typename T = eg_type<E>*/>
template<Color strong> inline Value Endgame<E>::krr_krcc_1p_0p(const Position& pos, Score& score) const {
	I_AM_WEAK

	if (pos.count(weak, ADVISOR) == 2 && pos.count(weak, BISHOP) > 0
		&& is_advantage<strong>(score) && pos.pawn_bottomcount<strong>() == 0
		&& equal_z(pos.pieces(strong, PAWN) & DangerPawnSide[strong]))
		return value_draw_zoom<2>(pos, score);

	return VALUE_NONE;

}

template<EndgameType E/*, typename T = eg_type<E>*/>
template<Color strong> inline Value Endgame<E>::krr_krcc_2p_0p(const Position& pos, Score& score) const {
	return VALUE_NONE;
}

template<EndgameType E/*, typename T = eg_type<E>*/>
template<Color strong> inline Value Endgame<E>::krr_krcc_0p_1p(const Position& pos, Score& score) const {
	return VALUE_NONE;
}

template<EndgameType E/*, typename T = eg_type<E>*/>
template<Color strong> inline Value Endgame<E>::krr_krcc_1p_1p(const Position& pos, Score& score) const {
	return VALUE_NONE;
}

template<EndgameType E/*, typename T = eg_type<E>*/>
template<Color strong> inline Value Endgame<E>::krr_krcc_2p_1p(const Position& pos, Score& score) const {
	return VALUE_NONE;
}


template<EndgameType E/*, typename T = eg_type<E>*/>
template<Color strong> inline Value Endgame<E>::krr_krcc_0p_2p(const Position& pos, Score& score) const {
	return VALUE_NONE;
}

template<EndgameType E/*, typename T = eg_type<E>*/>
template<Color strong> inline Value Endgame<E>::krr_krcc_1p_2p(const Position& pos, Score& score) const {
	return VALUE_NONE;
}

template<EndgameType E/*, typename T = eg_type<E>*/>
template<Color strong> inline Value Endgame<E>::krr_krcc_2p_2p(const Position& pos, Score& score) const {
	return VALUE_NONE;
}
