#include "endgame.h"


//���ڷ��������ƣ����ڷ��б������ڱ������ƴ󣬼Ӷ�� �� û�б�����������С�����ٷ�
//˫��û��ʿ���۷� 
//���ڷ���2�����Ϲ��ӱ���������ӷǵ��ߵ�����Ҳ�û�б����۷�
//˫�������2��ʿ��û�����ʿ���۷�
//���ڷ���ʿ��û�б����ڲ��ڼ������λ�ã��۷�
//���ڷ������ڵ���˫�ڷ�����������ӷ�
//���ڷ������ڵ���2 or ����1��˫�ڷ�������0�� �ӷ�
//˫�ڷ������ڵ���3���ӷ�
template<EndgameType E/*, typename T = eg_type<E>*/>
template<Color c>
inline void Endgame<E>::cn_cc_total(const Position& pos, Score& score) const {
	const Color Them = c == WHITE ? BLACK : WHITE;

	adjust_pawn_behind_king<c>(pos, score, 0.8);
	adjust_pawn_behind_king<Them>(pos, score, 0.8);



	int adKn = pos.count(c, ADVISOR);
	int adCn = pos.count(Them, ADVISOR);

	int duitou = pawns_headtohead(pos);
	int nbpKn = pos.pawn_nobottomcount<c>() - duitou;
	int nbpCn = pos.pawn_nobottomcount<Them>() - duitou;

	int vpKn = pos.pawn_validcount<c>();
	int vpCn = pos.pawn_validcount<Them>();

	int dcKn = pos.defense_count(c);
	int dcCn = pos.defense_count(Them);
	int dcdiff = dcCn - dcKn;

	Value v = Value(67);
	if (nbpKn > 0) {
		if (vpKn > 0) {
			if (vpCn == 0)
				v += PAWN_END_120P;
			else if (vpCn <= vpKn)
				v += PAWN_END_90P;
		}
		else {
			if (vpCn == 0)
				v += PAWN_END_95P;
			else
				v += Value(13);
		}
	}
	else if (nbpCn > 0)
		v = VALUE_ZERO;


	if (adKn == 0 && adCn > 0)
		v += -BISHOP_END_10P;
	else if (adKn > 0 && adCn == 0)
		v += BISHOP_END_10P;


	if (vpKn >= 2
		&& (equal_z(pos.pieces_pawn_crnb<c>() & FlankBoardBC[LEFT]) || equal_z(pos.pieces_pawn_crnb<c>() & FlankBoardBC[RIGHT]))) {
		v += -PAWN_END_10P;
	}


	if (adKn == 2 && !pos.is_advisor_cavel(c))
		v += -BISHOP_END_10P;
	if (adCn == 2 && !pos.is_advisor_cavel(Them))
		v += BISHOP_END_10P;


	if (adKn > 0 && pos.pawn_nobottomcount<c>() == 0 && !cannon_home_attack(pos, c))
		v += -PAWN_END_10P;
	else if(nbpKn == 0 && adCn > 0 && nbpCn > 0 && !cannon_home_attack(pos, Them))
		v += PAWN_END_10P;


	//�����ʿ��ֵ���
	if (dcdiff > 0 && (((nbpKn + duitou) > 0 && (nbpCn + duitou) == 0) ||
		(vpKn > 0 && vpCn == 0 && nbpKn > nbpCn))) {
		v += dcdiff * BISHOP_END_40P;
	}
	else if (dcdiff < 0 && (((nbpKn + duitou) == 0 && (nbpCn + duitou) > 0) ||
		(vpCn > 0 && vpKn == 0 && nbpKn < nbpCn))) {
		v += dcdiff * BISHOP_END_40P;
	}

	//�б����ޱ��� �й��ӱ����жԷ�������ı��� �Է���ʿ�� �ӷ�
	if (nbpKn > 0 && nbpCn == 0 && adCn <= 1 && dcCn <= 2)
		v += PAWN_END_80P * nbpKn;
	else if (vpKn > 0 && nbpCn == 0 && adCn == 0 && pos.pawn_onkinglow3count<c>() > 0)
		v += PAWN_END_50P * vpKn;
	else if (vpKn >= 2 && (vpCn == 0 || (vpCn == 1 && adKn == 2)) && pos.pawn_onkinglow3count<c>() > 0)
		v += PAWN_END_30P * vpKn;

	//��ͷ�ڣ������ڹ���λ�ã��й��ӱ���������ȫ��
	if (kongtou_cannon<c>(pos) && is_kn_attack<c>(pos) && vpKn > 0) {
		int dist = pos.pawn_mindist_king<c>(pos.square(Them, KING));
		v += (9 - dist) * PAWN_END_55P;
	}

	//�ڵ��ƶ��Գͷ���
	BitboardC notAttacked[2];
	notAttacked[c] = ~(pos.pawn_attacks<Them>() | pos.bishop_attacks<Them>()
		| pos.advisor_attacks<Them>() | pos.attacks_from<KING>(pos.square(Them, KING)));
	notAttacked[Them] = ~(pos.pawn_attacks<c>() | pos.bishop_attacks<c>()
		| pos.advisor_attacks<c>() | pos.attacks_from<KING>(pos.square(c, KING)));


	//�ڵ��ƶ��Գͷ���
	int mob;
	mob = cannon_mobility<c>(pos, notAttacked[c]);
	v += value_cannon_mob<c>(pos, mob);

	mob = cannon_mobility<Them, false>(pos, notAttacked[Them]);
	v += -value_cannon_mob<Them>(pos, mob);

	//�����ƶ��Գͷ���
	v += value_knight_mob<c>(pos, notAttacked[c]);

	update_score(score, c,  v);



}

template<>
Value Endgame<KCNKCC>::operator()(const Position& pos, Score& score) const {

	if (strongSide == WHITE) {
		if (knking_chain_bycannon<WHITE>(pos) && pos.pawn_validcount<BLACK>() > 0)
			return update_score(score, -KNIGHT_END_70P);
	}
	else {
		if (knking_chain_bycannon<BLACK>(pos) && pos.pawn_validcount<WHITE>() > 0)
			return update_score(score, KNIGHT_END_70P);
	}

	strongSide == WHITE ? cn_cc_total<WHITE>(pos, score) : cn_cc_total<BLACK>(pos, score);

	//if (pos.count(WHITE, PAWN) <= 3 && pos.count(BLACK, PAWN) <= 3) {
	//	if (pos.pawn_validcount<WHITE>() == 0 && pos.full_ba(BLACK) && greater_than<WHITE>(score, VALUE_ADV_LOWLIMIT)) {
	//		return value_draw_zoom<1>(score);
	//	}
	//	else if (pos.pawn_validcount<BLACK>() == 0 && pos.full_ba(WHITE) && greater_than<BLACK>(score, VALUE_ADV_LOWLIMIT)) {
	//		return value_draw_zoom<1>(score);
	//	}
	//}

	FUN_IMPL_DIFF_PIECES_ALL(kcn_kcc)
}


template<EndgameType E/*, typename T = eg_type<E>*/>
template<Color strong> inline Value Endgame<E>::kcn_kcc_0p_0p(const Position& pos, Score& score) const {

	return value_draw_zoom<8>(pos, score);

}

template<EndgameType E/*, typename T = eg_type<E>*/>
template<Color strong> inline Value Endgame<E>::kcn_kcc_1p_0p(const Position& pos, Score& score) const {

	I_AM_WEAK

	auto ba = pos.ba_number<weak>();
	switch (ba)
	{
	case BA_ZERO:
	case BA_BS:
	case BA_AD:
	case BA_BA:
	case BA_DB:
	case BA_DA:
	case BA_DBA:
	case BA_BDA:
		break;
	default:	//ȫʿ�����ڷ�û�еױ���Ӯ���Ѷȴ�
		if (pos.pawn_bottomcount<strong>() > 0)
			break;

		return value_draw_zoom<1>(pos, score);
	}
	return 	VALUE_NONE;

}

template<EndgameType E/*, typename T = eg_type<E>*/>
template<Color strong> inline Value Endgame<E>::kcn_kcc_2p_0p(const Position& pos, Score& score) const {
	return 	VALUE_NONE;
}


template<EndgameType E/*, typename T = eg_type<E>*/>
template<Color strong> inline Value Endgame<E>::kcn_kcc_0p_1p(const Position& pos, Score& score) const {

	I_AM_WEAK
	auto baWeak = pos.ba_number<weak>();

	if (pos.full_ba(strong) && baWeak >= BA_DBA && pos.pawn_bottomcount<weak>() == 0)
		return value_draw_zoom<2>(pos, score);

	return 	VALUE_NONE;
}

template<EndgameType E/*, typename T = eg_type<E>*/>
template<Color strong> inline Value Endgame<E>::kcn_kcc_1p_1p(const Position& pos, Score& score) const {
	return 	VALUE_NONE;
}

template<EndgameType E/*, typename T = eg_type<E>*/>
template<Color strong> inline Value Endgame<E>::kcn_kcc_2p_1p(const Position& pos, Score& score) const {
	return 	VALUE_NONE;
}

template<EndgameType E/*, typename T = eg_type<E>*/>
template<Color strong> inline Value Endgame<E>::kcn_kcc_0p_2p(const Position& pos, Score& score) const {
	//I_AM_WEAK

	//	if (pos.full_ba(strong) && pos.pawn_bottomcount<weak>() == 0)
	//		return value_draw_zoom<2>(pos, score);

	return 	VALUE_NONE;

}

template<EndgameType E/*, typename T = eg_type<E>*/>
template<Color strong> inline Value Endgame<E>::kcn_kcc_1p_2p(const Position& pos, Score& score) const {
	return 	VALUE_NONE;
}

template<EndgameType E/*, typename T = eg_type<E>*/>
template<Color strong> inline Value Endgame<E>::kcn_kcc_2p_2p(const Position& pos, Score& score) const {
	return 	VALUE_NONE;
}
