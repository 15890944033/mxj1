#include "bitboardc.h"

#include <algorithm>
#include <cstring>
#include <iostream>

#include "misc.h"
#include "util_vmp.h"

// ���̸���ӳ��  �׷���߲��� �ڷ����ӳ�䵽�׷�
Square	SquareMap[128];
//int SquareDistance[SQUARE_NB][SQUARE_NB];

//����ÿ��SQ�ı�����SQ	���4���������һ��32λ������   �������߷���Ӱ��ı�����SQ������
//uint32_t allKnightPin[SQUARE_NB];
// 2������FROM ��TO������ ����FROM  ��1ά��FROM ��2ά ��TO	���from ��to ���������ߵ���λ��  ֵ:SQ_NONE
Square		sqKnightPin[SQUARE_NB][SQUARE_NB];
// 2������ FROM ������ ���õ��ĸ��� ��1ά��FROM ��2ά ������   ���߱سɿ�����
// example: sqKnightNulDst[SQ_A0][SQ_B1] == SQ_B2
//Square		sqKnightNulDst[128][128];
//����Ϊ���۲����ߵ��ĵ� �� s1: ��λ s2: ����  etc: sqBishopNotReach[SQ_E2][SQ_D3] = SQ_C4
Square  sqBishopNotReach[SQUARE_NB][SQUARE_NB];

// ������������̹���ÿ������ʱ���б��������ʱ���޷���ɹ�������ʼ����  
// ��һ��128��squareA ��2��128�� ���ȸ������� B   ��ŵ�ֵ��C and D 
// ---D---
// |  |  |
// C--B---
// |  |  |
// |-----A-
//SquarePair	pairKnightPin[128][128];
//// ���̸���ӳ��  [2][64] Color half of board 
//// Color white������  Color Black : SQ_A0 => SQ_A9  ~square
//Square	SquareColorMap[2][64];
// ���ͱ��ľ���  [128][128]: king_square pawn_square
//uint8_t KPDistance[128][128];


BitboardC SquareBC[128];
BitboardC ReverseSquareBC[128];		// λ���̣��������ӵ�Ϊ0 ����������Ϊ1�����ڽ�����������0
BitboardC NotRowBC[SQUARE_NB];		//�ų���sͬ��ͬ�е�����λ����
BitboardC SameRowBC[SQUARE_NB];		//��sͬ��ͬ�е�λ����
BitboardC KingRing[SQUARE_NB];
BitboardC KingRingPawn[SQUARE_NB];
BitboardC KnightPinFrom[SQUARE_NB];		//��������ÿ����ʱ���ܱ����ȵĵ��λ���� �����������ھӵ�  KnightPinFrom[SQ_A0] = (SQ_A1 | SQ_B0)
BitboardC KnightPinTo[SQUARE_NB];		//����������ÿ����ʱ���ܱ����ȵĵ��λ����  ��������п����ھӵ� KnightPinTo[SQ_A0] = (SQ_B1)
BitboardC BishopPin[SQUARE_NB];			//����λ���� BishopPin[SQ_E2] = (SQ_D1 | SQ_D3 | SQ_F1 | SQ_F3)
BitboardC PseudoAttacksRook[SQUARE_NB]; //����s�㣬�������������������ܹ������ĵ㣬Ҳ���Ǽ��޹�����

BitboardC FileBC[16];
BitboardC RankBC[16];
BitboardC ReverseFileBC[16];
BitboardC ReverseRankBC[16];
BitboardC AdjacentFilesBC[16];

//���������е��4�������ϵ�ͬ�У���ͬ�У���λ����
//FileRankDirBC[SQ_A0][NORTH_DIR] == FILE_A ^ SQ_A0
BitboardC FileRankDirBC[SQUARE_NB][4];

// ������������һ���ܺ��򹥻���BitboardC
// SQUARE_NB��������ÿ����		512: ÿ������������ϵ������� 2��9�η�
// ���ֺڰ׷�����Ϊ�ڷ��׷���һ����
BitboardC AttacksRookRankBC[SQUARE_NB][128];
// ������������һ�������򹥻���BitboardC
// SQUARE_NB��������ÿ����		1024: ÿ������������ϵ������� 2��10�η�
BitboardC AttacksRookFileBC[SQUARE_NB][256];
// ÿ�����ֻ��2��1���ֱ��ʾ�����ϲ�ͬ�ķ���ĸ���
BitboardC AttacksCannonRankBC[SQUARE_NB][128];
BitboardC AttacksCannonFileBC[SQUARE_NB][256];


BitboardC PseudoAttacks[PIECE_TYPE_NB][SQUARE_NB];	//ROOK ����������û���ӵ����  CANNONû�õ�

													//����s�ܹ������ĵ�  PawnAttackingBC[W_PAWN][SQ_A3] == SQ_A4
BitboardC PawnAttackingBC[2][SQUARE_NB];
// �ڸ���square�ܱ�ĳ����square�еı�������  etc. PawnAttackedBC[W_PAWN][SQ_A4] == SQ_A3
BitboardC PawnAttackedBC[2][SQUARE_NB];
// s1 �� s2֮��ĸ�����Ϊ1 �� λ����  s1��s2ͬ�л�ͬ�У�����Ϊ0
BitboardC BetweenBC[SQUARE_NB][SQUARE_NB];
// s1 �� s2 ��ͬ�л�ͬ�� ����ͬ���л��е�λ����
BitboardC LineBC[SQUARE_NB][SQUARE_NB];
//����Ϊ���Ȳ����ߵ��ĵ� �� s1: ��λ s2: ����  etc: KnightNotReach[SQ_E2][SQ_E3] = (SQ_D4 | SQ_F4)
BitboardC KnightNotReach[SQUARE_NB][SQUARE_NB];
// �����������̸����ܹ����������и���
// 8���������� ֻ��ROOK CANNON���� 128: ��A1��I10 ����
//BitboardC PseudoAttacksBC[8][128];
// �������İ�ȫ����  2: color 128: square
//BitboardC KingRingBC[2][128];
BitboardC InFrontBC[COLOR_NB][RANK_NB];
BitboardC ForwardBC[COLOR_NB][SQUARE_NB];
//sλ�õ����ڱ�����ʱ���ߵ���λ����  [Square][����Square��һ���ֵ]
BitboardC KnightReachedPinFrom[SQUARE_NB][KnightPinTotal];
//���Ǳ����ȵ�����£���Щλ���ܹ�����s [Square][����Square��һ���ֵ (��s�ɿ���)]
BitboardC KnightReachedPinTo[SQUARE_NB][KnightPinTotal];
BitboardC BishopReachedPin[SQUARE_NB][BishopPinTotal];

//BitboardC* KnightReachedPinFrom;
//BitboardC* KnightReachedPinTo;


std::set<Square> setBishopLegal;

/// Bitboards::print() prints a bitboard in an easily readable format to the
/// standard output. This is sometimes useful for debugging.
void BitboardCs::print(const BitboardC b) 
{
	//const BitboardC FullBoard = _mm_set_epi32(0xFFFFFFFF, 0xFFFFFFFF, 0xFFFFFFFF, 0xFFFFFFFF);
    const BitboardC FullBoard = merge64(0xFFFFFFFFFFFFFFFF, 0xFFFFFFFFFFFFFFFF);
    std::string s = "+---+---+---+---+---+---+---+---+\n";
	for (Square sq = SQ_A0; sq < SQUARE_NB; ++sq) {
		if (FullBoard & sq)
			std::cout << sq << std::endl;
		//s += (FullBoard & sq) ? "| X " : "|   ";
		//s += "|\n+---+---+---+---+---+---+---+---+\n";
	}
	//std::cout << s << std::endl;
	//Bitboards::print(high64(b), BLACK);
	//// sync_cout;
	//std::cout << "|    R  I  V  E  R      |" << std::endl;
	//Bitboards::print(low64(b), WHITE);
}

/// Bitboards::init() initializes various bitboard arrays. It is called during
/// program initialization.

void BitboardCs::init()
{
	init_bishop_legal();
	init_squaremap();
	//init_squaredistance();
	init_square_bc();
	init_file_rank_bc();
	init_reverse_squarebc();
	init_row_bc();
	init_kingring_bc();
	//init_bishop_eye_square();
	init_stepattacks_bishop();
	init_stepattacks_advisor();
	init_stepattacks_knight();
	init_stepattacks_rk_cn();
	init_stepattacks_king();
	init_knight_pin();
	init_bishop_pin();
	init_bishop_reach_pin();
	init_move_pawn();
	//init_pseudo_attack();
	init_between();
	init_line();
	init_knight_notreach();
	init_bishop_notreach();
	//init_king_ring();
	//init_kp_distance();
	init_front_bc();
	init_filerank_dir();
}


void BitboardCs::init_bishop_legal()
{
	setBishopLegal = { SQ_A2, SQ_C0, SQ_C4, SQ_E2, SQ_G0, SQ_G4, SQ_I2, SQ_A7, SQ_C5, SQ_C9, SQ_E7, SQ_G5, SQ_G9, SQ_I7 };
}

void BitboardCs::init_squaremap()
{
#ifdef VMPROTECT
	VMProtectBeginUltra("init_smap");
#endif


	for (Square s = SQ_A0; s < SQUARE_HALF; ++s)
	{
		SquareMap[s] = s;
	}
#ifdef VMPROTECT

	VMProtectEnd();
#endif

	for (Square s = SQUARE_HALF; s < SQUARE_NB; ++s)
	{
		SquareMap[s] = ~s;
	}


}

void BitboardCs::init_square_bc()
{
	for (Square s = SQ_A0; s < SQUARE_NB; ++s) {
		SquareBC[s].m128i_u64[square_color(s)] |= SquareMap[s];
	}
}

void BitboardCs::init_row_bc()
{
	for (Square s = SQ_A0; s < SQUARE_NB; ++s) {
		SameRowBC[s] = file_bc(s) | rank_bc(s);
		NotRowBC[s] = ~SameRowBC[s];
	}
}


void BitboardCs::init_kingring_bc() {
	KingRing[SQ_D0] = SQ_C0 | SQ_C1 | SQ_C2 | SQ_D0 | SQ_D1 | SQ_D2 | SQ_E0 | SQ_E1 | SQ_E2;
	KingRingPawn[SQ_D0] = SQ_C0 | SQ_C1 | SQ_D0 | SQ_D1 | SQ_D2 | SQ_E0 | SQ_E1 | SQ_E2 | SQ_F1;

	KingRing[SQ_D1] = SQ_C0 | SQ_C1 | SQ_C2 | SQ_C3 | SQ_D0 | SQ_D1 | SQ_D2 | SQ_D3 | SQ_E0 | SQ_E1 | SQ_E2 | SQ_E3;
	KingRingPawn[SQ_D1] = SQ_C1 | SQ_C2 | SQ_D0 | SQ_D1 | SQ_D2 | SQ_D2 | SQ_E0 | SQ_E1 | SQ_E2 | SQ_F1;

	KingRing[SQ_D2] = SQ_C1 | SQ_C2 | SQ_C3 | SQ_C4 | SQ_D1 | SQ_D2 | SQ_D3 | SQ_D4 | SQ_E1 | SQ_E2 | SQ_E3 | SQ_E4;
	KingRingPawn[SQ_D2] = SQ_C1 | SQ_C2 | SQ_C3 | SQ_D1 | SQ_D2 | SQ_D3 | SQ_D4 | SQ_E1 | SQ_E2 | SQ_E3 | SQ_F2;

	KingRing[SQ_E0] = SQ_D0 | SQ_D1 | SQ_D2 | SQ_E0 | SQ_E1 | SQ_E2 | SQ_F0 | SQ_F1 | SQ_F2;
	KingRingPawn[SQ_E0] = SQ_D0 | SQ_D1 | SQ_E0 | SQ_E1 | SQ_E2 | SQ_F0 | SQ_F1;

	KingRing[SQ_E1] = SQ_D0 | SQ_D1 | SQ_D2 | SQ_D3 | SQ_E0 | SQ_E1 | SQ_E2 | SQ_E3 | SQ_F0 | SQ_F1 | SQ_F2 | SQ_F3;
	KingRingPawn[SQ_E1] = SQ_C1 | SQ_D1 | SQ_D2 | SQ_E0 | SQ_E1 | SQ_E2 | SQ_E3 | SQ_F1 | SQ_F2 | SQ_G1;

	KingRing[SQ_E2] = SQ_D1 | SQ_D2 | SQ_D3 | SQ_D4 | SQ_E1 | SQ_E2 | SQ_E3 | SQ_E4 | SQ_F1 | SQ_F2 | SQ_F3 | SQ_F4;
	KingRingPawn[SQ_E2] = SQ_D1 | SQ_D2 | SQ_D3 | SQ_E1 | SQ_E2 | SQ_E3 | SQ_E4 | SQ_F1 | SQ_F2 | SQ_F3;


#ifdef VMPROTECT
	VMProtectBeginUltraLockByKey("init_kr");
#endif


	KingRing[SQ_F0] = mirror(KingRing[SQ_D0]);
	KingRingPawn[SQ_F0] = mirror(KingRingPawn[SQ_D0]);

	KingRing[SQ_F1] = mirror(KingRing[SQ_D1]);
	KingRingPawn[SQ_F1] = mirror(KingRingPawn[SQ_D1]);
#ifdef VMPROTECT

	VMProtectEnd();
#endif

	KingRing[SQ_F2] = mirror(KingRing[SQ_D2]);
	KingRingPawn[SQ_F2] = mirror(KingRingPawn[SQ_D2]);

	KingRing[SQ_D9] = merge64(0, low64(KingRing[SQ_D0]));
	KingRing[SQ_D8] = merge64(0, low64(KingRing[SQ_D1]));
	KingRing[SQ_D7] = merge64(0, low64(KingRing[SQ_D2]));
	KingRing[SQ_E9] = merge64(0, low64(KingRing[SQ_E0]));
	KingRing[SQ_E8] = merge64(0, low64(KingRing[SQ_E1]));
	KingRing[SQ_E7] = merge64(0, low64(KingRing[SQ_E2]));
	KingRing[SQ_F9] = merge64(0, low64(KingRing[SQ_F0]));
	KingRing[SQ_F8] = merge64(0, low64(KingRing[SQ_F1]));
	KingRing[SQ_F7] = merge64(0, low64(KingRing[SQ_F2]));

	KingRingPawn[SQ_D9] = merge64(0, low64(KingRingPawn[SQ_D0]));
	KingRingPawn[SQ_D8] = merge64(0, low64(KingRingPawn[SQ_D1]));
	KingRingPawn[SQ_D7] = merge64(0, low64(KingRingPawn[SQ_D2]));
	KingRingPawn[SQ_E9] = merge64(0, low64(KingRingPawn[SQ_E0]));
	KingRingPawn[SQ_E8] = merge64(0, low64(KingRingPawn[SQ_E1]));
	KingRingPawn[SQ_E7] = merge64(0, low64(KingRingPawn[SQ_E2]));
	KingRingPawn[SQ_F9] = merge64(0, low64(KingRingPawn[SQ_F0]));
	KingRingPawn[SQ_F8] = merge64(0, low64(KingRingPawn[SQ_F1]));
	KingRingPawn[SQ_F7] = merge64(0, low64(KingRingPawn[SQ_F2]));


}

void BitboardCs::init_knight_pin_square()
{


	for (int i = 0; i < SQUARE_NB; ++i)
	{
		//allKnightPin[i] = 0;
		for (int j = 0; j < SQUARE_NB; ++j)
		{
			sqKnightPin[i][j] = SQ_NONE;
		}
	}



	for (Square s = SQ_A0; s < SQUARE_NB; ++s)
	{
		Rank r = rank_of(s);
		File f = file_of(s);

		//Square t;
		//int sft = 0;
		//if (f > FILE_B)
		//{
		//	t = s + WEST;
		//	allKnightPin[s] |= t;
		//	++sft;
		//}
		//if (f < FILE_H)
		//{
		//	t = s + EAST;
		//	allKnightPin[s] |= (t << (8 * sft));
		//	++sft;
		//}
		//if (r > RANK_1)
		//{
		//	t = s + SOUTH;
		//	allKnightPin[s] |= (t << (8 * sft));
		//	++sft;
		//}
		//if (r < RANK_8)
		//{
		//	t = s + NORTH;
		//	allKnightPin[s] |= (t << (8 * sft));
		//	++sft;
		//}

		// KDirect_1
		if (r >= RANK_2 && f >= FILE_B)
		{
			sqKnightPin[s][s + SOUTH + SOUTH_WEST] = s + SOUTH;
			sqKnightPin[s + SOUTH + SOUTH_WEST][s] = s + SOUTH_WEST;

			//sqKnightNulDst[s + SOUTH + SOUTH_WEST][s + SOUTH] = s;
			//sqKnightNulDst[s][s + SOUTH_WEST] = s + SOUTH + SOUTH_WEST;

		}

		// KDirect_2
		if (r >= RANK_1 && f >= FILE_C)
		{
			sqKnightPin[s][s + SOUTH + WEST_WEST] = s + WEST;
			sqKnightPin[s + SOUTH + WEST_WEST][s] = s + SOUTH_WEST;

			//sqKnightNulDst[s + SOUTH + WEST_WEST][s + WEST] = s;
			//sqKnightNulDst[s][s + SOUTH_WEST] = s + SOUTH + WEST_WEST;


		}

		// KDirect_3
		if (r <= RANK_8 && f >= FILE_C)
		{
			sqKnightPin[s][s + NORTH + WEST_WEST] = s + WEST;
			sqKnightPin[s + NORTH + WEST_WEST][s] = s + NORTH_WEST;

			//sqKnightNulDst[s + NORTH + WEST_WEST][s + WEST] = s;
			//sqKnightNulDst[s][s + NORTH_WEST] = s + NORTH + WEST_WEST;

		}
		// KDirect_4
		if (r <= RANK_7 && f >= FILE_B)
		{
			sqKnightPin[s][s + NORTH + NORTH_WEST] = s + NORTH;
			sqKnightPin[s + NORTH + NORTH_WEST][s] = s + NORTH_WEST;

			//sqKnightNulDst[s + NORTH + NORTH_WEST][s + NORTH] = s;
			//sqKnightNulDst[s][s + NORTH_WEST] = s + NORTH + NORTH_WEST;
		}

		// KDirect_5
		if (r >= RANK_2 && f <= FILE_H)
		{
			sqKnightPin[s][s + SOUTH + SOUTH_EAST] = s + SOUTH;
			sqKnightPin[s + SOUTH + SOUTH_EAST][s] = s + SOUTH_EAST;

			//sqKnightNulDst[s + SOUTH + SOUTH_EAST][s + SOUTH] = s;
			//sqKnightNulDst[s][s + SOUTH_EAST] = s + SOUTH + SOUTH_EAST;
		}

		// KDirect_6
		if (r >= RANK_1 && f <= FILE_G)
		{
			sqKnightPin[s][s + SOUTH + EAST_EAST] = s + EAST;
			sqKnightPin[s + SOUTH + EAST_EAST][s] = s + SOUTH_EAST;

			//sqKnightNulDst[s + SOUTH + EAST_EAST][s + EAST] = s;
			//sqKnightNulDst[s][s + SOUTH_EAST] = s + SOUTH + EAST_EAST;
		}
		// KDirect_7
		if (r <= RANK_8 && f <= FILE_G)
		{
			sqKnightPin[s][s + NORTH + EAST_EAST] = s + EAST;
			sqKnightPin[s + NORTH + EAST_EAST][s] = s + NORTH_EAST;

			//sqKnightNulDst[s + NORTH + EAST_EAST][s + EAST] = s;
			//sqKnightNulDst[s][s + NORTH_EAST] = s + NORTH + EAST_EAST;
		}

		// KDirect_8
		if (r <= RANK_7 && f <= FILE_H)
		{
			sqKnightPin[s][s + NORTH + NORTH_EAST] = s + NORTH;
			sqKnightPin[s + NORTH + NORTH_EAST][s] = s + NORTH_EAST;

			//sqKnightNulDst[s + NORTH + NORTH_EAST][s + NORTH] = s;
			//sqKnightNulDst[s][s + NORTH_EAST] = s + NORTH + NORTH_EAST;
		}
	}


}

void BitboardCs::init_knight_pin_bc() {

	for (Square s = SQ_A0; s < SQUARE_NB; ++s)
	{
		Rank r = rank_of(s);
		File f = file_of(s);

		if (r <= RANK_1 && f <= FILE_B)
		{
			KnightPinFrom[s] = ((s + EAST) | (s + NORTH));
		}
		else if (r <= RANK_1 && f >= FILE_C && f <= FILE_G)
		{
			KnightPinFrom[s] = ((s + WEST) | (s + EAST) | (s + NORTH));
		}
		else if (r <= RANK_1 && f >= FILE_H)
		{
			KnightPinFrom[s] = ((s + WEST) | (s + NORTH));
		}
		else if (r >= RANK_2 && r <= RANK_7 && f <= FILE_B)
		{
			KnightPinFrom[s] = ((s + EAST) | (s + NORTH) | (s + SOUTH));
		}
		else if (r >= RANK_2 && r <= RANK_7 && f >= FILE_C && f <= FILE_G)
		{
			KnightPinFrom[s] = ((s + WEST) | (s + EAST) | (s + NORTH) | (s + SOUTH));
		}
		else if (r >= RANK_2 && r <= RANK_7 && f >= FILE_H)
		{
			KnightPinFrom[s] = ((s + WEST) | (s + NORTH) | (s + SOUTH));
		}
		else if (r >= RANK_8 && f <= FILE_B)
		{
			KnightPinFrom[s] = ((s + EAST) | (s + SOUTH));
		}
		else if (r >= RANK_8 && f >= FILE_C && f <= FILE_G)
		{
			KnightPinFrom[s] = ((s + WEST) | (s + EAST) | (s + SOUTH));
		}
		else if (r >= RANK_8 && f >= FILE_H)
		{
			KnightPinFrom[s] = ((s + WEST) | (s + SOUTH));
		}
	}


	for (Square s = SQ_A0; s < SQUARE_NB; ++s)
	{
		Rank r = rank_of(s);
		File f = file_of(s);

		if (r == RANK_0 && f >= FILE_B && f <= FILE_H)
		{
			KnightPinTo[s] = ((s + NORTH_WEST) | (s + NORTH_EAST));
		}
		else if (r == RANK_9 && f >= FILE_B && f <= FILE_H)
		{
			KnightPinTo[s] = ((s + SOUTH_WEST) | (s + SOUTH_EAST));
		}
		else if (r >= RANK_1 && r <= RANK_8 && f == FILE_A)
		{
			KnightPinTo[s] = ((s + NORTH_EAST) | (s + SOUTH_EAST));
		}
		else if (r >= RANK_1 && r <= RANK_8 && f == FILE_I)
		{
			KnightPinTo[s] = ((s + NORTH_WEST) | (s + SOUTH_WEST));
		}
		else {
			KnightPinTo[s] = ((s + NORTH_WEST) | (s + SOUTH_WEST) | (s + NORTH_EAST) | (s + SOUTH_EAST));
		}
	}


	KnightPinTo[SQ_A0] = SquareBC[SQ_B1];
	KnightPinTo[SQ_A9] = SquareBC[SQ_B8];
	KnightPinTo[SQ_I0] = SquareBC[SQ_H1];
	KnightPinTo[SQ_I9] = SquareBC[SQ_H8];

	KnightPinTo[SQ_B1] = (SQ_A2 | SQ_C0 | SQ_C2);
	KnightPinTo[SQ_B8] = (SQ_A7 | SQ_C9 | SQ_C7);
	KnightPinTo[SQ_H1] = (SQ_I2 | SQ_G0 | SQ_G2);
	KnightPinTo[SQ_H8] = (SQ_I7 | SQ_G9 | SQ_G7);

}

void BitboardCs::init_knight_reach_pin()
{
	//KnightReachedPinFrom = (BitboardC*) malloc(90*90*90*90*sizeof(BitboardC));
	//if (!KnightReachedPinFrom) {

	//	std::cerr << "Failed to allocate " << "for KnightReachedPinFrom " << std::endl;
	//	exit(EXIT_FAILURE);
	//}

	//KnightReachedPinTo = (BitboardC*)malloc(90 * 90 * 90 * 90 * sizeof(BitboardC));
	//if (!KnightReachedPinTo) {

	//	std::cerr << "Failed to allocate " << "for KnightReachedPinTo " << std::endl;
	//	exit(EXIT_FAILURE);
	//}

	for (Square s = SQ_A0; s < SQUARE_NB; ++s) {
		for (int i = 0; i < KnightPinTotal; ++i) {
			KnightReachedPinTo[s][i] = KnightReachedPinFrom[s][i] = PseudoAttacks[KNIGHT][s];
		}
	}
	for (Square s = SQ_A0; s < SQUARE_NB; ++s)
	{
		Rank r = rank_of(s);
		File f = file_of(s);
		//west , north, east , south
		Square pin[4] = { SQ_NONE, SQ_NONE, SQ_NONE, SQ_NONE };
		BitboardC bcPin[4] = { 0 };

		if (f >= FILE_C) {		//west 
			pin[0] = s + WEST;
			if (r >= RANK_1) {		//south
				bcPin[0] |= (s + SOUTH_WEST_WEST);
			}
			if (r <= RANK_8) {		//south
				bcPin[0] |= (s + NORTH_WEST_WEST);
			}
		}
		if (r <= RANK_7) {		//north 
			pin[1] = s + NORTH;
			if (f >= FILE_B) {		//west
				bcPin[1] |= (s + NORTH_NORTH_WEST);
			}
			if (f <= FILE_H) {		//east
				bcPin[1] |= (s + NORTH_NORTH_EAST);
			}
		}

		if (f <= FILE_G) {		//east 
			pin[2] = s + EAST;
			if (r >= RANK_1) {		//south
				bcPin[2] |= (s + SOUTH_EAST_EAST);
			}
			if (r <= RANK_8) {		//south
				bcPin[2] |= (s + NORTH_EAST_EAST);
			}
		}

		if (r >= RANK_2) {		//south 
			pin[3] = s + SOUTH;
			if (f >= FILE_B) {		//west
				bcPin[3] |= (s + SOUTH_SOUTH_WEST);
			}
			if (f <= FILE_H) {		//east
				bcPin[3] |= (s + SOUTH_SOUTH_EAST);
			}
		}

		calc_kinght_pin(s, pin, bcPin, KnightReachedPinFrom[s]);

		//westnorth, westsouth , eastnorth, eastsouth
		Square pinTo[4] = { SQ_NONE, SQ_NONE, SQ_NONE, SQ_NONE };
		BitboardC bcPinTo[4] = { 0 };

		if (f >= FILE_C && f <= FILE_G) {

			if (r >= RANK_2 && r <= RANK_7) {
				pinTo[0] = s + NORTH_WEST;
				bcPinTo[0] = (s + NORTH_NORTH_WEST) | (s + NORTH_WEST_WEST);
				pinTo[1] = s + SOUTH_WEST;
				bcPinTo[1] = (s + SOUTH_SOUTH_WEST) | (s + SOUTH_WEST_WEST);
				pinTo[2] = s + NORTH_EAST;
				bcPinTo[2] = (s + NORTH_NORTH_EAST) | (s + NORTH_EAST_EAST);
				pinTo[3] = s + SOUTH_EAST;
				bcPinTo[3] = (s + SOUTH_SOUTH_EAST) | (s + SOUTH_EAST_EAST);
			}
			else if (r == RANK_0) {
				pinTo[0] = s + NORTH_WEST;
				bcPinTo[0] = (s + NORTH_NORTH_WEST) | (s + NORTH_WEST_WEST);
				pinTo[2] = s + NORTH_EAST;
				bcPinTo[2] = (s + NORTH_NORTH_EAST) | (s + NORTH_EAST_EAST);
			}
			else if (r == RANK_1) {
				pinTo[0] = s + NORTH_WEST;
				bcPinTo[0] = (s + NORTH_NORTH_WEST) | (s + NORTH_WEST_WEST);
				pinTo[1] = s + SOUTH_WEST;
				bcPinTo[1] = bcZero | (s + SOUTH_WEST_WEST);
				pinTo[2] = s + NORTH_EAST;
				bcPinTo[2] = (s + NORTH_NORTH_EAST) | (s + NORTH_EAST_EAST);
				pinTo[3] = s + SOUTH_EAST;
				bcPinTo[3] = bcZero | (s + SOUTH_EAST_EAST);
			}
			else if (r == RANK_9) {
				pinTo[1] = s + SOUTH_WEST;
				bcPinTo[1] = (s + SOUTH_SOUTH_WEST) | (s + SOUTH_WEST_WEST);
				pinTo[3] = s + SOUTH_EAST;
				bcPinTo[3] = (s + SOUTH_SOUTH_EAST) | (s + SOUTH_EAST_EAST);
			}
			else if (r == RANK_8) {
				pinTo[0] = s + NORTH_WEST;
				bcPinTo[0] = bcZero | (s + NORTH_WEST_WEST);
				pinTo[1] = s + SOUTH_WEST;
				bcPinTo[1] = (s + SOUTH_SOUTH_WEST) | (s + SOUTH_WEST_WEST);
				pinTo[2] = s + NORTH_EAST;
				bcPinTo[2] = bcZero | (s + NORTH_EAST_EAST);
				pinTo[3] = s + SOUTH_EAST;
				bcPinTo[3] = (s + SOUTH_SOUTH_EAST) | (s + SOUTH_EAST_EAST);
			}
		}
		else if (f == FILE_A) {
			if (r >= RANK_2 && r <= RANK_7) {
				pinTo[2] = s + NORTH_EAST;
				bcPinTo[2] = (s + NORTH_NORTH_EAST) | (s + NORTH_EAST_EAST);
				pinTo[3] = s + SOUTH_EAST;
				bcPinTo[3] = (s + SOUTH_SOUTH_EAST) | (s + SOUTH_EAST_EAST);
			}
			else if (r == RANK_0) {
				pinTo[2] = s + NORTH_EAST;
				bcPinTo[2] = (s + NORTH_NORTH_EAST) | (s + NORTH_EAST_EAST);
			}
			else if (r == RANK_9) {
				pinTo[3] = s + SOUTH_EAST;
				bcPinTo[3] = (s + SOUTH_SOUTH_EAST) | (s + SOUTH_EAST_EAST);
			}
			else if (r == RANK_1) {
				pinTo[2] = s + NORTH_EAST;
				bcPinTo[2] = (s + NORTH_NORTH_EAST) | (s + NORTH_EAST_EAST);
				pinTo[3] = s + SOUTH_EAST;
				bcPinTo[3] = bcZero | (s + SOUTH_EAST_EAST);
			}
			else if (r == RANK_8) {
				pinTo[2] = s + NORTH_EAST;
				bcPinTo[2] = bcZero | (s + NORTH_EAST_EAST);
				pinTo[3] = s + SOUTH_EAST;
				bcPinTo[3] = (s + SOUTH_SOUTH_EAST) | (s + SOUTH_EAST_EAST);
			}
		}
		else if (f == FILE_I) {
			if (r >= RANK_2 && r <= RANK_7) {
				pinTo[0] = s + NORTH_WEST;
				bcPinTo[0] = (s + NORTH_NORTH_WEST) | (s + NORTH_WEST_WEST);
				pinTo[1] = s + SOUTH_WEST;
				bcPinTo[1] = (s + SOUTH_SOUTH_WEST) | (s + SOUTH_WEST_WEST);
			}
			else if (r == RANK_0) {
				pinTo[0] = s + NORTH_WEST;
				bcPinTo[0] = (s + NORTH_NORTH_WEST) | (s + NORTH_WEST_WEST);
			}
			else if (r == RANK_9) {
				pinTo[1] = s + SOUTH_WEST;
				bcPinTo[1] = (s + SOUTH_SOUTH_WEST) | (s + SOUTH_WEST_WEST);
			}
			else if (r == RANK_1) {
				pinTo[0] = s + NORTH_WEST;
				bcPinTo[0] = (s + NORTH_NORTH_WEST) | (s + NORTH_WEST_WEST);
				pinTo[1] = s + SOUTH_WEST;
				bcPinTo[1] = bcZero | (s + SOUTH_WEST_WEST);
			}
			else if (r == RANK_8) {
				pinTo[0] = s + NORTH_WEST;
				bcPinTo[0] = bcZero | (s + NORTH_WEST_WEST);
				pinTo[1] = s + SOUTH_WEST;
				bcPinTo[1] = (s + SOUTH_SOUTH_WEST) | (s + SOUTH_WEST_WEST);
			}
		}
		else if (f == FILE_B) {
			if (r >= RANK_2 && r <= RANK_7) {
				pinTo[0] = s + NORTH_WEST;
				bcPinTo[0] = bcZero | (s + NORTH_NORTH_WEST);
				pinTo[1] = s + SOUTH_WEST;
				bcPinTo[1] = bcZero | (s + SOUTH_SOUTH_WEST);
				pinTo[2] = s + NORTH_EAST;
				bcPinTo[2] = (s + NORTH_NORTH_EAST) | (s + NORTH_EAST_EAST);
				pinTo[3] = s + SOUTH_EAST;
				bcPinTo[3] = (s + SOUTH_SOUTH_EAST) | (s + SOUTH_EAST_EAST);
			}
			else if (r == RANK_0) {
				pinTo[0] = s + NORTH_WEST;
				bcPinTo[0] = bcZero | (s + NORTH_NORTH_WEST);
				pinTo[2] = s + NORTH_EAST;
				bcPinTo[2] = (s + NORTH_NORTH_EAST) | (s + NORTH_EAST_EAST);
			}
			else if (r == RANK_9) {
				pinTo[1] = s + SOUTH_WEST;
				bcPinTo[1] = bcZero | (s + SOUTH_SOUTH_WEST);
				pinTo[3] = s + SOUTH_EAST;
				bcPinTo[3] = (s + SOUTH_SOUTH_EAST) | (s + SOUTH_EAST_EAST);
			}
			else if (r == RANK_1) {
				pinTo[0] = s + NORTH_WEST;
				bcPinTo[0] = bcZero | (s + NORTH_NORTH_WEST);
				pinTo[2] = s + NORTH_EAST;
				bcPinTo[2] = (s + NORTH_NORTH_EAST) | (s + NORTH_EAST_EAST);
				pinTo[3] = s + SOUTH_EAST;
				bcPinTo[3] = bcZero | (s + SOUTH_EAST_EAST);

			}
			else if (r == RANK_8) {
				pinTo[1] = s + SOUTH_WEST;
				bcPinTo[1] = bcZero | (s + SOUTH_SOUTH_WEST);
				pinTo[2] = s + NORTH_EAST;
				bcPinTo[2] = bcZero | (s + NORTH_EAST_EAST);
				pinTo[3] = s + SOUTH_EAST;
				bcPinTo[3] = (s + SOUTH_SOUTH_EAST) | (s + SOUTH_EAST_EAST);
			}
		}
		else if (f == FILE_H) {
			if (r >= RANK_2 && r <= RANK_7) {
				pinTo[0] = s + NORTH_WEST;
				bcPinTo[0] = (s + NORTH_NORTH_WEST) | (s + NORTH_WEST_WEST);
				pinTo[1] = s + SOUTH_WEST;
				bcPinTo[1] = (s + SOUTH_SOUTH_WEST) | (s + SOUTH_WEST_WEST);
				pinTo[2] = s + NORTH_EAST;
				bcPinTo[2] = bcZero | (s + NORTH_NORTH_EAST);
				pinTo[3] = s + SOUTH_EAST;
				bcPinTo[3] = bcZero | (s + SOUTH_SOUTH_EAST);
			}
			else if (r == RANK_0) {
				pinTo[0] = s + NORTH_WEST;
				bcPinTo[0] = (s + NORTH_NORTH_WEST) | (s + NORTH_WEST_WEST);
				pinTo[2] = s + NORTH_EAST;
				bcPinTo[2] = bcZero | (s + NORTH_NORTH_EAST);
			}
			else if (r == RANK_9) {
				pinTo[1] = s + SOUTH_WEST;
				bcPinTo[1] = (s + SOUTH_SOUTH_WEST) | (s + SOUTH_WEST_WEST);
				pinTo[3] = s + SOUTH_EAST;
				bcPinTo[3] = bcZero | (s + SOUTH_SOUTH_EAST);
			}
			else if (r == RANK_1) {
				pinTo[0] = s + NORTH_WEST;
				bcPinTo[0] = (s + NORTH_NORTH_WEST) | (s + NORTH_WEST_WEST);
				pinTo[1] = s + SOUTH_WEST;
				bcPinTo[1] = bcZero | (s + SOUTH_WEST_WEST);
				pinTo[2] = s + NORTH_EAST;
				bcPinTo[2] = bcZero | (s + NORTH_NORTH_EAST);

			}
			else if (r == RANK_8) {
				pinTo[0] = s + NORTH_WEST;
				bcPinTo[0] = bcZero | (s + NORTH_WEST_WEST);
				pinTo[1] = s + SOUTH_WEST;
				bcPinTo[1] = (s + SOUTH_SOUTH_WEST) | (s + SOUTH_WEST_WEST);
				pinTo[3] = s + SOUTH_EAST;
				bcPinTo[3] = bcZero | (s + SOUTH_SOUTH_EAST);
			}
		}

		calc_kinght_pin(s, pinTo, bcPinTo, KnightReachedPinTo[s]);

	}


}


void BitboardCs::init_knight_pin()
{
	init_knight_pin_square();
	init_knight_pin_bc();
	init_knight_reach_pin();
}


void BitboardCs::init_bishop_pin() {
	BishopPin[SQ_A2] = SQ_B1 | SQ_B3;
	BishopPin[SQ_C0] = SQ_B1 | SQ_D1;
	BishopPin[SQ_C4] = SQ_D3 | SQ_B3;
	BishopPin[SQ_E2] = SQ_D1 | SQ_D3 | SQ_F1 | SQ_F3;
	BishopPin[SQ_G0] = SQ_H1 | SQ_F1;
	BishopPin[SQ_G4] = SQ_F3 | SQ_H3;
	BishopPin[SQ_I2] = SQ_H1 | SQ_H3;


#ifdef VMPROTECT
	VMProtectBeginUltraLockByKey("init_bpin");
#endif
	BishopPin[~SQ_A2] = ~SQ_B1 | ~SQ_B3;
	BishopPin[~SQ_C0] = ~SQ_B1 | ~SQ_D1;
#ifdef VMPROTECT
	VMProtectEnd();
#endif
	BishopPin[~SQ_C4] = ~SQ_D3 | ~SQ_B3;
	BishopPin[~SQ_E2] = ~SQ_D1 | ~SQ_D3 | ~SQ_F1 | ~SQ_F3;
	BishopPin[~SQ_G0] = ~SQ_H1 | ~SQ_F1;
	BishopPin[~SQ_G4] = ~SQ_F3 | ~SQ_H3;
	BishopPin[~SQ_I2] = ~SQ_H1 | ~SQ_H3;


}


void BitboardCs::init_bishop_reach_pin() {


	for (int i = 0; i < BishopPinTotal; ++i) {
		BishopReachedPin[SQ_A2][i] = PseudoAttacks[BISHOP][SQ_A2];
		BishopReachedPin[SQ_C0][i] = PseudoAttacks[BISHOP][SQ_C0];
		BishopReachedPin[SQ_C4][i] = PseudoAttacks[BISHOP][SQ_C4];
		BishopReachedPin[SQ_E2][i] = PseudoAttacks[BISHOP][SQ_E2];
		BishopReachedPin[SQ_G0][i] = PseudoAttacks[BISHOP][SQ_G0];
		BishopReachedPin[SQ_G4][i] = PseudoAttacks[BISHOP][SQ_G4];
		BishopReachedPin[SQ_I2][i] = PseudoAttacks[BISHOP][SQ_I2];

		BishopReachedPin[~SQ_A2][i] = PseudoAttacks[BISHOP][~SQ_A2];
		BishopReachedPin[~SQ_C0][i] = PseudoAttacks[BISHOP][~SQ_C0];
		BishopReachedPin[~SQ_C4][i] = PseudoAttacks[BISHOP][~SQ_C4];
		BishopReachedPin[~SQ_E2][i] = PseudoAttacks[BISHOP][~SQ_E2];
		BishopReachedPin[~SQ_G0][i] = PseudoAttacks[BISHOP][~SQ_G0];
		BishopReachedPin[~SQ_G4][i] = PseudoAttacks[BISHOP][~SQ_G4];
		BishopReachedPin[~SQ_I2][i] = PseudoAttacks[BISHOP][~SQ_I2];


	}
#ifdef VMPROTECT
	VMProtectBeginUltra("init_bspin");
#endif

	BishopReachedPin[SQ_A2][SQ_B1] = bcZero | SQ_C4;
	BishopReachedPin[SQ_A2][SQ_B3] = bcZero | SQ_C0;
	BishopReachedPin[SQ_I2][SQ_H1] = bcZero | SQ_G4;
	BishopReachedPin[SQ_I2][SQ_H3] = bcZero | SQ_G0;
#ifdef VMPROTECT
	VMProtectEnd();
#endif

	BishopReachedPin[SQ_C0][SQ_B1] = bcZero | SQ_E2;
	BishopReachedPin[SQ_C0][SQ_D1] = bcZero | SQ_A2;
	BishopReachedPin[SQ_G0][SQ_H1] = bcZero | SQ_E2;
	BishopReachedPin[SQ_G0][SQ_F1] = bcZero | SQ_I2;

	BishopReachedPin[SQ_C4][SQ_B3] = bcZero | SQ_E2;
	BishopReachedPin[SQ_C4][SQ_D3] = bcZero | SQ_A2;
	BishopReachedPin[SQ_G4][SQ_H3] = bcZero | SQ_E2;
	BishopReachedPin[SQ_G4][SQ_F3] = bcZero | SQ_I2;

	BishopReachedPin[SQ_E2][SQ_D1] = SQ_C4 | SQ_G0 | SQ_G4;
	BishopReachedPin[SQ_E2][SQ_F1] = SQ_C0 | SQ_C4 | SQ_G4;
	BishopReachedPin[SQ_E2][SQ_D3] = SQ_C0 | SQ_G0 | SQ_G4;
	BishopReachedPin[SQ_E2][SQ_F3] = SQ_C0 | SQ_C4 | SQ_G0;

	BishopReachedPin[SQ_E2][total_bpsquare(SquareBB[SQ_D1] | SquareBB[SQ_F1])] = SQ_C4 | SQ_G4;
	BishopReachedPin[SQ_E2][total_bpsquare(SquareBB[SQ_D1] | SquareBB[SQ_D3])] = SQ_G0 | SQ_G4;
	BishopReachedPin[SQ_E2][total_bpsquare(SquareBB[SQ_D1] | SquareBB[SQ_F3])] = SQ_C4 | SQ_G0;
	BishopReachedPin[SQ_E2][total_bpsquare(SquareBB[SQ_F1] | SquareBB[SQ_D3])] = SQ_C0 | SQ_G4;
	BishopReachedPin[SQ_E2][total_bpsquare(SquareBB[SQ_F1] | SquareBB[SQ_F3])] = SQ_C0 | SQ_C4;
	BishopReachedPin[SQ_E2][total_bpsquare(SquareBB[SQ_D3] | SquareBB[SQ_F3])] = SQ_C0 | SQ_G0;

	BishopReachedPin[SQ_E2][total_bpsquare(SquareBB[SQ_D1] | SquareBB[SQ_F1] | SquareBB[SQ_D3])] = bcZero | SQ_G4;
	BishopReachedPin[SQ_E2][total_bpsquare(SquareBB[SQ_D1] | SquareBB[SQ_F1] | SquareBB[SQ_F3])] = bcZero | SQ_C4;
	BishopReachedPin[SQ_E2][total_bpsquare(SquareBB[SQ_D1] | SquareBB[SQ_D3] | SquareBB[SQ_F3])] = bcZero | SQ_G0;
	BishopReachedPin[SQ_E2][total_bpsquare(SquareBB[SQ_F1] | SquareBB[SQ_D3] | SquareBB[SQ_F3])] = bcZero | SQ_C0;

	BishopReachedPin[~SQ_A2][~SQ_B1] = (bcZero | ~SQ_C4);
	BishopReachedPin[~SQ_A2][~SQ_B3] = (bcZero | ~SQ_C0);
	BishopReachedPin[~SQ_I2][~SQ_H1] = (bcZero | ~SQ_G4);
	BishopReachedPin[~SQ_I2][~SQ_H3] = (bcZero | ~SQ_G0);

	BishopReachedPin[~SQ_C0][~SQ_B1] = (bcZero | ~SQ_E2);
	BishopReachedPin[~SQ_C0][~SQ_D1] = (bcZero | ~SQ_A2);
	BishopReachedPin[~SQ_G0][~SQ_H1] = (bcZero | ~SQ_E2);
	BishopReachedPin[~SQ_G0][~SQ_F1] = (bcZero | ~SQ_I2);

	BishopReachedPin[~SQ_C4][~SQ_B3] = (bcZero | ~SQ_E2);
	BishopReachedPin[~SQ_C4][~SQ_D3] = (bcZero | ~SQ_A2);
	BishopReachedPin[~SQ_G4][~SQ_H3] = (bcZero | ~SQ_E2);
	BishopReachedPin[~SQ_G4][~SQ_F3] = (bcZero | ~SQ_I2);

	BishopReachedPin[SQ_E7][~SQ_D1] = (~SQ_C4 | ~SQ_G0 | ~SQ_G4);
	BishopReachedPin[SQ_E7][~SQ_F1] = (~SQ_C0 | ~SQ_C4 | ~SQ_G4);
	BishopReachedPin[SQ_E7][~SQ_D3] = (~SQ_C0 | ~SQ_G0 | ~SQ_G4);
	BishopReachedPin[SQ_E7][~SQ_F3] = (~SQ_C0 | ~SQ_C4 | ~SQ_G0);


	BishopReachedPin[SQ_E7][total_bpsquare(SquareBB[SQ_D1] | SquareBB[SQ_F1])] = (~SQ_C4 | ~SQ_G4);
	BishopReachedPin[SQ_E7][total_bpsquare(SquareBB[SQ_D1] | SquareBB[SQ_D3])] = (~SQ_G0 | ~SQ_G4);
	BishopReachedPin[SQ_E7][total_bpsquare(SquareBB[SQ_D1] | SquareBB[SQ_F3])] = (~SQ_C4 | ~SQ_G0);
	BishopReachedPin[SQ_E7][total_bpsquare(SquareBB[SQ_F1] | SquareBB[SQ_D3])] = (~SQ_C0 | ~SQ_G4);
	BishopReachedPin[SQ_E7][total_bpsquare(SquareBB[SQ_F1] | SquareBB[SQ_F3])] = (~SQ_C0 | ~SQ_C4);
	BishopReachedPin[SQ_E7][total_bpsquare(SquareBB[SQ_D3] | SquareBB[SQ_F3])] = (~SQ_C0 | ~SQ_G0);

	BishopReachedPin[SQ_E7][total_bpsquare(SquareBB[SQ_D1] | SquareBB[SQ_F1] | SquareBB[SQ_D3])] = (bcZero | ~SQ_G4);
	BishopReachedPin[SQ_E7][total_bpsquare(SquareBB[SQ_D1] | SquareBB[SQ_F1] | SquareBB[SQ_F3])] = (bcZero | ~SQ_C4);
	BishopReachedPin[SQ_E7][total_bpsquare(SquareBB[SQ_D1] | SquareBB[SQ_D3] | SquareBB[SQ_F3])] = (bcZero | ~SQ_G0);
	BishopReachedPin[SQ_E7][total_bpsquare(SquareBB[SQ_F1] | SquareBB[SQ_D3] | SquareBB[SQ_F3])] = (bcZero | ~SQ_C0);


}

//
//void BitboardCs::init_knight_center_pin(const Square s)
//{
//	SquarePair sp;
//
//	sp.s1 = s + SOUTH_WEST + WEST; sp.s2 = s + SOUTH_WEST + SOUTH;
//	pairKnightPin[s][s + SOUTH_WEST] = sp;
//
//	sp.s1 = s + NORTH_WEST + WEST; sp.s2 = s + NORTH_WEST + NORTH;
//	pairKnightPin[s][s + NORTH_WEST] = sp;
//
//	sp.s1 = s + SOUTH_EAST + EAST; sp.s2 = s + SOUTH_EAST + SOUTH;
//	pairKnightPin[s][s + SOUTH_EAST] = sp;
//
//	sp.s1 = s + NORTH_EAST + EAST; sp.s2 = s + NORTH_EAST + NORTH;
//	pairKnightPin[s][s + NORTH_EAST] = sp;
//}

////���A�е��� �����������±߽����
//void BitboardCs::init_knight_lefta_pin( const Square s )
//{
//	SquarePair sp;
//
//	sp.s1 = s + SOUTH_EAST + EAST; sp.s2 = s + SOUTH_EAST + SOUTH;
//	pairKnightPin[s][s + SOUTH_EAST] = sp;
//
//	sp.s1 = s + NORTH_EAST + EAST; sp.s2 = s + NORTH_EAST + NORTH;
//	pairKnightPin[s][s + NORTH_EAST] = sp;
//
//}

//
//void BitboardCs::init_knight_leftb_pin( const Square s )
//{
//	SquarePair sp;
//
//	sp.s1 = s + SOUTH_WEST + SOUTH  ; sp.s2 = SQ_NONE ;
//	pairKnightPin[s][s + SOUTH_WEST] = sp;
//
//	sp.s1 = s + NORTH_WEST + NORTH ; sp.s2 = SQ_NONE;
//	pairKnightPin[s][s + NORTH_WEST] = sp;
//
//
//	sp.s1 = s + SOUTH_EAST + EAST; sp.s2 = s + SOUTH_EAST + SOUTH;
//	pairKnightPin[s][s + SOUTH_EAST] = sp;
//
//	sp.s1 = s + NORTH_EAST + EAST; sp.s2 = s + NORTH_EAST + NORTH;
//	pairKnightPin[s][s + NORTH_EAST] = sp;
//
//}
//
//
//void BitboardCs::init_knight_righti_pin( const Square s )
//{
//	SquarePair sp;
//
//	sp.s1 = s + SOUTH_WEST + WEST; sp.s2 = s + SOUTH_WEST + SOUTH;
//	pairKnightPin[s][s + SOUTH_WEST] = sp;
//
//	sp.s1 = s + NORTH_WEST + WEST; sp.s2 = s + NORTH_WEST + NORTH;
//	pairKnightPin[s][s + NORTH_WEST] = sp;
//}
//
//void BitboardCs::init_knight_righth_pin( const Square s )
//{
//	SquarePair sp;
//
//	sp.s1 = s + SOUTH_EAST + SOUTH  ; sp.s2 = SQ_NONE ;
//	pairKnightPin[s][s + SOUTH_EAST] = sp;
//
//	sp.s1 = s + NORTH_EAST + NORTH ; sp.s2 = SQ_NONE;
//	pairKnightPin[s][s + NORTH_EAST] = sp;
//
//
//	sp.s1 = s + SOUTH_WEST + WEST; sp.s2 = s + SOUTH_WEST + SOUTH;
//	pairKnightPin[s][s + SOUTH_WEST] = sp;
//
//	sp.s1 = s + NORTH_WEST + WEST; sp.s2 = s + NORTH_WEST + NORTH;
//	pairKnightPin[s][s + NORTH_WEST] = sp;
//}
void BitboardCs::init_move_pawn()
{
	for (Square s = SQ_A0; s < SQUARE_NB; ++s) {
		File f = file_of(s);
		Rank r = rank_of(s);
		if (r == RANK_3 || r == RANK_4) {
			if (f == FILE_A || f == FILE_C || f == FILE_E || f == FILE_G || f == FILE_I)
				PawnAttackingBC[WHITE][s] = SquareBC[(s + NORTH)];
		}
		else if (r == RANK_5 || r == RANK_6) {
			if (f == FILE_A || f == FILE_C || f == FILE_E || f == FILE_G || f == FILE_I)
				PawnAttackingBC[BLACK][s] = SquareBC[(s + SOUTH)];
		}

		if (r >= RANK_5 && r <= RANK_8) {
			if (f > FILE_A && f < FILE_I)
				PawnAttackingBC[WHITE][s] = SquareBC[(s + NORTH)] | SquareBC[(s + WEST)] | SquareBC[(s + EAST)];
			else if (f == FILE_A)
				PawnAttackingBC[WHITE][s] = SquareBC[(s + NORTH)] | SquareBC[(s + EAST)];
			else if (f == FILE_I)
				PawnAttackingBC[WHITE][s] = SquareBC[(s + NORTH)] | SquareBC[(s + WEST)];
		}
		else if (r == RANK_9) {
			if (f > FILE_A && f < FILE_I)
				PawnAttackingBC[WHITE][s] = SquareBC[(s + WEST)] | SquareBC[(s + EAST)];
			else if (f == FILE_A)
				PawnAttackingBC[WHITE][s] = SquareBC[(s + EAST)];
			else if (f == FILE_I)
				PawnAttackingBC[WHITE][s] = SquareBC[(s + WEST)];

		}

		if (r >= RANK_1 && r <= RANK_4) {
			if (f > FILE_A && f < FILE_I)
				PawnAttackingBC[BLACK][s] = SquareBC[(s + SOUTH)] | SquareBC[(s + WEST)] | SquareBC[(s + EAST)];
			else if (f == FILE_A)
				PawnAttackingBC[BLACK][s] = SquareBC[(s + SOUTH)] | SquareBC[(s + EAST)];
			else if (f == FILE_I)
				PawnAttackingBC[BLACK][s] = SquareBC[(s + SOUTH)] | SquareBC[(s + WEST)];
		}
		else if (r == RANK_0) {
			if (f > FILE_A && f < FILE_I)
				PawnAttackingBC[BLACK][s] = SquareBC[(s + WEST)] | SquareBC[(s + EAST)];
			else if (f == FILE_A)
				PawnAttackingBC[BLACK][s] = SquareBC[(s + EAST)];
			else if (f == FILE_I)
				PawnAttackingBC[BLACK][s] = SquareBC[(s + WEST)];

		}

		if (r == RANK_4) {
			if (f == FILE_A || f == FILE_C || f == FILE_E || f == FILE_G || f == FILE_I)
				PawnAttackedBC[WHITE][s] = SquareBC[(s + SOUTH)];
		}
		else if (r == RANK_5) {
			if (f == FILE_A)
				PawnAttackedBC[WHITE][s] = SquareBC[(s + SOUTH)] | SquareBC[(s + EAST)];
			else if (f == FILE_B || f == FILE_D || f == FILE_F || f == FILE_H)
				PawnAttackedBC[WHITE][s] = SquareBC[(s + WEST)] | SquareBC[(s + EAST)];
			else if (f == FILE_C || f == FILE_E || f == FILE_G)
				PawnAttackedBC[WHITE][s] = SquareBC[(s + SOUTH)] | SquareBC[(s + WEST)] | SquareBC[(s + EAST)];
			if (f == FILE_I)
				PawnAttackedBC[WHITE][s] = SquareBC[(s + SOUTH)] | SquareBC[(s + WEST)];
		}
		else if (r >= RANK_6 && r <= RANK_9) {
			if (f > FILE_A && f < FILE_I)
				PawnAttackedBC[WHITE][s] = SquareBC[(s + SOUTH)] | SquareBC[(s + WEST)] | SquareBC[(s + EAST)];
			else if (f == FILE_A)
				PawnAttackedBC[WHITE][s] = SquareBC[(s + SOUTH)] | SquareBC[(s + EAST)];
			else if (f == FILE_I)
				PawnAttackedBC[WHITE][s] = SquareBC[(s + SOUTH)] | SquareBC[(s + WEST)];
		}

		if (r == RANK_5) {
			if (f == FILE_A || f == FILE_C || f == FILE_E || f == FILE_G || f == FILE_I)
				PawnAttackedBC[BLACK][s] = SquareBC[(s + NORTH)];
		}
		else if (r == RANK_4) {
			if (f == FILE_A)
				PawnAttackedBC[BLACK][s] = SquareBC[(s + NORTH)] | SquareBC[(s + EAST)];
			else if (f == FILE_B || f == FILE_D || f == FILE_F || f == FILE_H)
				PawnAttackedBC[BLACK][s] = SquareBC[(s + WEST)] | SquareBC[(s + EAST)];
			else if (f == FILE_C || f == FILE_E || f == FILE_G)
				PawnAttackedBC[BLACK][s] = SquareBC[(s + NORTH)] | SquareBC[(s + WEST)] | SquareBC[(s + EAST)];
			if (f == FILE_I)
				PawnAttackedBC[BLACK][s] = SquareBC[(s + NORTH)] | SquareBC[(s + WEST)];
		}
		else if (r <= RANK_3) {
			if (f > FILE_A && f < FILE_I)
				PawnAttackedBC[BLACK][s] = SquareBC[(s + NORTH)] | SquareBC[(s + WEST)] | SquareBC[(s + EAST)];
			else if (f == FILE_A)
				PawnAttackedBC[BLACK][s] = SquareBC[(s + NORTH)] | SquareBC[(s + EAST)];
			else if (f == FILE_I)
				PawnAttackedBC[BLACK][s] = SquareBC[(s + NORTH)] | SquareBC[(s + WEST)];
		}

	}
}


void BitboardCs::init_stepattacks_knight()
{
	BitboardC tmp = bcZero;

	// A1
	tmp.m128i_u64[0] = SquareBB[SQ_B2] | SquareBB[SQ_C1];
	PseudoAttacks[KNIGHT][SQ_A0] = tmp;

	// B1
	tmp.m128i_u64[0] = SquareBB[SQ_A2] | SquareBB[SQ_C2] | SquareBB[SQ_D1];
	PseudoAttacks[KNIGHT][SQ_B0] = tmp;

	// C1-G1
	for (Square s = SQ_C0; s <= SQ_G0; ++s)
	{
		computer_knight_4(s);
	}

	// C10-G10
	for (Square s = SQ_C9; s <= SQ_G9; ++s)
	{
		computer_knight_4(s);
	}

	// H1
	tmp.m128i_u64[0] = SquareBB[SQ_F1] | SquareBB[SQ_G2] | SquareBB[SQ_I2];
	PseudoAttacks[KNIGHT][SQ_H0] = tmp;

	// I1
	tmp.m128i_u64[0] = SquareBB[SQ_G1] | SquareBB[SQ_H2];
	PseudoAttacks[KNIGHT][SQ_I0] = tmp;

	// A2
	tmp.m128i_u64[0] = SquareBB[SQ_B3] | SquareBB[SQ_C0] | SquareBB[SQ_C2];
	PseudoAttacks[KNIGHT][SQ_A1] = tmp;

	// B2
	tmp.m128i_u64[0] = SquareBB[SQ_A3] | SquareBB[SQ_D0] | SquareBB[SQ_D2] | SquareBB[SQ_C3];
	PseudoAttacks[KNIGHT][SQ_B1] = tmp;

	// C2-G2
	for (Square s = SQ_C1; s <= SQ_G1; ++s)
	{
		computer_knight_6(s);
	}
	// C9-G9
	for (Square s = SQ_C8; s <= SQ_G8; ++s)
	{
		computer_knight_6(s);
	}
	// H2
	tmp.m128i_u64[0] = SquareBB[SQ_F0] | SquareBB[SQ_F2] | SquareBB[SQ_G3] | SquareBB[SQ_I3];
	PseudoAttacks[KNIGHT][SQ_H1] = tmp;

	// I2
	tmp.m128i_u64[0] = SquareBB[SQ_G0] | SquareBB[SQ_G2] | SquareBB[SQ_H3];
	PseudoAttacks[KNIGHT][SQ_I1] = tmp;

	// A3
	tmp.m128i_u64[0] = SquareBB[SQ_B0] | SquareBB[SQ_C1] | SquareBB[SQ_C3] | SquareBB[SQ_B4];
	PseudoAttacks[KNIGHT][SQ_A2] = tmp;

	// B3
	tmp.m128i_u64[0] = SquareBB[SQ_A0] | SquareBB[SQ_A4] | SquareBB[SQ_C0] | SquareBB[SQ_D1]
		| SquareBB[SQ_D3] | SquareBB[SQ_C4];
	PseudoAttacks[KNIGHT][SQ_B2] = tmp;

	// C3-G3
	for (Square s = SQ_C2; s <= SQ_G2; ++s)
	{
		computer_knight_full_nocross(s);
	}
	// C8-G8
	for (Square s = SQ_C7; s <= SQ_G7; ++s)
	{
		computer_knight_full_nocross(s);
	}

	// H3
	tmp.m128i_u64[0] = SquareBB[SQ_G0] | SquareBB[SQ_F1] | SquareBB[SQ_F3] | SquareBB[SQ_G4]
		| SquareBB[SQ_I0] | SquareBB[SQ_I4];
	PseudoAttacks[KNIGHT][SQ_H2] = tmp;

	// I3
	tmp.m128i_u64[0] = SquareBB[SQ_H0] | SquareBB[SQ_G1] | SquareBB[SQ_G3] | SquareBB[SQ_H4];
	PseudoAttacks[KNIGHT][SQ_I2] = tmp;

	// A4
	tmp.m128i_u64[0] = SquareBB[SQ_B1] | SquareBB[SQ_C2] | SquareBB[SQ_C4];
	tmp.m128i_u64[1] = SquareBB[SQ_B4];
	PseudoAttacks[KNIGHT][SQ_A3] = tmp;

	// B4
	tmp.m128i_u64[0] = SquareBB[SQ_A1] | SquareBB[SQ_C1] | SquareBB[SQ_D2] | SquareBB[SQ_D4];
	tmp.m128i_u64[1] = SquareBB[SQ_A4] | SquareBB[SQ_C4];
	PseudoAttacks[KNIGHT][SQ_B3] = tmp;

	// C4-G4
	for (Square s = SQ_C3; s <= SQ_G3; ++s)
	{
		computer_knight_full_cross2(s);
	}
	// C7-G7
	for (Square s = SQ_C6; s <= SQ_G6; ++s)
	{
		computer_knight_full_cross2(s);
	}

	// H4
	tmp.m128i_u64[0] = SquareBB[SQ_G1] | SquareBB[SQ_F2] | SquareBB[SQ_F4] | SquareBB[SQ_I1];
	tmp.m128i_u64[1] = SquareBB[SQ_G4] | SquareBB[SQ_I4];
	PseudoAttacks[KNIGHT][SQ_H3] = tmp;

	// I4
	tmp.m128i_u64[0] = SquareBB[SQ_H1] | SquareBB[SQ_G2] | SquareBB[SQ_G4];
	tmp.m128i_u64[1] = SquareBB[SQ_H4];
	PseudoAttacks[KNIGHT][SQ_I3] = tmp;

	// A5
	tmp.m128i_u64[0] = SquareBB[SQ_B2] | SquareBB[SQ_C3];
	tmp.m128i_u64[1] = SquareBB[SQ_C4] | SquareBB[SQ_B3];
	PseudoAttacks[KNIGHT][SQ_A4] = tmp;

	// B5
	tmp.m128i_u64[0] = SquareBB[SQ_A2] | SquareBB[SQ_C2] | SquareBB[SQ_D3];
	tmp.m128i_u64[1] = SquareBB[SQ_A3] | SquareBB[SQ_C3] | SquareBB[SQ_D4];
	PseudoAttacks[KNIGHT][SQ_B4] = tmp;

	// C5-G5
	for (Square s = SQ_C4; s <= SQ_G4; ++s)
	{
		computer_knight_full_cross4(s);
	}
	// C6-G6
	for (Square s = SQ_C5; s <= SQ_G5; ++s)
	{
		computer_knight_full_cross4(s);
	}

#ifdef VMPROTECT
	VMProtectBeginUltraLockByKey("init1");
#endif
	// H5
	tmp.m128i_u64[0] = SquareBB[SQ_G2] | SquareBB[SQ_F3] | SquareBB[SQ_I2];
	tmp.m128i_u64[1] = SquareBB[SQ_G3] | SquareBB[SQ_I3] | SquareBB[SQ_F4];
	PseudoAttacks[KNIGHT][SQ_H4] = tmp;

	// I5
	tmp.m128i_u64[0] = SquareBB[SQ_H2] | SquareBB[SQ_G3];
	tmp.m128i_u64[1] = SquareBB[SQ_G4] | SquareBB[SQ_H3];
	PseudoAttacks[KNIGHT][SQ_I4] = tmp;
#ifdef VMPROTECT
	VMProtectEnd();
#endif

	// A6
	tmp.m128i_u64[1] = SquareBB[SQ_B2] | SquareBB[SQ_C3];
	tmp.m128i_u64[0] = SquareBB[SQ_C4] | SquareBB[SQ_B3];
	PseudoAttacks[KNIGHT][SQ_A5] = tmp;

	// B6
	tmp.m128i_u64[1] = SquareBB[SQ_A2] | SquareBB[SQ_C2] | SquareBB[SQ_D3];
	tmp.m128i_u64[0] = SquareBB[SQ_A3] | SquareBB[SQ_C3] | SquareBB[SQ_D4];
	PseudoAttacks[KNIGHT][SQ_B5] = tmp;

	// H6
	tmp.m128i_u64[1] = SquareBB[SQ_G2] | SquareBB[SQ_F3] | SquareBB[SQ_I2];
	tmp.m128i_u64[0] = SquareBB[SQ_G3] | SquareBB[SQ_I3] | SquareBB[SQ_F4];
	PseudoAttacks[KNIGHT][SQ_H5] = tmp;

	// I6
	tmp.m128i_u64[1] = SquareBB[SQ_H2] | SquareBB[SQ_G3];
	tmp.m128i_u64[0] = SquareBB[SQ_G4] | SquareBB[SQ_H3];
	PseudoAttacks[KNIGHT][SQ_I5] = tmp;

	// A7
	tmp.m128i_u64[1] = SquareBB[SQ_B1] | SquareBB[SQ_C2] | SquareBB[SQ_C4];
	tmp.m128i_u64[0] = SquareBB[SQ_B4];
	PseudoAttacks[KNIGHT][SQ_A6] = tmp;

	// B7
	tmp.m128i_u64[1] = SquareBB[SQ_A1] | SquareBB[SQ_C1] | SquareBB[SQ_D2] | SquareBB[SQ_D4];
	tmp.m128i_u64[0] = SquareBB[SQ_A4] | SquareBB[SQ_C4];
	PseudoAttacks[KNIGHT][SQ_B6] = tmp;

	// H7
	tmp.m128i_u64[1] = SquareBB[SQ_G1] | SquareBB[SQ_F2] | SquareBB[SQ_F4] | SquareBB[SQ_I1];
	tmp.m128i_u64[0] = SquareBB[SQ_G4] | SquareBB[SQ_I4];
	PseudoAttacks[KNIGHT][SQ_H6] = tmp;

	// I7
	tmp.m128i_u64[1] = SquareBB[SQ_H1] | SquareBB[SQ_G2] | SquareBB[SQ_G4];
	tmp.m128i_u64[0] = SquareBB[SQ_H4];
	PseudoAttacks[KNIGHT][SQ_I6] = tmp;


	tmp.m128i_u64[0] = 0;
	// A8

	tmp.m128i_u64[1] = SquareBB[SQ_B0] | SquareBB[SQ_C1] | SquareBB[SQ_C3] | SquareBB[SQ_B4];
	PseudoAttacks[KNIGHT][SQ_A7] = tmp;

	// B8
	tmp.m128i_u64[1] = SquareBB[SQ_A0] | SquareBB[SQ_A4] | SquareBB[SQ_C0] | SquareBB[SQ_D1]
		| SquareBB[SQ_D3] | SquareBB[SQ_C4];
	PseudoAttacks[KNIGHT][SQ_B7] = tmp;


	// H8
	tmp.m128i_u64[1] = SquareBB[SQ_G0] | SquareBB[SQ_F1] | SquareBB[SQ_F3] | SquareBB[SQ_G4]
		| SquareBB[SQ_I0] | SquareBB[SQ_I4];
	PseudoAttacks[KNIGHT][SQ_H7] = tmp;

	// I8
	tmp.m128i_u64[1] = SquareBB[SQ_H0] | SquareBB[SQ_G1] | SquareBB[SQ_G3] | SquareBB[SQ_H4];
	PseudoAttacks[KNIGHT][SQ_I7] = tmp;

	// A9
	tmp.m128i_u64[1] = SquareBB[SQ_B3] | SquareBB[SQ_C0] | SquareBB[SQ_C2];
	PseudoAttacks[KNIGHT][SQ_A8] = tmp;

	// B9
	tmp.m128i_u64[1] = SquareBB[SQ_A3] | SquareBB[SQ_D0] | SquareBB[SQ_D2] | SquareBB[SQ_C3];
	PseudoAttacks[KNIGHT][SQ_B8] = tmp;

	// H9
	tmp.m128i_u64[1] = SquareBB[SQ_F0] | SquareBB[SQ_F2] | SquareBB[SQ_G3] | SquareBB[SQ_I3];
	PseudoAttacks[KNIGHT][SQ_H8] = tmp;

	// I9
	tmp.m128i_u64[1] = SquareBB[SQ_G0] | SquareBB[SQ_G2] | SquareBB[SQ_H3];
	PseudoAttacks[KNIGHT][SQ_I8] = tmp;

	// A10
	tmp.m128i_u64[1] = SquareBB[SQ_B2] | SquareBB[SQ_C1];
	PseudoAttacks[KNIGHT][SQ_A9] = tmp;

	// B10
	tmp.m128i_u64[1] = SquareBB[SQ_A2] | SquareBB[SQ_C2] | SquareBB[SQ_D1];
	PseudoAttacks[KNIGHT][SQ_B9] = tmp;

	// H10
	tmp.m128i_u64[1] = SquareBB[SQ_F1] | SquareBB[SQ_G2] | SquareBB[SQ_I2];
	PseudoAttacks[KNIGHT][SQ_H9] = tmp;

	// I10
	tmp.m128i_u64[1] = SquareBB[SQ_G1] | SquareBB[SQ_H2];
	PseudoAttacks[KNIGHT][SQ_I9] = tmp;


}


void BitboardCs::init_stepattacks_bishop()
{

	PseudoAttacks[BISHOP][SQ_A2] = SquareBC[SQ_C0] | SquareBC[SQ_C4];
	PseudoAttacks[BISHOP][SQ_A7] = SquareBC[~SQ_C0] | SquareBC[~SQ_C4];

	PseudoAttacks[BISHOP][SQ_C0] = SquareBC[SQ_A2] | SquareBC[SQ_E2];
	PseudoAttacks[BISHOP][SQ_C9] = SquareBC[~SQ_A2] | SquareBC[~SQ_E2];

	PseudoAttacks[BISHOP][SQ_E2] = SquareBC[SQ_C0] | SquareBC[SQ_G0] | SquareBC[SQ_C4] | SquareBC[SQ_G4];
	PseudoAttacks[BISHOP][SQ_E7] = SquareBC[~SQ_C0] | SquareBC[~SQ_G0] | SquareBC[~SQ_C4] | SquareBC[~SQ_G4];

	PseudoAttacks[BISHOP][SQ_G0] = SquareBC[SQ_E2] | SquareBC[SQ_I2];
	PseudoAttacks[BISHOP][SQ_G9] = SquareBC[~SQ_E2] | SquareBC[~SQ_I2];

	PseudoAttacks[BISHOP][SQ_I2] = SquareBC[SQ_G0] | SquareBC[SQ_G4];
	PseudoAttacks[BISHOP][SQ_I7] = SquareBC[~SQ_G0] | SquareBC[~SQ_G4];

	PseudoAttacks[BISHOP][SQ_C4] = SquareBC[SQ_A2] | SquareBC[SQ_E2];
	PseudoAttacks[BISHOP][SQ_C5] = SquareBC[~SQ_A2] | SquareBC[~SQ_E2];

	PseudoAttacks[BISHOP][SQ_G4] = SquareBC[SQ_I2] | SquareBC[SQ_E2];
	PseudoAttacks[BISHOP][SQ_G5] = SquareBC[~SQ_I2] | SquareBC[~SQ_E2];

}



void BitboardCs::init_stepattacks_advisor()
{
	PseudoAttacks[ADVISOR][SQ_D0] = SquareBC[SQ_E1];
	PseudoAttacks[ADVISOR][SQ_F0] = SquareBC[SQ_E1];
	PseudoAttacks[ADVISOR][SQ_D2] = SquareBC[SQ_E1];
	PseudoAttacks[ADVISOR][SQ_F2] = SquareBC[SQ_E1];

	PseudoAttacks[ADVISOR][SQ_D9] = SquareBC[~SQ_E1];
	PseudoAttacks[ADVISOR][SQ_F9] = SquareBC[~SQ_E1];
	PseudoAttacks[ADVISOR][SQ_D7] = SquareBC[~SQ_E1];
	PseudoAttacks[ADVISOR][SQ_F7] = SquareBC[~SQ_E1];


	PseudoAttacks[ADVISOR][SQ_E1] = SquareBC[SQ_D0] | SquareBC[SQ_F0] | SquareBC[SQ_D2] | SquareBC[SQ_F2];
	PseudoAttacks[ADVISOR][SQ_E8] = SquareBC[~SQ_D0] | SquareBC[~SQ_F0] | SquareBC[~SQ_D2] | SquareBC[~SQ_F2];

}



void BitboardCs::init_stepattacks_king()
{

#ifdef VMPROTECT
	VMProtectBeginUltraLockByKey("init_saking");
#endif

	PseudoAttacks[KING][SQ_D0] = SquareBC[SQ_D1] | SquareBC[SQ_E0];
	PseudoAttacks[KING][SQ_D9] = SquareBC[~SQ_D1] | SquareBC[~SQ_E0];

	PseudoAttacks[KING][SQ_E0] = SquareBC[SQ_D0] | SquareBC[SQ_F0] | SquareBC[SQ_E1];
	PseudoAttacks[KING][SQ_E9] = SquareBC[~SQ_D0] | SquareBC[~SQ_F0] | SquareBC[~SQ_E1];

	PseudoAttacks[KING][SQ_F0] = SquareBC[SQ_F1] | SquareBC[SQ_E0];
	PseudoAttacks[KING][SQ_F9] = SquareBC[~SQ_F1] | SquareBC[~SQ_E0];

	PseudoAttacks[KING][SQ_D1] = SquareBC[SQ_D0] | SquareBC[SQ_D2] | SquareBC[SQ_E1];
	PseudoAttacks[KING][SQ_D8] = SquareBC[~SQ_D0] | SquareBC[~SQ_D2] | SquareBC[~SQ_E1];
#ifdef VMPROTECT

	VMProtectEnd();
#endif

	PseudoAttacks[KING][SQ_E1] = SquareBC[SQ_E0] | SquareBC[SQ_D1] | SquareBC[SQ_F1] | SquareBC[SQ_E2];
	PseudoAttacks[KING][SQ_E8] = SquareBC[~SQ_E0] | SquareBC[~SQ_D1] | SquareBC[~SQ_F1] | SquareBC[~SQ_E2];

	PseudoAttacks[KING][SQ_F1] = SquareBC[SQ_F0] | SquareBC[SQ_F2] | SquareBC[SQ_E1];
	PseudoAttacks[KING][SQ_F8] = SquareBC[~SQ_F0] | SquareBC[~SQ_F2] | SquareBC[~SQ_E1];

	PseudoAttacks[KING][SQ_D2] = SquareBC[SQ_D1] | SquareBC[SQ_E2];
	PseudoAttacks[KING][SQ_D7] = SquareBC[~SQ_D1] | SquareBC[~SQ_E2];

	PseudoAttacks[KING][SQ_E2] = SquareBC[SQ_D2] | SquareBC[SQ_E1] | SquareBC[SQ_F2];
	PseudoAttacks[KING][SQ_E7] = SquareBC[~SQ_D2] | SquareBC[~SQ_E1] | SquareBC[~SQ_F2];

	PseudoAttacks[KING][SQ_F2] = SquareBC[SQ_F1] | SquareBC[SQ_E2];
	PseudoAttacks[KING][SQ_F7] = SquareBC[~SQ_F1] | SquareBC[~SQ_E2];

}

void BitboardCs::init_file_rank_bc()
{
	FileBC[FILE_A] = FileABC;
	FileBC[FILE_B] = FileBBC;
	FileBC[FILE_C] = FileCBC;
	FileBC[FILE_D] = FileDBC;
	FileBC[FILE_E] = FileEBC;
	FileBC[FILE_F] = FileFBC;
	FileBC[FILE_G] = FileGBC;
	FileBC[FILE_H] = FileHBC;
	FileBC[FILE_I] = FileIBC;

	ReverseFileBC[FILE_A] = ~FileABC;
	ReverseFileBC[FILE_B] = ~FileBBC;
	ReverseFileBC[FILE_C] = ~FileCBC;
	ReverseFileBC[FILE_D] = ~FileDBC;
	ReverseFileBC[FILE_E] = ~FileEBC;
	ReverseFileBC[FILE_F] = ~FileFBC;
	ReverseFileBC[FILE_G] = ~FileGBC;
	ReverseFileBC[FILE_H] = ~FileHBC;
	ReverseFileBC[FILE_I] = ~FileIBC;

	RankBC[RANK_0] = Rank1BC;
	RankBC[RANK_1] = Rank2BC;
	RankBC[RANK_2] = Rank3BC;
	RankBC[RANK_3] = Rank4BC;
	RankBC[RANK_4] = Rank5BC;
	RankBC[RANK_5] = Rank6BC;
	RankBC[RANK_6] = Rank7BC;
	RankBC[RANK_7] = Rank8BC;
	RankBC[RANK_8] = Rank9BC;
	RankBC[RANK_9] = Rank10BC;


#ifdef VMPROTECT
	VMProtectBeginUltraLockByKey("init_frank");
#endif

	ReverseRankBC[RANK_0] = ~Rank1BC;
	ReverseRankBC[RANK_1] = ~Rank2BC;
	ReverseRankBC[RANK_2] = ~Rank3BC;
	ReverseRankBC[RANK_3] = ~Rank4BC;
	ReverseRankBC[RANK_4] = ~Rank5BC;
	ReverseRankBC[RANK_5] = ~Rank6BC;
	ReverseRankBC[RANK_6] = ~Rank7BC;
	ReverseRankBC[RANK_7] = ~Rank8BC;
	ReverseRankBC[RANK_8] = ~Rank9BC;
	ReverseRankBC[RANK_9] = ~Rank10BC;
#ifdef VMPROTECT
	VMProtectEnd();
#endif

	for (File f = FILE_A; f < FILE_NB; ++f)
		AdjacentFilesBC[f] = merge64(AdjacentFilesBB[f], AdjacentFilesBB[f]);



}

void BitboardCs::init_reverse_squarebc() {
	for (Square s = SQ_A0; s < SQUARE_NB; ++s) {
		ReverseSquareBC[s] = ~SquareBC[s];
	}
}

// �ܲ�8�����Ҳ�����		SQ_C2 -> SQ_G2 �� ����һ�����̵ĶԳƵ�
void BitboardCs::computer_knight_full_nocross(const Square s)
{
	BitboardC tmp = bcZero;
	Square	s_t = square_color(s) == WHITE ? s : ~s;
	assert(is_half_legal(s_t));
	assert(is_half_legal(knight_dst<KDirect_1>(s_t)));
	assert(is_half_legal(knight_dst<KDirect_2>(s_t)));
	assert(is_half_legal(knight_dst<KDirect_3>(s_t)));
	assert(is_half_legal(knight_dst<KDirect_4>(s_t)));
	assert(is_half_legal(knight_dst<KDirect_5>(s_t)));
	assert(is_half_legal(knight_dst<KDirect_6>(s_t)));
	assert(is_half_legal(knight_dst<KDirect_7>(s_t)));
	assert(is_half_legal(knight_dst<KDirect_8>(s_t)));

	Bitboard bb = SquareBB[knight_dst<KDirect_1>(s_t)] | SquareBB[knight_dst<KDirect_2>(s_t)]
		| SquareBB[knight_dst<KDirect_3>(s_t)] | SquareBB[knight_dst<KDirect_4>(s_t)]
		| SquareBB[knight_dst<KDirect_5>(s_t)] | SquareBB[knight_dst<KDirect_6>(s_t)]
		| SquareBB[knight_dst<KDirect_7>(s_t)] | SquareBB[knight_dst<KDirect_8>(s_t)];

	if (square_color(s) == WHITE)
	{
		tmp.m128i_u64[0] = bb;
	}
	else
	{
		tmp.m128i_u64[1] = bb;
	}

	PseudoAttacks[KNIGHT][s] = tmp;

}

// �ܲ�8��������2�����		SQ_C3 -> SQ_G3 �� ����һ�����̵ĶԳƵ�
void BitboardCs::computer_knight_full_cross2(const Square s)
{
	BitboardC tmp = bcZero;

	Square	s_t = square_color(s) == WHITE ? s : ~s;

	assert(is_half_legal(s_t));
	assert(is_half_legal(knight_dst<KDirect_1>(s_t)));
	assert(is_half_legal(knight_dst<KDirect_2>(s_t)));
	assert(is_half_legal(knight_dst<KDirect_3>(s_t)));
	assert(is_half_legal(knight_dst<KDirect_5>(s_t)));
	assert(is_half_legal(knight_dst<KDirect_6>(s_t)));
	assert(is_half_legal(knight_dst<KDirect_7>(s_t)));
	assert(is_half_legal(s_t + NORTH_WEST));
	assert(is_half_legal(s_t + NORTH_EAST));


	Bitboard bb_us = SquareBB[knight_dst<KDirect_1>(s_t)] | SquareBB[knight_dst<KDirect_2>(s_t)]
		| SquareBB[knight_dst<KDirect_3>(s_t)]
		| SquareBB[knight_dst<KDirect_5>(s_t)] | SquareBB[knight_dst<KDirect_6>(s_t)]
		| SquareBB[knight_dst<KDirect_7>(s_t)];

	Bitboard bb_them = SquareBB[s_t + NORTH_WEST] | SquareBB[s_t + NORTH_EAST];

	if (square_color(s) == WHITE)
	{
		tmp.m128i_u64[0] = bb_us;
		tmp.m128i_u64[1] = bb_them;
	}
	else
	{
		tmp.m128i_u64[1] = bb_us;
		tmp.m128i_u64[0] = bb_them;
	}

	PseudoAttacks[KNIGHT][s] = tmp;

}

// �ܲ�8��������4�����		SQ_C4 -> SQ_G4 �� ����һ�����̵ĶԳƵ�
void BitboardCs::computer_knight_full_cross4(const Square s)
{
	BitboardC tmp = bcZero;

	Square	s_t = square_color(s) == WHITE ? s : ~s;

	assert(is_half_legal(s_t));
	assert(is_half_legal(knight_dst<KDirect_1>(s_t)));
	assert(is_half_legal(knight_dst<KDirect_2>(s_t)));
	assert(is_half_legal(knight_dst<KDirect_5>(s_t)));
	assert(is_half_legal(knight_dst<KDirect_6>(s_t)));
	assert(is_half_legal(s_t + SOUTH_WEST));
	assert(is_half_legal(s_t + SOUTH_EAST));
	assert(is_half_legal(s_t + WEST_WEST));
	assert(is_half_legal(s_t + EAST_EAST));

	Bitboard bb_us = SquareBB[knight_dst<KDirect_1>(s_t)] | SquareBB[knight_dst<KDirect_2>(s_t)]
		| SquareBB[knight_dst<KDirect_5>(s_t)] | SquareBB[knight_dst<KDirect_6>(s_t)];

	Bitboard bb_them = SquareBB[s_t + WEST_WEST] | SquareBB[s_t + EAST_EAST] | SquareBB[s_t + SOUTH_WEST] | SquareBB[s_t + SOUTH_EAST];

	if (square_color(s) == WHITE)
	{
		tmp.m128i_u64[0] = bb_us;
		tmp.m128i_u64[1] = bb_them;
	}
	else
	{
		tmp.m128i_u64[1] = bb_us;
		tmp.m128i_u64[0] = bb_them;
	}

	PseudoAttacks[KNIGHT][s] = tmp;
}

// �ܲ�4��		SQ_C0 -> SQ_G0 �� ����һ�����̵ĶԳƵ�
void BitboardCs::computer_knight_4(const Square s)
{
	BitboardC tmp = bcZero;

	Square	s_t = square_color(s) == WHITE ? s : ~s;

	assert(is_half_legal(s_t));
	assert(is_half_legal(knight_dst<KDirect_3>(s_t)));
	assert(is_half_legal(knight_dst<KDirect_4>(s_t)));
	assert(is_half_legal(knight_dst<KDirect_7>(s_t)));
	assert(is_half_legal(knight_dst<KDirect_8>(s_t)));


	Bitboard bb_us = SquareBB[knight_dst<KDirect_3>(s_t)] | SquareBB[knight_dst<KDirect_4>(s_t)]
		| SquareBB[knight_dst<KDirect_7>(s_t)] | SquareBB[knight_dst<KDirect_8>(s_t)];

	if (square_color(s) == WHITE)
	{
		tmp.m128i_u64[0] = bb_us;
	}
	else
	{
		tmp.m128i_u64[1] = bb_us;
	}

	PseudoAttacks[KNIGHT][s] = tmp;
}

// �ܲ�6��		SQ_C1 -> SQ_G1 �� ����һ�����̵ĶԳƵ�
void BitboardCs::computer_knight_6(const Square s)
{
	BitboardC tmp = bcZero;

	Square	s_t = square_color(s) == WHITE ? s : ~s;

	assert(is_half_legal(s_t));
	assert(is_half_legal(knight_dst<KDirect_2>(s_t)));
	assert(is_half_legal(knight_dst<KDirect_3>(s_t)));
	assert(is_half_legal(knight_dst<KDirect_4>(s_t)));
	assert(is_half_legal(knight_dst<KDirect_6>(s_t)));
	assert(is_half_legal(knight_dst<KDirect_7>(s_t)));
	assert(is_half_legal(knight_dst<KDirect_8>(s_t)));


	Bitboard bb_us = SquareBB[knight_dst<KDirect_2>(s_t)] | SquareBB[knight_dst<KDirect_3>(s_t)]
		| SquareBB[knight_dst<KDirect_4>(s_t)] | SquareBB[knight_dst<KDirect_6>(s_t)]
		| SquareBB[knight_dst<KDirect_7>(s_t)] | SquareBB[knight_dst<KDirect_8>(s_t)];

	if (square_color(s) == WHITE)
	{
		tmp.m128i_u64[0] = bb_us;
	}
	else
	{
		tmp.m128i_u64[1] = bb_us;
	}

	PseudoAttacks[KNIGHT][s] = tmp;
}

// �������s ͬ�л�ͬ�еĸ��ӣ��ŵ�vSq			
// ֻ����췽������� s ���� SQ_A0 <= s <= SQ_I4 
void BitboardCs::computer_rook_square(const Square s, const bool bRank, vSquare& vSq)
{
	int nIndex;
	Square tmpS;
	if (bRank)
	{
		nIndex = rank_of(s);
		for (tmpS = s; tmpS >= SQ_A0; --tmpS)
		{
			if (rank_of(tmpS) == nIndex)
			{
				vSq.push_back(tmpS);
			}
			else
			{
				break;
			}
		}
		for (tmpS = s; tmpS < SQUARE_HALF; ++tmpS)
		{
			if (rank_of(tmpS) == nIndex)
			{
				vSq.push_back(tmpS);
			}
			else
			{
				break;
			}
		}

	}
	else
	{
		nIndex = file_of(s);

		for (tmpS = s; tmpS >= SQ_A0; tmpS += SOUTH)
		{
			vSq.push_back(tmpS);
		}
		for (tmpS = s; tmpS < SQUARE_HALF; tmpS += NORTH)
		{
			vSq.push_back(tmpS);
		}
	}


}

Bitboard BitboardCs::vec_bb(const vSquare& vSq) {
	Bitboard bb = 0;
	for (size_t i = 0; i < vSq.size(); ++i) {
		bb |= vSq[i];
	}
	return bb;
}
// �õ� ���������ͬ������ֵ ��λ����
Bitboard BitboardCs::fileno_bb(const File fileIn) {
	Bitboard bb = 0;
	for (Rank r = RANK_0; r < RANK_4; ++r)
	{
		bb |= make_square(fileIn, r);

	}

	return bb;
}


void BitboardCs::init_filerank_dir() {
#ifdef VMPROTECT
	VMProtectBeginUltra("init_frdir");
#endif

	for (Square s = SQ_A0; s < SQUARE_NB; ++s) {
		File f = file_of(s);
		Rank r = rank_of(s);
		FileRankDirBC[s][NORTH_DIR] = ForwardBC[WHITE][s] & FileBC[f];
		FileRankDirBC[s][SOUTH_DIR] = ForwardBC[BLACK][s] & FileBC[f];
		FileRankDirBC[s][WEST_DIR] = side_file(f, WEST_DIR) & RankBC[r];
		FileRankDirBC[s][EAST_DIR] = side_file(f, EAST_DIR) & RankBC[r];
	}
#ifdef VMPROTECT
	VMProtectEnd();
#endif

}


void BitboardCs::init_stepattacks_rk_cn()
{
	for (Square s = SQ_A0; s < SQUARE_NB; ++s)
		for (int i = 0; i < 128; ++i) {
			AttacksRookRankBC[s][i] = calc_rook_rank(s, i);
		}

	for (Square s = SQ_A0; s < SQUARE_NB; ++s)
		for (int i = 0; i < 256; ++i) {
			AttacksRookFileBC[s][i] = calc_rook_file(s, i);
		}
#ifdef VMPROTECT
	VMProtectBeginUltra("init_rkcn");
#endif

	for (Square s = SQ_A0; s < SQUARE_NB; ++s) {
		PseudoAttacks[ROOK][s] = attacks_bc_rk(s, bcZero);
	}
#ifdef VMPROTECT
	VMProtectEnd();
#endif

	for (Square s = SQ_A0; s < SQUARE_NB; ++s)
		PseudoAttacksRook[s] = AttacksRookRankBC[s][0] | AttacksRookFileBC[s][0];


	for (Square s = SQ_A0; s < SQUARE_NB; ++s) {
		for (int i = 0; i < 128; ++i) {
			AttacksCannonRankBC[s][i] = calc_cannon_rank(s, i);
			//AssumeAttacksCannonRankBC[s][i] = calc_cannon_rank_assume(s, i);
		}
	}


	// i 0..1023  �ɵ�5λ �׷����� RANK_0...RANK_4  | ��5λ �ڷ�����RANK_0...RANK_4���
	for (Square s = SQ_A0; s < SQUARE_NB; ++s) {
		for (int i = 0; i < 256; ++i) {
			AttacksCannonFileBC[s][i] = calc_cannon_file(s, i);
			//AssumeAttacksCannonFileBC[s][i] = calc_cannon_file_assume(s, i);
		}
	}


}

// ����������λ�ã��������е����ӷֲ��������������������ߵ�λ�õ�λ����
// s:������λ�� 
// piece_bit:�����е����ӷֲ���� 0��512֮�� ��0(û������) �� 111111111 ��һ��ȫ������)  
// I <--   A		���ҵ��� == �ӵ�λ����λ
// 111110001
BitboardC BitboardCs::calc_rook_rank(const Square s, int piece_bit)
{
	assert(piece_bit >= 0 && piece_bit <= 127);

	BitboardC  bcRet = bcZero;
	Bitboard  b = 0;
	Square sWhite = SquareMap[s];
	piece_bit <<= 1;

	Rank rankS = rank_of(sWhite);
	File fileS = file_of(sWhite);

	assert(rank_color(rankS) == WHITE);

	for (File f = File(fileS - 1); f >= FILE_A; --f)
	{
		assert(f >= FILE_A && f < fileS);
		assert(make_square(f, rankS) < SQUARE_HALF);
		b |= make_square(f, rankS);
		if (piece_bit & FileBB[f]) 
			break;
	}
	for (File f = File(fileS + 1); f < FILE_NB; ++f)
	{
		assert(f > fileS && f < FILE_NB);
		assert(make_square(f, rankS) < SQUARE_HALF);
		b |= make_square(f, rankS);
		if (piece_bit & FileBB[f]) 
			break;

	}

	if (square_color(s) == WHITE)
	{
		bcRet.m128i_u64[0] = b;
	}
	else
	{
		bcRet.m128i_u64[1] = b;
	}

	return bcRet;
}


BitboardC BitboardCs::calc_rook_file(const Square s, int piece_bit)
{
	assert(piece_bit >= 0 && piece_bit <= 255);

	Rank r = rank_of(s);
	File f = file_of(s);
	int white = (piece_bit & 0xF); 	//��λ����λ�� RANK_1 => RANK_4
	white <<= 1;
	int black = piece_bit >> 4;		//��λ����λ�� RANK_5 => RANK_8
	Bitboard  w = 0, b = 0;
	BitboardC bc = bcZero;
	Color c = rank_color(r);

	for (Rank rr = Rank(r - 1); rr >= RANK_0; --rr) {
		if (rank_color(rr) == WHITE) {
			w |= make_square(f, rr);
			if ((white >> rr) & 0x1)
				break;
		}
		else {
			b |= make_square(f, ~rr);
			if ((black >> (rr - RANK_5)) & 0x1)
				break;
		}
	}

	for (Rank rr = Rank(r + 1); rr <= RANK_9; ++rr) {
		if (rank_color(rr) == WHITE) {
			w |= make_square(f, rr);
			if ((white >> rr) & 0x1)
				break;
		}
		else {
			b |= make_square(f, ~rr);
			if ((black >> (rr - RANK_5)) & 0x1)
				break;
		}
	}


	return merge64(w, b);
}



//�������ܹ������ĵ㣬�����ӵ� ����	�������ĵ�����ո���
BitboardC BitboardCs::calc_cannon_rank(const Square s, int piece_bit)
{
	assert(piece_bit >= 0 && piece_bit <= 127);

	BitboardC  bcRet = bcZero;
	Bitboard  tmp = 0;
	piece_bit <<= 1;
	Rank rankS = rank_of(SquareMap[s]);
	File fileS = file_of(s);

	assert(rankS >= RANK_0 && rankS <= RANK_4);

	bool bLever = false;
	for (File f = File(fileS - 1); f >= FILE_A; --f)
	{
		assert(f >= FILE_A && f < fileS);
		assert(make_square(f, rankS) < SQUARE_HALF);
		if (bLever)
		{
			tmp |= make_square(f, rankS);
			if (piece_bit & FileBB[f])
				break;
		}
		else
		{
			if (piece_bit & FileBB[f])
			{
				bLever = true;
			}
		}

	}
	bLever = false;

	for (File f = File(fileS + 1); f < FILE_NB; ++f)
	{
		assert(f > fileS && f < FILE_NB);
		assert(make_square(f, rankS) < SQUARE_HALF);
		if (bLever)
		{
			tmp |= make_square(f, rankS);
			if (piece_bit & FileBB[f])
				break;
		}
		else
		{
			if (piece_bit & FileBB[f])
				bLever = true;
		}
	}

	if (square_color(s) == WHITE)
	{
		bcRet.m128i_u64[0] = tmp;
	}
	else
	{
		bcRet.m128i_u64[1] = tmp;
	}

	return bcRet;
}

//�������ܹ������ĵ㣬�����ӵ� ����	�������ĵ�����ո���
BitboardC BitboardCs::calc_cannon_file(const Square s, int piece_bit)
{
	assert(piece_bit >= 0 && piece_bit <= 255);

	Rank r = rank_of(s);
	File f = file_of(s);
	int white = (piece_bit & 0xF); 	//��λ����λ�� RANK_1 => RANK_4
	white <<= 1;
	int black = piece_bit >> 4;		//��λ����λ�� RANK_5 => RANK_8
	Bitboard  w = 0, b = 0;
	BitboardC bc = bcZero;
	Color c = rank_color(r);
	bool half = true;
	bool lever = false;
	
	for (Rank rr = Rank(r - 1); rr >= RANK_0; --rr) {
		if (lever) {
			if (rank_color(rr) == WHITE) {
				w |= make_square(f, rr);
				if ((white >> rr) & 0x1)
					break;
			}
			else {
				b |= make_square(f, ~rr);
				if ((black >> (rr - RANK_5)) & 0x1)
					break;
			}
		}
		else {
			if (rank_color(rr) == WHITE) {
				if ((white >> rr) & 0x1)
					lever = true;
			}
			else {
				if ((black >> (rr - RANK_5)) & 0x1)
					lever = true;
			}
		}
		
	}
	lever = false;
	for (Rank rr = Rank(r + 1); rr <= RANK_9; ++rr) {
		if (lever) {
			if (rank_color(rr) == WHITE) {
				w |= make_square(f, rr);
				if ((white >> rr) & 0x1)
					break;
			}
			else {
				b |= make_square(f, ~rr);
				if ((black >> (rr - RANK_5)) & 0x1)
					break;
			}
		}
		else {
			if (rank_color(rr) == WHITE) {
				if ((white >> rr) & 0x1)
					lever = true;
			}
			else {
				if ((black >> (rr - RANK_5)) & 0x1)
					lever = true;
			}
		}

	}

	return merge64(w, b);


}

void BitboardCs::calc_kinght_pin(const Square s, const Square* pin, const BitboardC* bcPin, BitboardC* target)
{
	BitboardC bc;
	//for (int i = 0; i < 4; ++i) {
	//	Square sqPin = pin[i];
	//	if (sqPin != SQ_NONE) {
	//		bc = SquareBC[sqPin];
	//		KnightReachedPinFrom[s][total_square(&bc)] ^= bcPin[i];
	//	}
	//}
	std::set<int> setTotal;
	for (int i = 0; i < 4; ++i) {
		if (pin[i] != SQ_NONE) {
			bc = bcZero | pin[i];
			int t = total_square(&bc);
			auto it = setTotal.insert(t);
			assert(it.second);
			target[t] ^= bcPin[i];
		}
	}

	for (int i = 0; i < 4; ++i) {
		if (pin[i] != SQ_NONE) {
			for (int j = 0; j < 4; ++j) {
				if (pin[j] != SQ_NONE && i < j) {
					bc = pin[i] | pin[j];
					int t = total_square(&bc);
					auto it = setTotal.insert(t);
					assert(it.second);
					target[t] ^= (bcPin[i] | bcPin[j]);
				}
			}
		}
	}

	for (int i = 0; i < 4; ++i) {
		if (pin[i] != SQ_NONE) {
			for (int j = 0; j < 4; ++j) {
				if (pin[j] != SQ_NONE && i < j) {

					for (int k = 0; k < 4; ++k) {
						if (pin[k] != SQ_NONE && j < k) {
							bc = pin[i] | pin[j] | pin[k];
							int t = total_square(&bc);
							auto it = setTotal.insert(t);
							assert(it.second);
							target[t] ^= (bcPin[i] | bcPin[j] | bcPin[k]);
						}
					}
				}
			}
		}
	}

}


//
//void BitboardCs::init_pseudo_attack()
//{
//	for (Square s = SQ_A0; s < SQUARE_NB; ++s)
//	{
//		PseudoAttacksBC[ROOK][s] = PseudoAttacksBC[CANNON][s] = attacks_bc_rk(s, bcZero);
//	}
//
//}

void BitboardCs::init_between()
{
	for (Square s1 = SQ_A0; s1 < SQUARE_NB; ++s1)
	{
		for (Square s2 = SQ_A0; s2 < SQUARE_NB; ++s2)
		{
			if (s1 != s2 && equal_z(BetweenBC[s1][s2]))
			{
				Rank r1 = rank_of(s1);
				Rank r2 = rank_of(s2);
				File f1 = file_of(s1);
				File f2 = file_of(s2);

				if (r1 == r2)
				{
					f1 = std::min(f1, f2);
					f2 = std::max(f1, f2);
					for (File f = File(f1 + 1); f < f2; ++f)
					{
						BetweenBC[s1][s2] |= make_square(f, r1);
					}
					BetweenBC[s2][s1] = BetweenBC[s1][s2];

				}
				else if (f1 == f2)
				{
					r1 = std::min(r1, r2);
					r2 = std::max(r1, r2);
					for (Rank r = Rank(r1 + 1); r < r2; ++r)
					{
						BetweenBC[s1][s2] |= make_square(f1, r);
					}
					BetweenBC[s2][s1] = BetweenBC[s1][s2];

				}
			}
		}
	}
}

void BitboardCs::init_line() {
	for (Square s1 = SQ_A0; s1 < SQUARE_NB; ++s1) {
		for (Square s2 = SQ_A0; s2 < SQUARE_NB; ++s2) {
			if (s1 != s2) {
				File f1 = file_of(s1);
				File f2 = file_of(s2);
				if (f1 == f2) {
					LineBC[s1][s2] = FileBC[f1];
					continue;
				}
				Rank r1 = rank_of(s1);
				Rank r2 = rank_of(s2);
				if (r1 == r2) {
					LineBC[s1][s2] = RankBC[r1];
				}
			}
		}
	}
}

void BitboardCs::init_knight_notreach() {
	for (Square s1 = SQ_A0; s1 < SQUARE_NB; ++s1) {
		File f1 = file_of(s1);
		Rank r1 = rank_of(s1);
		if (f1 >= FILE_C && f1 <= FILE_G && r1 >= RANK_2 && r1 <= RANK_7) {
			KnightNotReach[s1][s1 + WEST] = ((s1 + SOUTH_WEST_WEST) | (s1 + NORTH_WEST_WEST));
			KnightNotReach[s1][s1 + NORTH] = ((s1 + NORTH_NORTH_WEST) | (s1 + NORTH_NORTH_EAST));
			KnightNotReach[s1][s1 + EAST] = ((s1 + NORTH_EAST_EAST) | (s1 + SOUTH_EAST_EAST));
			KnightNotReach[s1][s1 + SOUTH] = ((s1 + SOUTH_SOUTH_WEST) | (s1 + SOUTH_SOUTH_EAST));
		}
		if (f1 == FILE_B && r1 >= RANK_2 && r1 <= RANK_7) {
			KnightNotReach[s1][s1 + NORTH] = ((s1 + NORTH_NORTH_WEST) | (s1 + NORTH_NORTH_EAST));
			KnightNotReach[s1][s1 + EAST] = ((s1 + NORTH_EAST_EAST) | (s1 + SOUTH_EAST_EAST));
			KnightNotReach[s1][s1 + SOUTH] = ((s1 + SOUTH_SOUTH_WEST) | (s1 + SOUTH_SOUTH_EAST));
		}
		if (f1 == FILE_H && r1 >= RANK_2 && r1 <= RANK_7) {
			KnightNotReach[s1][s1 + WEST] = ((s1 + SOUTH_WEST_WEST) | (s1 + NORTH_WEST_WEST));
			KnightNotReach[s1][s1 + NORTH] = ((s1 + NORTH_NORTH_WEST) | (s1 + NORTH_NORTH_EAST));
			KnightNotReach[s1][s1 + SOUTH] = ((s1 + SOUTH_SOUTH_WEST) | (s1 + SOUTH_SOUTH_EAST));
		}
		if (f1 >= FILE_C && f1 <= FILE_G && r1 == RANK_1) {
			KnightNotReach[s1][s1 + WEST] = ((s1 + SOUTH_WEST_WEST) | (s1 + NORTH_WEST_WEST));
			KnightNotReach[s1][s1 + NORTH] = ((s1 + NORTH_NORTH_WEST) | (s1 + NORTH_NORTH_EAST));
			KnightNotReach[s1][s1 + EAST] = ((s1 + NORTH_EAST_EAST) | (s1 + SOUTH_EAST_EAST));
		}
		if (f1 >= FILE_C && f1 <= FILE_G && r1 == RANK_8) {
			KnightNotReach[s1][s1 + WEST] = ((s1 + SOUTH_WEST_WEST) | (s1 + NORTH_WEST_WEST));
			KnightNotReach[s1][s1 + EAST] = ((s1 + NORTH_EAST_EAST) | (s1 + SOUTH_EAST_EAST));
			KnightNotReach[s1][s1 + SOUTH] = ((s1 + SOUTH_SOUTH_WEST) | (s1 + SOUTH_SOUTH_EAST));
		}
		if (f1 == FILE_A && r1 >= RANK_2 && r1 <= RANK_7) {
			KnightNotReach[s1][s1 + NORTH] = SquareBC[s1 + NORTH_NORTH_EAST];
			KnightNotReach[s1][s1 + EAST] = ((s1 + NORTH_EAST_EAST) | (s1 + SOUTH_EAST_EAST));
			KnightNotReach[s1][s1 + SOUTH] = SquareBC[s1 + SOUTH_SOUTH_EAST];
		}
		if (f1 == FILE_I && r1 >= RANK_2 && r1 <= RANK_7) {
			KnightNotReach[s1][s1 + WEST] = ((s1 + SOUTH_WEST_WEST) | (s1 + NORTH_WEST_WEST));
			KnightNotReach[s1][s1 + NORTH] = SquareBC[s1 + NORTH_NORTH_WEST];
			KnightNotReach[s1][s1 + SOUTH] = SquareBC[s1 + SOUTH_SOUTH_WEST];
		}
		if (f1 >= FILE_C && f1 <= FILE_G && r1 == RANK_0) {
			KnightNotReach[s1][s1 + WEST] = SquareBC[s1 + NORTH_WEST_WEST];
			KnightNotReach[s1][s1 + NORTH] = ((s1 + NORTH_NORTH_WEST) | (s1 + NORTH_NORTH_EAST));
			KnightNotReach[s1][s1 + EAST] = SquareBC[s1 + NORTH_EAST_EAST];
		}
		if (f1 >= FILE_C && f1 <= FILE_G && r1 == RANK_9) {
			KnightNotReach[s1][s1 + WEST] = SquareBC[s1 + SOUTH_WEST_WEST];
			KnightNotReach[s1][s1 + EAST] = SquareBC[s1 + SOUTH_EAST_EAST];
			KnightNotReach[s1][s1 + SOUTH] = ((s1 + SOUTH_SOUTH_WEST) | (s1 + SOUTH_SOUTH_EAST));
		}

	}


#ifdef VMPROTECT
	VMProtectBeginUltraLockByKey("init_knnr");
#endif


	KnightNotReach[SQ_B1][SQ_B1 + NORTH] = ((SQ_B1 + NORTH_NORTH_WEST) | (SQ_B1 + NORTH_NORTH_EAST));
	KnightNotReach[SQ_B1][SQ_B1 + EAST] = ((SQ_B1 + NORTH_EAST_EAST) | (SQ_B1 + SOUTH_EAST_EAST));
	KnightNotReach[SQ_B0][SQ_B0 + NORTH] = ((SQ_B0 + NORTH_NORTH_WEST) | (SQ_B0 + NORTH_NORTH_EAST));
	KnightNotReach[SQ_B0][SQ_B0 + EAST] = SquareBC[SQ_B0 + NORTH_EAST_EAST];
	KnightNotReach[SQ_A1][SQ_A1 + NORTH] = SquareBC[SQ_A1 + NORTH_NORTH_EAST];
	KnightNotReach[SQ_A1][SQ_A1 + EAST] = ((SQ_A1 + NORTH_EAST_EAST) | (SQ_A1 + SOUTH_EAST_EAST));
	KnightNotReach[SQ_A0][SQ_A0 + NORTH] = SquareBC[SQ_A0 + NORTH_NORTH_EAST];
	KnightNotReach[SQ_A0][SQ_A0 + EAST] = SquareBC[SQ_A0 + NORTH_EAST_EAST];

#ifdef VMPROTECT
	VMProtectEnd();
#endif


	KnightNotReach[SQ_H1][SQ_H1 + NORTH] = ((SQ_H1 + NORTH_NORTH_WEST) | (SQ_H1 + NORTH_NORTH_EAST));
	KnightNotReach[SQ_H1][SQ_H1 + WEST] = ((SQ_H1 + NORTH_WEST_WEST) | (SQ_H1 + SOUTH_WEST_WEST));
	KnightNotReach[SQ_H0][SQ_H0 + NORTH] = ((SQ_H0 + NORTH_NORTH_WEST) | (SQ_H0 + NORTH_NORTH_EAST));
	KnightNotReach[SQ_H0][SQ_H0 + WEST] = SquareBC[SQ_H0 + NORTH_WEST_WEST];
	KnightNotReach[SQ_I1][SQ_I1 + NORTH] = SquareBC[SQ_I1 + NORTH_NORTH_WEST];
	KnightNotReach[SQ_I1][SQ_I1 + WEST] = ((SQ_I1 + NORTH_WEST_WEST) | (SQ_I1 + SOUTH_WEST_WEST));
	KnightNotReach[SQ_I0][SQ_I0 + NORTH] = SquareBC[SQ_I0 + NORTH_NORTH_WEST];
	KnightNotReach[SQ_I0][SQ_I0 + WEST] = SquareBC[SQ_I0 + NORTH_WEST_WEST];

	KnightNotReach[SQ_B8][SQ_B8 + SOUTH] = ((SQ_B8 + SOUTH_SOUTH_WEST) | (SQ_B8 + SOUTH_SOUTH_EAST));
	KnightNotReach[SQ_B8][SQ_B8 + EAST] = ((SQ_B8 + NORTH_EAST_EAST) | (SQ_B8 + SOUTH_EAST_EAST));
	KnightNotReach[SQ_B9][SQ_B9 + SOUTH] = ((SQ_B9 + SOUTH_SOUTH_WEST) | (SQ_B9 + SOUTH_SOUTH_EAST));
	KnightNotReach[SQ_B9][SQ_B9 + EAST] = SquareBC[SQ_B9 + SOUTH_EAST_EAST];
	KnightNotReach[SQ_A8][SQ_A8 + SOUTH] = SquareBC[SQ_A8 + SOUTH_SOUTH_EAST];
	KnightNotReach[SQ_A8][SQ_A8 + EAST] = ((SQ_A8 + NORTH_EAST_EAST) | (SQ_A8 + SOUTH_EAST_EAST));
	KnightNotReach[SQ_A9][SQ_A9 + SOUTH] = SquareBC[SQ_A9 + SOUTH_SOUTH_EAST];
	KnightNotReach[SQ_A9][SQ_A9 + EAST] = SquareBC[SQ_A9 + SOUTH_EAST_EAST];

	KnightNotReach[SQ_H8][SQ_H8 + SOUTH] = ((SQ_H8 + SOUTH_SOUTH_WEST) | (SQ_H8 + SOUTH_SOUTH_EAST));
	KnightNotReach[SQ_H8][SQ_H8 + WEST] = ((SQ_H8 + NORTH_WEST_WEST) | (SQ_H8 + SOUTH_WEST_WEST));
	KnightNotReach[SQ_H9][SQ_H9 + SOUTH] = ((SQ_H9 + SOUTH_SOUTH_WEST) | (SQ_H9 + SOUTH_SOUTH_EAST));
	KnightNotReach[SQ_H9][SQ_H9 + WEST] = SquareBC[SQ_H9 + SOUTH_WEST_WEST];
	KnightNotReach[SQ_I8][SQ_I8 + SOUTH] = SquareBC[SQ_I8 + SOUTH_SOUTH_WEST];
	KnightNotReach[SQ_I8][SQ_I8 + WEST] = ((SQ_I8 + NORTH_WEST_WEST) | (SQ_I8 + SOUTH_WEST_WEST));
	KnightNotReach[SQ_I9][SQ_I9 + SOUTH] = SquareBC[SQ_I9 + SOUTH_SOUTH_WEST];
	KnightNotReach[SQ_I9][SQ_I9 + WEST] = SquareBC[SQ_I9 + SOUTH_WEST_WEST];

}

void BitboardCs::init_bishop_notreach() {
	for (Square s1 = SQ_A0; s1 < SQUARE_NB; ++s1) {
		for (Square s2 = SQ_A0; s2 < SQUARE_NB; ++s2) {
			sqBishopNotReach[s1][s2] = SQ_NONE;
		}
	}
	for (Square s = SQ_A0; s < SQUARE_NB; ++s) {
		if (bishop_square(s)) {
			File f = file_of(s);
			Rank r = rank_of(s);
			if (f == FILE_A) {
				sqBishopNotReach[s][s + SOUTH_EAST] = s + SOUTH_EAST + SOUTH_EAST;
				sqBishopNotReach[s][s + NORTH_EAST] = s + NORTH_EAST + NORTH_EAST;
			}
			else if (f == FILE_C || f == FILE_G) {
				if (r == RANK_0 || r == RANK_5) {
					sqBishopNotReach[s][s + NORTH_WEST] = s + NORTH_WEST + NORTH_WEST;
					sqBishopNotReach[s][s + NORTH_EAST] = s + NORTH_EAST + NORTH_EAST;
				}
				else if (r == RANK_4 || r == RANK_9) {
					sqBishopNotReach[s][s + SOUTH_WEST] = s + SOUTH_WEST + SOUTH_WEST;
					sqBishopNotReach[s][s + SOUTH_EAST] = s + SOUTH_EAST + SOUTH_EAST;
				}
			}
			else if (f == FILE_E) {
				sqBishopNotReach[s][s + SOUTH_WEST] = s + SOUTH_WEST + SOUTH_WEST;
				sqBishopNotReach[s][s + NORTH_WEST] = s + NORTH_WEST + NORTH_WEST;
				sqBishopNotReach[s][s + SOUTH_EAST] = s + SOUTH_EAST + SOUTH_EAST;
				sqBishopNotReach[s][s + NORTH_EAST] = s + NORTH_EAST + NORTH_EAST;
			}
			else if (f == FILE_I) {
				sqBishopNotReach[s][s + SOUTH_WEST] = s + SOUTH_WEST + SOUTH_WEST;
				sqBishopNotReach[s][s + NORTH_WEST] = s + NORTH_WEST + NORTH_WEST;
			}
		}
	}
}
//
//void BitboardCs::init_king_ring()
//{
//	BitboardC bcWhite = bcZero, bcBlack = bcZero;
//	bcWhite.m128i_u64[0] = bcBlack.m128i_u64[1] = 7354396;
//	KingRingBC[WHITE][SQ_D0] = bcWhite;		//
//	KingRingBC[BLACK][~SQ_D0] = bcBlack;	
//
//	bcWhite.m128i_u64[0] = bcBlack.m128i_u64[1] = FortBB;
//	KingRingBC[WHITE][SQ_E0] = bcWhite;		//ȫ�Ź�
//	KingRingBC[BLACK][~SQ_E0] = bcBlack;	
//
//	bcWhite.m128i_u64[0] = bcBlack.m128i_u64[1] = 29417584;
//	KingRingBC[WHITE][SQ_F0] = bcWhite;		//
//	KingRingBC[BLACK][~SQ_F0] = bcBlack;	
//
//	bcWhite.m128i_u64[0] = bcBlack.m128i_u64[1] = 3765450780;
//	KingRingBC[WHITE][SQ_D1] = bcWhite;		//
//	KingRingBC[BLACK][~SQ_D1] = bcBlack;	
//
//	bcWhite.m128i_u64[0] = bcBlack.m128i_u64[1] = 7530901560;
//	KingRingBC[WHITE][SQ_E1] = bcWhite;		//
//	KingRingBC[BLACK][~SQ_E1] = bcBlack;	
//
//	bcWhite.m128i_u64[0] = bcBlack.m128i_u64[1] = 15061803120;
//	KingRingBC[WHITE][SQ_F1] = bcWhite;		//
//	KingRingBC[BLACK][~SQ_F1] = bcBlack;	
//
//	bcWhite.m128i_u64[0] = bcBlack.m128i_u64[1] = 1927910799360;
//	KingRingBC[WHITE][SQ_D2] = bcWhite;		//
//	KingRingBC[BLACK][~SQ_D2] = bcBlack;	
//
//	bcWhite.m128i_u64[0] = bcBlack.m128i_u64[1] = 3855821598720;
//	KingRingBC[WHITE][SQ_E2] = bcWhite;		//
//	KingRingBC[BLACK][~SQ_E2] = bcBlack;	
//
//	bcWhite.m128i_u64[0] = bcBlack.m128i_u64[1] = 7711643197440;
//	KingRingBC[WHITE][SQ_F2] = bcWhite;		//
//	KingRingBC[BLACK][~SQ_F2] = bcBlack;	
//
//}

//
//void BitboardCs::init_kp_distance()
//{
//	for(int i = 0; i < 128 ; ++i)
//		for(int j = 0; j < 128 ; ++j)
//			KPDistance[i][j]  = KPDistance[i][j] = KING_PAWN_MAX_DIST;
//
//	for (Square ks = SQ_A0; ks < SQUARE_NB; ++ks)
//		for (Square kp = SQ_A0; kp < SQUARE_NB; ++kp)
//		{
//			KPDistance[ks][kp]  = std::min(KING_PAWN_MAX_DIST, kp_distance(ks, kp));
//		}
//}
//
//void BitboardCs::init_squaredistance()
//{
//	for (Square s1 = SQ_A0; s1 < SQUARE_NB; ++s1)
//		for (Square s2 = SQ_A0; s2 < SQUARE_NB; ++s2) {
//			if (s1 != s2)
//				SquareDistance[s1][s2] = std::max(distance<File>(s1, s2), distance<Rank>(s1, s2));
//			else
//				SquareDistance[s1][s2] = 0;
//		}
//}

void BitboardCs::init_front_bc()
{
	for (Rank r = RANK_0; r <= RANK_4; ++r)
		InFrontBC[WHITE][r] = merge64(InFrontBB[WHITE][r], LegalAllOneBB);
	for (Rank r = RANK_5; r < RANK_NB; ++r)
		InFrontBC[WHITE][r] = merge64(0, InFrontBB[BLACK][~r]);	//InFrontBC[WHITE][RANK_9] == bcZero
	for (Rank r = RANK_0; r <= RANK_4; ++r)
		InFrontBC[BLACK][r] = merge64(InFrontBB[BLACK][r], 0);
	for (Rank r = RANK_5; r < RANK_NB; ++r)
		InFrontBC[BLACK][r] = merge64(LegalAllOneBB, InFrontBB[WHITE][~r]);


#ifdef VMPROTECT
	VMProtectBeginUltraLockByKey("init_frbc");
#endif
	for (Color c = WHITE; c < COLOR_NB; ++c)
		for (Square s = SQ_A0; s < SQUARE_NB; ++s)
			ForwardBC[c][s] = InFrontBC[c][rank_of(s)];

#ifdef VMPROTECT
	VMProtectEnd();
#endif

}
