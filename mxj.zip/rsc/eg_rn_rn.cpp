#include "endgame.h"


//������Ŀ���ڵ���2�����ӷ�
//��˫��ʿ��û�����ʿ���۷�
//һ�����ֻ��һ��ʿ���ҶԷ����ڽ���λ�ã��й��ƣ��ӷ�
template<EndgameType E/*, typename T = eg_type<E>*/>
inline void Endgame<E>::rn_rn_total(const Position& pos, Score& score) const {

	Value v = VALUE_ZERO;

	int adWhite = pos.count(WHITE, ADVISOR);
	int adBlack = pos.count(BLACK, ADVISOR);

	int nbpWhite = pos.pawn_nobottomcount<WHITE>();
	int nbpBlack = pos.pawn_nobottomcount<BLACK>();
	int vpWhite = pos.pawn_validcount<WHITE>();
	int vpBlack = pos.pawn_validcount<BLACK>();

	auto baWhite = pos.ba_number<WHITE>();
	auto baBlack = pos.ba_number<BLACK>();

	//if (equal_z(pos.pieces(WHITE, ROOK) & AreaHighRook))
	//	v += -BishopValueEg * 0.2;
	//if (equal_z(pos.pieces(BLACK, ROOK) & AreaHighRook))
	//	v += BishopValueEg * 0.2;

	if (pos.count(WHITE, ADVISOR) == 2 && !pos.is_advisor_cavel(WHITE))
		v += -BISHOP_END_10P;
	if (pos.count(BLACK, ADVISOR) == 2 && !pos.is_advisor_cavel(BLACK))
		v += BISHOP_END_10P;

	if (nbpWhite <= 2 && rookpawn_chain_byrook<WHITE>(pos)) {
		v += -PAWN_END_70P;
	}
	if (nbpBlack <= 2 && rookpawn_chain_byrook<BLACK>(pos)) {
		v += PAWN_END_70P;
	}

	//if (vpWhite == 0 && pos.is_king_rank2(BLACK))
	//	v += -50;
	//if (vpBlack == 0 && pos.is_king_rank2(WHITE))
	//	v += 50;

	//if (vpWhite >= vpBlack + 2) {
	//	v += vpWhite * PawnValueEg * 0.4;
	//}
	//else if (vpBlack >= vpWhite + 2) {
	//	v += -vpBlack * PawnValueEg * 0.4;
	//}

	if (pos.defense_count(WHITE) <= 1 && is_kn_attack<BLACK>(pos))
		v += -BISHOP_END_30P;
	if (pos.defense_count(BLACK) <= 1 && is_kn_attack<WHITE>(pos))
		v += BISHOP_END_30P;

	if (vpWhite > 0 && vpBlack == 0 && baWhite >= BA_DA) {
		v += vpWhite * PAWN_END_20P;
	}
	else if (vpWhite == 0 && vpBlack > 0 && baBlack >= BA_DA) {
		v += -vpBlack * PAWN_END_20P;
	}

	update_score(score, v);

	if (pos.count(WHITE, PAWN) <= 3 && pos.count(BLACK, PAWN) <= 3) {
		if (pos.pawn_validcount<WHITE>() == 0 && pos.full_ba(BLACK) && greater_than<WHITE>(score, VALUE_ADV_LOWLIMIT)) {
			update_score(score, -eg_value(score) * 0.5);
		}
		else if (pos.pawn_validcount<BLACK>() == 0 && pos.full_ba(WHITE) && greater_than<BLACK>(score, VALUE_ADV_LOWLIMIT)) {
			update_score(score, -eg_value(score) * 0.5);
		}
	}


}

template<>
Value Endgame<KRNKRN>::operator()(const Position& pos, Score& score) const {
	if (rkkncn_chain_byrk<WHITE, KNIGHT>(pos)) {
		//�׷�����ǣ�ƣ��ڷ��б� or �׷���ʿ��ȫ���Һڷ���ʿ��
		if (pos.pawn_nobottomcount<BLACK>() > 0 || (!pos.full_ba(WHITE) && !pos.zero_ba(BLACK)))
			return update_score(pos, score, -KNIGHT_END_70P);
	}
	if (rkkncn_chain_byrk<BLACK, KNIGHT>(pos)) {
		//�ڷ�����ǣ�ƣ��׷��б� or �ڷ���ʿ��ȫ���Ұ׷���ʿ��
		if (pos.pawn_nobottomcount<WHITE>() > 0 || (!pos.full_ba(BLACK) && !pos.zero_ba(WHITE)))
			return update_score(pos, score, KNIGHT_END_70P);
	}

	strongSide == WHITE ? rn_rn_total(pos, score) : rn_rn_total(pos, score);

	FUN_IMPL_SAME_PIECES_ALL(krn_krn)
}

template<EndgameType E/*, typename T = eg_type<E>*/>
template<Color strong> inline Value Endgame<E>::krn_krn_0p_0p(const Position& pos, Score& score) const {
	auto baWhite = pos.ba_number<WHITE>();
	auto baBlack = pos.ba_number<BLACK>();

	//�������  �ڷ�����˫������˫���ȱʿ���� ע�� ����ʿ��ȫ�Գ���ʿ��(˫ʿ)��ʤ��
	if (baWhite >= BA_DB && baBlack >= BA_DB && pos.pawn_bottomcount<WHITE>() + pos.pawn_bottomcount<BLACK>() == 0) {
		int diff = pos.defense_count(WHITE) - pos.defense_count(BLACK);
		Value v = diff * BISHOP_END_70P;
		return update_score(score, strong, -v);

	}

	return VALUE_NONE;
}

template<EndgameType E/*, typename T = eg_type<E>*/>
template<Color strong> inline Value Endgame<E>::krn_krn_1p_0p(const Position& pos, Score& score) const {
	I_AM_WEAK

		auto ba = pos.ba_number<weak>();
	auto baStrg = pos.ba_number<strong>();

	//�б��������������ڵ���2���޺��֮�ǣ���Ч���ӷ�
	if (baStrg >= BA_BA && pos.pawn_validcount<strong>() == 1)
		update_score(score, strong, PAWN_END_80P);


	switch (ba) {
	case BA_ZERO:
		if (pos.pawn_validcount<strong>() > 0 && !pos.zero_ba(strong))
			goto almostWin;
		break;
	case BA_AD:
	case BA_BS:
	case BA_DB:
	case BA_BA:
	case BA_DA:
		break;
	case BA_DBA:
	case BA_BDA:
	default:
		if (baStrg >= BA_DBA)
			goto drawEnd;
		break;
	}
	return VALUE_NONE;

almostWin:
	return update_score(pos, score, strong, PAWN_END_200P);

drawEnd:
	return 	update_score_limit(score, -PAWN_END_50P);

}

template<EndgameType E/*, typename T = eg_type<E>*/>
template<Color strong> inline Value Endgame<E>::krn_krn_1p_1p(const Position& pos, Score& score) const {
	return VALUE_NONE;
}

template<EndgameType E/*, typename T = eg_type<E>*/>
template<Color strong> inline Value Endgame<E>::krn_krn_2p_0p(const Position& pos, Score& score) const {
	return VALUE_NONE;
}

template<EndgameType E/*, typename T = eg_type<E>*/>
template<Color strong> inline Value Endgame<E>::krn_krn_2p_1p(const Position& pos, Score& score) const {
	return VALUE_NONE;
}

template<EndgameType E/*, typename T = eg_type<E>*/>
template<Color strong> inline Value Endgame<E>::krn_krn_2p_2p(const Position& pos, Score& score) const {
	return VALUE_NONE;
}