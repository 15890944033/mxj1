#include "endgame.h"


template<EndgameType E/*, typename T = eg_type<E>*/>
template<Color c>
inline void Endgame<E>::rn_cn_total(const Position& pos, Score& score) const {
	Value v = VALUE_ZERO;
	const Color Them = c == WHITE ? BLACK : WHITE;

	//ǿ��������¶�����ӷ�
	if (pos.is_king_mid_clear<c>())
		v += BISHOP_END_40P;

	//���������ڵף��۷�
	if (!pos.is_king_bottom(Them))
		v += BISHOP_END_40P;

	update_score(score, c, v);

	ba_adjust_strong<c>(pos, score, VALUE_BA_ADJUST_MAX_UL);

}

template<>
Value Endgame<KRNKCN>::operator()(const Position& pos, Score& score) const {
	strongSide == WHITE ? rn_cn_total<WHITE>(pos, score) : rn_cn_total<BLACK>(pos, score);

	FUN_IMPL_DIFF_PIECES_ALL(krn_kcn)
}

template<EndgameType E/*, typename T = eg_type<E>*/>
template<Color strong> inline Value Endgame<E>::krn_kcn_0p_0p(const Position& pos, Score& score) const {
	return 	VALUE_NONE;
}

template<EndgameType E/*, typename T = eg_type<E>*/>
template<Color strong> inline Value Endgame<E>::krn_kcn_1p_0p(const Position& pos, Score& score) const {
	return 	VALUE_NONE;
}

template<EndgameType E/*, typename T = eg_type<E>*/>
template<Color strong> inline Value Endgame<E>::krn_kcn_2p_0p(const Position& pos, Score& score) const {
	return 	VALUE_NONE;
}

template<EndgameType E/*, typename T = eg_type<E>*/>
template<Color strong> inline Value Endgame<E>::krn_kcn_0p_1p(const Position& pos, Score& score) const {
	return 	VALUE_NONE;
}

template<EndgameType E/*, typename T = eg_type<E>*/>
template<Color strong> inline Value Endgame<E>::krn_kcn_1p_1p(const Position& pos, Score& score) const {
	return 	VALUE_NONE;
}

template<EndgameType E/*, typename T = eg_type<E>*/>
template<Color strong> inline Value Endgame<E>::krn_kcn_2p_1p(const Position& pos, Score& score) const {
	return 	VALUE_NONE;
}

template<EndgameType E/*, typename T = eg_type<E>*/>
template<Color strong> inline Value Endgame<E>::krn_kcn_0p_2p(const Position& pos, Score& score) const {
	return 	VALUE_NONE;
}

template<EndgameType E/*, typename T = eg_type<E>*/>
template<Color strong> inline Value Endgame<E>::krn_kcn_1p_2p(const Position& pos, Score& score) const {
	return 	VALUE_NONE;
}

template<EndgameType E/*, typename T = eg_type<E>*/>
template<Color strong> inline Value Endgame<E>::krn_kcn_2p_2p(const Position& pos, Score& score) const {
	return 	VALUE_NONE;
}

