#include "endgame.h"

template<>
Value Endgame<KRCKCNN>::operator()(const Position& pos, Score& score) const {

	//�г����޳��������� 
	int nbpStrong;
	if (strongSide == WHITE)
		nbpStrong = pos.pawn_nobottomcount<WHITE>();
	else
		nbpStrong = pos.pawn_nobottomcount<BLACK>();

	Value v = nbpStrong > 0 ? RookVsNoRookWithPawn /*+ nbpStrong * Value(25) */: RookVsNoRookWithoutPawn;
	update_score(score, strongSide, v);

	FUN_IMPL_DIFF_PIECES_ALL(krc_kcnn)
}

template<EndgameType E/*, typename T = eg_type<E>*/>
template<Color strong> inline Value Endgame<E>::krc_kcnn_0p_0p(const Position& pos, Score& score) const {
	return VALUE_NONE;
}

template<EndgameType E/*, typename T = eg_type<E>*/>
template<Color strong> inline Value Endgame<E>::krc_kcnn_1p_0p(const Position& pos, Score& score) const {
	return VALUE_NONE;
}

template<EndgameType E/*, typename T = eg_type<E>*/>
template<Color strong> inline Value Endgame<E>::krc_kcnn_2p_0p(const Position& pos, Score& score) const {
	return VALUE_NONE;
}


template<EndgameType E/*, typename T = eg_type<E>*/>
template<Color strong> inline Value Endgame<E>::krc_kcnn_0p_1p(const Position& pos, Score& score) const {

	return VALUE_NONE;
}

template<EndgameType E/*, typename T = eg_type<E>*/>
template<Color strong> inline Value Endgame<E>::krc_kcnn_1p_1p(const Position& pos, Score& score) const {
	return VALUE_NONE;
}

template<EndgameType E/*, typename T = eg_type<E>*/>
template<Color strong> inline Value Endgame<E>::krc_kcnn_2p_1p(const Position& pos, Score& score) const {
	return VALUE_NONE;
}

template<EndgameType E/*, typename T = eg_type<E>*/>
template<Color strong> inline Value Endgame<E>::krc_kcnn_0p_2p(const Position& pos, Score& score) const {

	return VALUE_NONE;
}

template<EndgameType E/*, typename T = eg_type<E>*/>
template<Color strong> inline Value Endgame<E>::krc_kcnn_1p_2p(const Position& pos, Score& score) const {
	return VALUE_NONE;
}

template<EndgameType E/*, typename T = eg_type<E>*/>
template<Color strong> inline Value Endgame<E>::krc_kcnn_2p_2p(const Position& pos, Score& score) const {
	return VALUE_NONE;
}
