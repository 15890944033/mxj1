#include "endgame.h"

template<>
Value Endgame<KRNKCNN>::operator()(const Position& pos, Score& score) const {

	//�г����޳��������� 
	int nbpStrong, vpWeak;
	BishopAdvisorNum baStrg, baWeak;

	nbpStrong = strongSide == WHITE ? pos.pawn_nobottomcount<WHITE>() : pos.pawn_nobottomcount<BLACK>();
	vpWeak = strongSide == WHITE ? pos.pawn_validcount<BLACK>() : pos.pawn_validcount<WHITE>();
	baStrg = strongSide == WHITE ? pos.ba_number<WHITE>() : pos.ba_number<BLACK>();
	baWeak = strongSide == WHITE ? pos.ba_number<BLACK>() : pos.ba_number<WHITE>();

	Value v = nbpStrong > 0 ? RookVsNoRookWithPawn /*+ nbpStrong * Value(25)*/ : RookVsNoRookWithoutPawn;
	update_score(score, strongSide, v);

	if (baStrg >= BA_DBA && baWeak >= BA_DBA && nbpStrong == 0 && vpWeak < 3)
		return 	update_score_limit(score, -PAWN_END_40P);


	FUN_IMPL_DIFF_PIECES_ALL(krn_kcnn)
}

template<EndgameType E/*, typename T = eg_type<E>*/>
template<Color strong> inline Value Endgame<E>::krn_kcnn_0p_0p(const Position& pos, Score& score) const {
	
	return VALUE_NONE;
}

template<EndgameType E/*, typename T = eg_type<E>*/>
template<Color strong> inline Value Endgame<E>::krn_kcnn_1p_0p(const Position& pos, Score& score) const {
	return VALUE_NONE;
}

template<EndgameType E/*, typename T = eg_type<E>*/>
template<Color strong> inline Value Endgame<E>::krn_kcnn_2p_0p(const Position& pos, Score& score) const {
	return VALUE_NONE;
}

template<EndgameType E/*, typename T = eg_type<E>*/>
template<Color strong> inline Value Endgame<E>::krn_kcnn_0p_1p(const Position& pos, Score& score) const {

	return VALUE_NONE;
}

template<EndgameType E/*, typename T = eg_type<E>*/>
template<Color strong> inline Value Endgame<E>::krn_kcnn_1p_1p(const Position& pos, Score& score) const {
	return VALUE_NONE;
}

template<EndgameType E/*, typename T = eg_type<E>*/>
template<Color strong> inline Value Endgame<E>::krn_kcnn_2p_1p(const Position& pos, Score& score) const {
	return VALUE_NONE;
}



template<EndgameType E/*, typename T = eg_type<E>*/>
template<Color strong> inline Value Endgame<E>::krn_kcnn_0p_2p(const Position& pos, Score& score) const {

	return VALUE_NONE;
}

template<EndgameType E/*, typename T = eg_type<E>*/>
template<Color strong> inline Value Endgame<E>::krn_kcnn_1p_2p(const Position& pos, Score& score) const {
	return VALUE_NONE;
}

template<EndgameType E/*, typename T = eg_type<E>*/>
template<Color strong> inline Value Endgame<E>::krn_kcnn_2p_2p(const Position& pos, Score& score) const {
	return VALUE_NONE;
}


