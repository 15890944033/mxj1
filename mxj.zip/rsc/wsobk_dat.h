#ifndef WSOBK_DAT_H
#define WSOBK_DAT_H
extern const unsigned char wsobk_tab[];
extern const unsigned long wsobk_bytes;
#endif
