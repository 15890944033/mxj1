#include "endgame.h"


template<EndgameType E/*, typename T = eg_type<E>*/>
template<Color c>
inline void Endgame<E>::rr_cn_total(const Position& pos, Score& score) const {
	Value v = VALUE_ZERO;
	const Color Them = c == WHITE ? BLACK : WHITE;

	//�����ڵף��۷�
	if (!pos.is_king_bottom(Them))
		v = BISHOP_END_110P;

	update_score(score, c, v);

	ba_adjust_strong<c>(pos, score, VALUE_BA_ADJUST_MAX_UL);

}

template<>
Value Endgame<KRRKCN>::operator()(const Position& pos, Score& score) const {
	strongSide == WHITE ? rr_cn_total<WHITE>(pos, score) : rr_cn_total<BLACK>(pos, score);

	FUN_IMPL_DIFF_PIECES_ALL(krr_kcn)
}

template<EndgameType E/*, typename T = eg_type<E>*/>
template<Color strong> inline Value Endgame<E>::krr_kcn_0p_0p(const Position& pos, Score& score) const {
	I_AM_WEAK
	//�������ڵ���
	if (pos.full_ba(weak) && pos.pawn_bottomcount<strong>() == 0 && pos.is_king_bottom(weak)) {
		//˫������·���ײ��������ڱ������ۣ����ڷ���λ��
		if (bishop_bottom_ring<weak>(pos) && is_kn_defense<weak>(pos)) {
			Square csq = pos.square(weak, CANNON);
			Square bsq = lsb(pos.pieces(weak, BISHOP) & AreaThreeSevenFile);
			if(!same_flank(csq, bsq))
				return 	update_score_limit(score,  -KNIGHT_END_40P);
		}
	}
	return VALUE_NONE;

}
//����ʤ˫�ڵ�ȱ��		���߱�ʤ˫��˫��
template<EndgameType E/*, typename T = eg_type<E>*/>
template<Color strong> inline Value Endgame<E>::krr_kcn_1p_0p(const Position& pos, Score& score) const {
	return VALUE_NONE;

}

template<EndgameType E/*, typename T = eg_type<E>*/>
template<Color strong> inline Value Endgame<E>::krr_kcn_2p_0p(const Position& pos, Score& score) const {
	return VALUE_NONE;
}

template<EndgameType E/*, typename T = eg_type<E>*/>
template<Color strong> inline Value Endgame<E>::krr_kcn_0p_1p(const Position& pos, Score& score) const {
	return krr_kcn_0p_0p<strong>(pos, score);
}

template<EndgameType E/*, typename T = eg_type<E>*/>
template<Color strong> inline Value Endgame<E>::krr_kcn_1p_1p(const Position& pos, Score& score) const {
	return VALUE_NONE;
}

template<EndgameType E/*, typename T = eg_type<E>*/>
template<Color strong> inline Value Endgame<E>::krr_kcn_2p_1p(const Position& pos, Score& score) const {
	return VALUE_NONE;
}

template<EndgameType E/*, typename T = eg_type<E>*/>
template<Color strong> inline Value Endgame<E>::krr_kcn_0p_2p(const Position& pos, Score& score) const {
	I_AM_WEAK

	if (pos.is_pawns_partner_midhigh<weak>()) {
		if (pos.count(weak, ADVISOR) == 2 && pos.is_king_bottom(weak) && pos.pawn_bottomcount<strong>() == 0)
			return 	update_score_limit(score, -KNIGHT_END_40P);
	}

	return krr_kcn_0p_0p<strong>(pos, score);
}

template<EndgameType E/*, typename T = eg_type<E>*/>
template<Color strong> inline Value Endgame<E>::krr_kcn_1p_2p(const Position& pos, Score& score) const {
	return VALUE_NONE;
}

template<EndgameType E/*, typename T = eg_type<E>*/>
template<Color strong> inline Value Endgame<E>::krr_kcn_2p_2p(const Position& pos, Score& score) const {
	return VALUE_NONE;
}

