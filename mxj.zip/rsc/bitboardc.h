#if !defined(BITBOARDC_H_INCLUDED)
#define BITBOARDC_H_INCLUDED

#include <vector>
#include <set>

#include "types.h"
#include "bitboard.h"

typedef std::vector<Square>		vSquare;

const int KnightPinTotal = 4096;		//max: 90 + 4 *90 + 8 *90 = 1170
const int BishopPinTotal = 128;		//max: 77*8+75*4+59 

									//const int RankNum[] = {0, 9, 18, 27, 36, 36, 27, 18, 9, 0};

extern Square	SquareMap[128];
//extern int		SquareDistance[SQUARE_NB][SQUARE_NB];
//extern uint32_t allKnightPin[SQUARE_NB];
extern Square	sqKnightPin[SQUARE_NB][SQUARE_NB];
//extern Square	sqKnightNulDst[128][128];
//extern Square	sqBishopEye[128][128];
extern Square   sqBishopNotReach[SQUARE_NB][SQUARE_NB];
//extern SquarePair	pairKnightPin[128][128];
//extern Square	SquareColorMap[2][64];
//extern uint8_t KPDistance[128][128];

//���Ҳ��ߵ�
const File  FileRibFlank[2] = { FILE_D, FILE_F };

#if defined(IS_64BIT)
const BitboardC	bcZero = _mm_setzero_si128();	//CPUID Flags: SSE2
#else
const BitboardC	bcZero = merge64(0, 0);
#endif

const BitboardC	LegalAllOneBC = merge64(LegalAllOneBB, LegalAllOneBB);		//45��1������64��1
const BitboardC	IllegalAllOneBC = merge64(IllegalAllOneBB, IllegalAllOneBB);	//19��1 + 45��0

const BitboardC	FileABC = merge64(FileABB, FileABB);
const BitboardC	FileBBC = merge64(FileBBB, FileBBB);
const BitboardC	FileCBC = merge64(FileCBB, FileCBB);
const BitboardC	FileDBC = merge64(FileDBB, FileDBB);
const BitboardC	FileEBC = merge64(FileEBB, FileEBB);
const BitboardC	FileFBC = merge64(FileFBB, FileFBB);
const BitboardC	FileGBC = merge64(FileGBB, FileGBB);
const BitboardC	FileHBC = merge64(FileHBB, FileHBB);
const BitboardC	FileIBC = merge64(FileIBB, FileIBB);

const BitboardC	Rank1BC = merge64(Rank1BB, 0);
const BitboardC	Rank2BC = merge64(Rank2BB, 0);
const BitboardC	Rank3BC = merge64(Rank3BB, 0);
const BitboardC	Rank4BC = merge64(Rank4BB, 0);
const BitboardC	Rank5BC = merge64(Rank5BB, 0);
const BitboardC	Rank6BC = merge64(0, Rank5BB);
const BitboardC	Rank7BC = merge64(0, Rank4BB);
const BitboardC	Rank8BC = merge64(0, Rank3BB);
const BitboardC	Rank9BC = merge64(0, Rank2BB);
const BitboardC	Rank10BC = merge64(0, Rank1BB);
//�Ź�
const BitboardC	FortBC = merge64(FortBB, FortBB);
//˫��������
const BitboardC	AreaLow3Rank = merge64(Rank1BB | Rank2BB | Rank3BB, Rank1BB | Rank2BB | Rank3BB);
//˫���ĵ���
const BitboardC	BottomBC = merge64(Rank1BB, Rank1BB);
//˫���ķǵ���
const BitboardC	NoBottomBC = merge64(Rank2BB | Rank3BB | Rank4BB | Rank5BB, Rank2BB | Rank3BB | Rank4BB | Rank5BB);
//˫������¥������������¥���ж�
const BitboardC	Rank3FLOOR = merge64(Rank3BB, Rank3BB);
//˫����2¥��������2¥���ж�
const BitboardC	Rank2FLOOR = merge64(Rank2BB, Rank2BB);
//˫���ĵ�λ
const BitboardC	LowRankBC = merge64(Rank2BB | Rank3BB, Rank2BB | Rank3BB);
//˫�����¶��ߣ������ߺ��϶���
const BitboardC	Rank2Rank3Rank4 = merge64(Rank2BB | Rank3BB | Rank4BB, Rank2BB | Rank3BB | Rank4BB);
//˫����ԭλλ��
const BitboardC	AreaPawnOrg = merge64(45768245248, 45768245248);
//˫������Σ�ձ�����
const BitboardC	AreaExtremDangerPawn = merge64(32569344, 32569344);
//E1 E10 E2 E9
const BitboardC	AreaKingMidTwo = merge64(0x2010ULL, 0x2010ULL);
//˫ʿ��ԭλ
const BitboardC	AreaDualAdvisorOrg = merge64(DualAdvisorBB, DualAdvisorBB);
//˫ʿ������ԭλ
const BitboardC	DualAdvisorKingOrg = merge64(56, 56);
//���ʿλ��
const BitboardC	AreaAdvisorCavel = merge64(AdvisorCavelBB, AdvisorCavelBB);
//������λ��
const BitboardC	AreaWoxinKnight = merge64(8192, 8192);
//����λ��
const BitboardC	AreaMidBishop = merge64(0x400000ULL, 0x400000ULL);
//����λ��
const BitboardC	AreaHighBishop = merge64(0x44000000000ULL, 0x44000000000ULL);
//����λ��
const BitboardC	AreaBottomBishop = merge64(68, 68);
//����λ��
const BitboardC	AreaBorderBishop = merge64(67371008, 67371008);
//�¶��ߣ�B,H��λ�ã������Թҽǽ����������ױ�׽����λ��
const BitboardC	AreaDangerKnight = merge64(66560, 66560);
//���ڸ�λ 
const BitboardC	AreaHighRook = merge64(Rank4BB | Rank5BB, Rank4BB | Rank5BB);
//ԭλ��λ��
const BitboardC	AreaKingOrg = merge64(16, 16);
//ԭλ��λ��
const BitboardC	AreaCannonOrg = merge64(34078720, 34078720);
//˫������λ��
const BitboardC	AreaDbMonster = merge64(20480, 20480);
//����ʿ��ȫλ��1
const BitboardC	AreaPawnCrackBa1 = merge64(4311748608, 4311748608);
//����ʿ��ȫλ��2
const BitboardC	AreaPawnCrackBa2 = merge64(1074806784, 1074806784);
//�ǵ��߾Ź�
const BitboardC	AreaNoBottomFort = merge64(0xE07000ULL, 0xE07000ULL);
//�м�����
const BitboardC	AreaMid3File = merge64(FileDBB | FileEBB | FileFBB, FileDBB | FileEBB | FileFBB);
//�м�����
const BitboardC	AreaMid5File = merge64(FileCBB | FileDBB | FileEBB | FileFBB | FileGBB, FileCBB | FileDBB | FileEBB | FileFBB | FileGBB);
//ABC GHI ��������������
const BitboardC	AreaSide3File = merge64(FileABB | FileBBB | FileCBB | FileGBB | FileHBB | FileIBB,
	FileABB | FileBBB | FileCBB | FileGBB | FileHBB | FileIBB);
//AB HI ��2������2��
const BitboardC	AreaSide2File = merge64(FileABB | FileBBB | FileHBB | FileIBB, FileABB | FileBBB | FileHBB | FileIBB);
//��A�к�I��
const BitboardC	AreaNoBorderFile = merge64(FileBBB | FileCBB | FileDBB | FileEBB | FileFBB | FileGBB | FileHBB,
	FileBBB | FileCBB | FileDBB | FileEBB | FileFBB | FileGBB | FileHBB);
//A�к�I��
const BitboardC	AreaBorderFile = merge64(FileABB | FileIBB, FileABB | FileIBB);
//C�к�G�� ������
const BitboardC	AreaThreeSevenFile = merge64(FileCBB | FileGBB, FileCBB | FileGBB);
//B+C�� �� G+H��
const BitboardC	AreaTwoThreeSevenEightFile = merge64(FileBBB | FileCBB | FileGBB | FileHBB, FileBBB | FileCBB | FileGBB | FileHBB);
//�ߵ�  D F ��
const BitboardC	AreaLeidaoFile = merge64(FileDBB | FileFBB, FileDBB | FileFBB);
//���̱߽�
const BitboardC	AreaAllBorder = merge64(Rank1BB | FileABB | FileIBB, Rank1BB | FileABB | FileIBB);
//��������
const BitboardC	AreaBishopEye = merge64(22817100800, 22817100800);
//������λ��
const BitboardC	AreaFishKnight = merge64(17825792, 17825792);
//C D F G�� 
const BitboardC	ThreeFourFile = merge64(FileCBB | FileDBB | FileFBB | FileGBB, FileCBB | FileDBB | FileFBB | FileGBB);
//B��C��2��4, 6���㣬 һ��4������
const BitboardC	KnightControled = merge64(13716999168, 13716999168);

//���Ҳ������߱���λ��
const BitboardC	Low3PawnFlankBC[2] = { merge64(0x3C0000ULL, 0x3C0000ULL), merge64(0x7800000ULL, 0x7800000ULL) };
//���Ҳ��¶��߱���λ��
const BitboardC	Low2PawnFlankBC[2] = { merge64(0x1E00ULL, 0x1E00ULL), merge64(0x3C000ULL, 0x3C000ULL) };
//���Ҳ�ͱ������߼����ߣ���λ��
const BitboardC	LowPawnFlankBC[2] = { merge64(0x3C1E00ULL, 0x3C1E00ULL), merge64(0x783C000ULL, 0x783C000ULL) };
//���Ҳ�  ����������
const BitboardC	FlankBoardBC[2] = { merge64(0xF0783C1E0FULL, 0xF0783C1E0FULL), merge64(0x1E0F0783C1E0ULL, 0x1E0F0783C1E0ULL) };
//���Ҳ�  ��������
const BitboardC	FlankMidBoardBC[2] = { merge64(0xF0783C1E0FULL | FileEBB, 0xF0783C1E0FULL | FileEBB), merge64(0x1E0F0783C1E0ULL | FileEBB, 0x1E0F0783C1E0ULL | FileEBB) };
//���A��B�� �Ҳ�H��I�� ���ڳ������ж�
const BitboardC	SideTwoFileBC[2] = { merge64(206561871363, 206561871363), merge64(26439919534464, 26439919534464) };
//����ߵ�D�� �Ҳ��ߵ�F��
const BitboardC	RibFileBC[2] = { FileDBC, FileFBC };
//���Ҳ��Σ�ձ�λ�� �����������ߣ�
const BitboardC	FlankDangerPawn[2] = { merge64(3151872, 3151872), merge64(25214976, 25214976) };
//������ʿ��ȫλ�ã�������2��
const BitboardC	TripPawnFullBa[2] = { merge64(1074806784, 1074806784), merge64(4311748608, 4311748608) };
//˫ʿ������0�� ���ʿ֧�� 1 ���ұ�ʿ֧��
const BitboardC	DualAdvisorKingDirection[2] = { merge64(8240, 8240), merge64(8216, 8216) };
//���Ҳ��ʿλ�� 
const BitboardC	BottomAdvisorFlank[2] = { merge64(8, 8), merge64(32, 32) };
//���Ҳ�ı�������
const BitboardC	Side3FileFlank[2] = { merge64(FileABB | FileBBB | FileCBB, FileABB | FileBBB | FileCBB), 
	merge64(FileGBB | FileHBB | FileIBB, FileGBB | FileHBB | FileIBB) };
//���Ҳ�ĵ��ߵ�����4��
const BitboardC	BottomSide4File[2] = { merge64(15, 15),  merge64(480, 480) };

//home side
const BitboardC	HomeSideBC[2] = { merge64(LegalAllOneBB, 0), merge64(0, LegalAllOneBB) };
//˫��������λ��
const BitboardC	WoxinKnightBC[2] = { merge64(8192, 0), merge64(0, 8192) };
//˫���Ĺ��Ӹ߱�λ��
const BitboardC	HighPawnBC[2] = { merge64(0, Rank4BB | Rank5BB), merge64(Rank4BB | Rank5BB, 0) };
//˫���Ĺ��Ӹ߱������м����е�λ��
const BitboardC	HighPawnMid3[2] = { merge64(0, 3855806889984), merge64(3855806889984, 0) };
//��ԭλ
const BitboardC	KingOrgBC[2] = { merge64(16, 0), merge64(0, 16) };
//ԭʼ�б�λ��ԭ�ڳ����о�
//const BitboardC	MidPawnOrgBC[2] = { merge64(0x80000000ULL, 0), merge64(0, 0x80000000ULL) };
//˫���ĵ���
const BitboardC	BottomRankBC[2] = { Rank1BC, Rank10BC };
//˫���ķǵ���
const BitboardC	NoBottomRankBC[2] = { merge64(0x1FFFFFFFFE00ULL, 0), merge64(0, 0x1FFFFFFFFE00ULL) };
//˫�����Ľ���Ҫ��
const BitboardC	KnightAttackBC[2] = { merge64(17454747090944, 17488972479999), merge64(17488972479999, 17454747090944) };
//˫�����ķ���Ҫ��(�Է��ޱ�)
const BitboardC	KnightDefenseBC[2] = { merge64(0x7C3E1F0006CULL, 0), merge64(0, 0x7C3E1F0006CULL) };
//˫�����ķ���Ҫ��(�Է��б�)
const BitboardC	KnightDefenseAgPawnBC[2] = { merge64(0x7C3E1F00000ULL, 0x7C000000000ULL), merge64(0x7C000000000ULL, 0x7C3E1F00000ULL) };
//������ʱ˫�����Ľ���Ҫ��
const BitboardC	KnightAttackMidCn[2] = { merge64(5772436045824, 17523466407407), merge64(17523466407407, 5772436045824) };
//˫�����ӱ����ֽ��з���
const BitboardC	PawnPartnerBC[2] = { merge64(0, 0x7C3E0000000ULL), merge64(0x7C3E0000000ULL, 0) };
//˫���Ź�
const BitboardC	FortSide[2] = { merge64(14708792, 0), merge64(0, 14708792)};
//˫�����Ϸ�λ��
const BitboardC	PawnLegalBC[2] = { merge64(0x155AA8000000ULL, LegalAllOneBB), merge64(LegalAllOneBB, 0x155AA8000000ULL) };
//˫����Ϸ�λ��
const BitboardC	BishopLegalBC[2] = { merge64(0x44004440044ULL, 0), merge64(0, 0x44004440044ULL) };
//˫���˺Ϸ�λ��
const BitboardC	AdvisorLegalBC[2] = { merge64(10493992, 0), merge64(0, 10493992) };
//˫���϶��߹��ӱ������ڹ��ӱ�����
const BitboardC	PawnCrHigh2Rank[2] = { merge64(0, Rank4BB), merge64(Rank4BB, 0) };
//���ֵ�������
const BitboardC	EnemyBottom3Rank[2] = { merge64(0, Rank1BB | Rank2BB | Rank3BB), merge64(Rank1BB | Rank2BB | Rank3BB, 0) };
//˫�����߻����Եĵ㣬ȥ���Լ��ҵ����̱߽�
const BitboardC	KnightHighMob[2] = { merge64(35184304585728, LegalAllOneBB), merge64(LegalAllOneBB, 35184304585728) };
//˫���ں�ʿ��ϵĽ���λ�ã��Ź����ߺ��¶������ų�����
const BitboardC	CannonAdvisorAttack[2] = { merge64(28728, 0), merge64(0, 28728) };
//˫���ڷ���λ�ã���ʿ�����ʿλ��
//const BitboardC	CannonAdvisorDefense[2] = { merge64(10485800, 0), merge64(0, 10485800) };
//˫�������������Ժ���λ��
const BitboardC	KnightThreeBishop[2] = { merge64(0x28220400000ULL, 0), merge64(0, 0x28220400000ULL) };
//˫����ʿλ�� 
const BitboardC	BottomAdvisorSide[2] = { merge64(40, 0), merge64(0, 40) };
//�Ź����������ߵ����е�
const BitboardC	FortNoBottom[2] = { merge64(28728, 0), merge64(0, 28728) };
//˫�������б߽�
const BitboardC	AllBorderSide[2] = { merge64(Rank1BB | FileABB | FileIBB, 0),  merge64(0, Rank1BB | FileABB | FileIBB)};
//˫���ĵ��ߵ���������
const BitboardC	BottomSide3File[2] = { merge64(455, 0),  merge64(0, 455) };
//���ӷǵ���λ��
const BitboardC	CrossRiverNoBottom[2] = { merge64(0, 35184372088320),  merge64(35184372088320, 0) };
//���ӷǵ��߷Ǳ���λ��
const BitboardC	CrossRiverNoBottomNoBorder[2] = { merge64(0, 17488905108480),  merge64(17488905108480, 0) };
//˫��Σ�ձ�����
const BitboardC	DangerPawnSide[2] = { merge64(0, 16675567616),  merge64(16675567616, 0) };

//˫���Ź����ڵ��к���
const BitboardC FortRankFile[2] = { merge64(Rank1BB | Rank2BB | Rank3BB | FileDBB | FileEBB | FileFBB, FileDBB | FileEBB | FileFBB),
merge64(FileDBB | FileEBB | FileFBB, Rank1BB | Rank2BB | Rank3BB | FileDBB | FileEBB | FileFBB) };
//���������Ƶ�λ�� �� [Color][Flank] 
const BitboardC	KnightControlByPawn[2][2] = { { merge64(1838599, 0), merge64(117670336, 0) },{ merge64(0, 1838599), merge64(0, 117670336) } };

extern BitboardC SquareBC[128];
extern BitboardC ReverseSquareBC[128];
extern BitboardC NotRowBC[SQUARE_NB];
extern BitboardC SameRowBC[SQUARE_NB];
extern BitboardC KingRing[SQUARE_NB];
extern BitboardC KingRingPawn[SQUARE_NB];
extern BitboardC KnightPinFrom[SQUARE_NB];
extern BitboardC KnightPinTo[SQUARE_NB];
extern BitboardC BishopPin[SQUARE_NB];
extern BitboardC PseudoAttacksRook[SQUARE_NB];

extern BitboardC FileBC[16];
extern BitboardC RankBC[16];
extern BitboardC ReverseFileBC[16];
extern BitboardC ReverseRankBC[16];
extern BitboardC AdjacentFilesBC[16];

extern BitboardC FileRankDirBC[SQUARE_NB][4];

extern BitboardC AttacksRookRankBC[SQUARE_NB][128];

extern BitboardC AttacksRookFileBC[SQUARE_NB][256];

extern BitboardC AttacksCannonRankBC[SQUARE_NB][128];
extern BitboardC AttacksCannonFileBC[SQUARE_NB][256];
extern BitboardC PseudoAttacks[PIECE_TYPE_NB][SQUARE_NB];
extern BitboardC PawnAttackingBC[2][SQUARE_NB];
extern BitboardC PawnAttackedBC[2][SQUARE_NB];
extern BitboardC BetweenBC[SQUARE_NB][SQUARE_NB];
extern BitboardC LineBC[SQUARE_NB][SQUARE_NB];
extern BitboardC KnightNotReach[SQUARE_NB][SQUARE_NB];
//extern BitboardC PseudoAttacksBC[8][128];
//extern BitboardC KingRingBC[2][128];
extern BitboardC InFrontBC[COLOR_NB][RANK_NB];
extern BitboardC ForwardBC[COLOR_NB][SQUARE_NB];
extern BitboardC KnightReachedPinFrom[SQUARE_NB][KnightPinTotal];
extern BitboardC KnightReachedPinTo[SQUARE_NB][KnightPinTotal];
//extern BitboardC* KnightReachedPinFrom;
//extern BitboardC* KnightReachedPinTo;
extern BitboardC BishopReachedPin[SQUARE_NB][BishopPinTotal];

extern std::set<Square> setBishopLegal;

namespace BitboardCs {

	void init();
	void init_bishop_legal();

	void init_squaremap();
	//void init_squaredistance();
	void init_square_bc();
	void init_file_rank_bc();
	void init_row_bc();
	void init_kingring_bc();
	void init_reverse_squarebc();
	void init_knight_pin();
	void init_bishop_pin();

	//void init_bishop_eye_square();
	void init_stepattacks_bishop();
	void init_stepattacks_advisor();
	void init_stepattacks_knight();
	void init_stepattacks_rk_cn();
	void init_stepattacks_king();

	void init_move_pawn();
	//void init_pseudo_attack();
	void init_between();
	void init_line();
	void init_knight_notreach();
	void init_bishop_notreach();
	//void init_king_ring();
	//void init_kp_distance();
	void init_front_bc();

	void init_knight_pin_square();
	void init_knight_pin_bc();
	void init_knight_reach_pin();
	void init_bishop_reach_pin();
	void init_filerank_dir();

	//void init_knight_center_pin(const Square s);
	//void init_knight_lefta_pin(const Square s);
	//void init_knight_leftb_pin(const Square s);
	//void init_knight_righti_pin(const Square s);
	//void init_knight_righth_pin(const Square s);
	//void init_knight_pin_pair();

	void computer_knight_full_nocross(const Square s);
	void computer_knight_full_cross2(const Square s);
	void computer_knight_full_cross4(const Square s);
	void computer_knight_4(const Square s);
	void computer_knight_6(const Square s);
	void computer_rook_square(const Square s, const bool bRank, vSquare& vSq);

	//template <PieceType pt>	void init_stepattacks_rookcannon();

	void print(const BitboardC b);

	Bitboard	vec_bb(const vSquare& vSq);
	Bitboard	fileno_bb(const File fileIn);

	BitboardC	calc_rook_rank(const Square s, int piece_bit);
	BitboardC	calc_rook_file(const Square s, int piece_bit);

	BitboardC	calc_cannon_rank(const Square s, int piece_bit);
	BitboardC	calc_cannon_file(const Square s, int piece_bit);

	void		calc_kinght_pin(const Square s, const Square* pin, const BitboardC* bcPin, BitboardC* target);
	//void		calc_kinght_pin_to(const Square s, const Square* pin, const BitboardC* bcPin);


}


inline bool operator==(const BitboardC bc1, const BitboardC bc2)
{
#if defined(IS_64BIT) && defined(USE_SSE4)
	// _mm_cmpeq_epi64(bc1, bc2) ����ȫ1 ������ȫ���
	//return _mm_testc_si128(_mm_cmpeq_epi64(bc1, bc2), LegalAllOneBC);

	//return _mm_testc_si128(bcZero, _mm_xor_si128(bc1, bc2));	//CPUID Flags: SSE4.1	SSE2
	return _mm_testc_si128(bc1, bc2);	//CPUID Flags: SSE4.1	SSE2
#else
	return bc1.m128i_u64[0] == bc2.m128i_u64[0] && bc1.m128i_u64[1] == bc2.m128i_u64[1];
#endif
}

inline bool operator!=(const BitboardC bc1, const BitboardC bc2) {
	return !(bc1 == bc2);
}

//inline bool operator!(const BitboardC bc1) {
//	return bc1 == bcZero;
//}

inline BitboardC operator&(const BitboardC bc1, const BitboardC bc2)
{
#if defined(IS_64BIT)
	return _mm_and_si128(bc1, bc2);		//CPUID Flags: SSE2

#else
	BitboardC  cTmp;

	cTmp.m128i_u64[0] = bc1.m128i_u64[0] & bc2.m128i_u64[0];
	cTmp.m128i_u64[1] = bc1.m128i_u64[1] & bc2.m128i_u64[1];

	return cTmp;

#endif

}

inline bool operator&(const BitboardC bc, const Square s)
{
	return not_z(bc & SquareBC[s]);
}


inline BitboardC& operator&=(BitboardC& bc1, const BitboardC bc2)
{
#if defined(IS_64BIT)
	bc1 = _mm_and_si128(bc1, bc2);
	return bc1;
#else
	bc1.m128i_u64[0] &= bc2.m128i_u64[0];
	bc1.m128i_u64[1] &= bc2.m128i_u64[1];
	return bc1;
#endif

}


inline BitboardC& operator&=(BitboardC& bc1, const Square s)
{
#if defined(IS_64BIT)
	bc1 = _mm_and_si128(bc1, SquareBC[s]);
	return bc1;

#else
	bc1 &= SquareBC[s];
	return bc1;

#endif

}

inline BitboardC operator|(const BitboardC bc1, const BitboardC bc2)
{
#if defined(IS_64BIT)
	return _mm_or_si128(bc1, bc2);
#else
	BitboardC  cTmp;

	cTmp.m128i_u64[0] = bc1.m128i_u64[0] | bc2.m128i_u64[0];
	cTmp.m128i_u64[1] = bc1.m128i_u64[1] | bc2.m128i_u64[1];

	return cTmp;
#endif
}

inline BitboardC operator|(const BitboardC bc, const Square s)
{
#if defined(IS_64BIT)
	return _mm_or_si128(bc, SquareBC[s]);
#else
	return bc | SquareBC[s];
#endif

}

inline BitboardC operator|(const Square s1, const Square s2)
{
	return SquareBC[s1] | SquareBC[s2];
}

inline BitboardC& operator|=(BitboardC& bc1, const BitboardC bc2)
{
#if defined(IS_64BIT)
	bc1 = _mm_or_si128(bc1, bc2);
	return bc1;

#else
	bc1.m128i_u64[0] |= bc2.m128i_u64[0];
	bc1.m128i_u64[1] |= bc2.m128i_u64[1];
	return bc1;

#endif
}

inline BitboardC& operator|=(BitboardC& bc, const Square s)
{
#if defined(IS_64BIT)
	bc = _mm_or_si128(bc, SquareBC[s]);
	return bc;

#else
	bc |= SquareBC[s];
	return bc;
#endif

}


inline BitboardC& operator^=(BitboardC& bc1, const BitboardC bc2)
{
#if defined(IS_64BIT)
	bc1 = _mm_xor_si128(bc1, bc2);		//CPUID Flags: SSE2
	return bc1;

#else
	bc1.m128i_u64[0] ^= bc2.m128i_u64[0];
	bc1.m128i_u64[1] ^= bc2.m128i_u64[1];
	return bc1;
#endif

}

inline BitboardC& operator^=(BitboardC& bc, const Square s)
{
#if defined(IS_64BIT)
	return (bc = _mm_xor_si128(bc, SquareBC[s]));
#else
	bc ^= SquareBC[s];
	return bc;
#endif
}


inline BitboardC operator^(const BitboardC bc1, const BitboardC bc2)
{
#if defined(IS_64BIT)
	return _mm_xor_si128(bc1, bc2);

#else
	BitboardC  cTmp;

	cTmp.m128i_u64[0] = bc1.m128i_u64[0] ^ bc2.m128i_u64[0];
	cTmp.m128i_u64[1] = bc1.m128i_u64[1] ^ bc2.m128i_u64[1];

	return cTmp;
#endif

}

inline BitboardC operator^(const BitboardC bc, const Square s)
{
	return  bc ^ SquareBC[s];
}


inline BitboardC operator~(const BitboardC bc)
{
#if defined(IS_64BIT)
	return _mm_xor_si128(bc, LegalAllOneBC);		//��ȫ1 ���

#else
	BitboardC  cTmp;

	cTmp.m128i_u64[0] = (~bc.m128i_u64[0]) & LegalAllOneBB;
	cTmp.m128i_u64[1] = (~bc.m128i_u64[1]) & LegalAllOneBB;

	return cTmp;
#endif

}

inline BitboardC operator<<(const BitboardC& bc, const int n)
{
#if defined(IS_64BIT)
	return _mm_slli_epi64(bc, n);		//CPUID Flags: SSE2

#else

	BitboardC  cTmp;
	cTmp.m128i_u64[0] = bc.m128i_u64[0] << n;
	cTmp.m128i_u64[1] = bc.m128i_u64[1] << n;

	return cTmp;
#endif
}

inline BitboardC operator >> (const BitboardC& bc, const int n)
{
#if defined(IS_64BIT)
	return _mm_srli_epi64(bc, n);		//CPUID Flags: SSE2

#else
	BitboardC  cTmp = bc;
	cTmp.m128i_u64[0] >>= n;
	cTmp.m128i_u64[1] >>= n;

	return cTmp;
#endif

}


//// �������λ��1  �� 1000100  => 100  100 => 100	110 => 10
//inline BitboardC least_bit(const BitboardC& bc)
//{
//	Bitboard b = low64(bc);
//	if (b)
//	{
//		return _mm_cvtsi64_si128(b & ~(b - 1));  
//		//return merge64(b & ~(b - 1), 0);
//	}
//	else
//	{
//		Bitboard c = high64(bc);
//		return merge64(0, c & ~(c - 1));
//	}
//}


inline Square lsb(const BitboardC b) {
	assert(not_z(b));
	Bitboard c = low64(b);
	if (c)
		return lsb(c);
	else
		return ~msb(high64(b));
}

inline Square msb(const BitboardC b) {
	assert(not_z(b));
	Bitboard c = high64(b);
	if (c)
		return ~lsb(c);
	else
		return msb(low64(b));
}

/// pop_lsb() finds and clears the least significant bit in a non-zero bitboard
inline Square pop_lsb(BitboardC* b) {
	assert(not_z(*b));
	const Square s = lsb(*b);
	*b &= ReverseSquareBC[s];
	return s;
}


inline int total_square(BitboardC* b) {
	assert(not_z(*b));
	int r = pop_lsb(b);
	if (not_z(*b)) {
		r += (pop_lsb(b) << 3);
	}
	if (not_z(*b)) {
		r += (pop_lsb(b) << 4);
	}
	return r;

}
//���� ����square�Ĳ�ͬ��ϵ�ֵ 
inline Bitboard total_bpsquare(const Bitboard b) {
	assert(b);
	return ((b >> 11) & 0x0F) | (b >> 26);
}

inline Square pop_msb(BitboardC* b) {
	const Square s = msb(*b);
	if (s != SQ_NONE)
		*b &= ReverseSquareBC[s];
	return s;
}


/// distance() functions return the distance between x and y, defined as the
/// number of steps for a king in x to reach y. Works with squares, ranks, files.

template<typename T> inline int distance(T x, T y) { return x < y ? y - x : x - y; }
//template<> inline int distance<Square>(Square x, Square y) { return SquareDistance[x][y]; }

//template<typename T1, typename T2> inline int distance(T2 x, T2 y);
//template<> inline int distance<File>(Square x, Square y) { return distance(file_of(x), file_of(y)); }
//template<> inline int distance<Rank>(Square x, Square y) { return distance(rank_of(x), rank_of(y)); }

// �о�����о�������ֵ
//inline int square_distance(Square s1, Square s2) { return SquareDistance[s1][s2]; }

inline const BitboardC rank_bc(const Square s) {
	return RankBC[rank_of(s)];
}

inline const BitboardC file_bc(const Square s) {
	return FileBC[file_of(s)];
}

inline bool is_ok(const BitboardC b) {
	//return (low64(b) & IllegalAllOneBB) == 0 && (high64(b) & IllegalAllOneBB) == 0;
	return equal_z(IllegalAllOneBC & b);
}

// �Ӱ׷��Ƕ� ���б�ǰ��
inline BitboardC push_pawn(const BitboardC bc) {
	Bitboard b = (low64(bc) << NORTH) & LegalAllOneBB;
	// ����׷������Ӻ���ʧ�����⣬Ӧ���ںڷ�RANK_4�г���
	Bitboard c = ((high64(bc) >> NORTH) & LegalAllOneBB) | (b & Rank5BB);
	return  merge64(b, c);
}

// �Ӻڷ��Ƕ� ���б�ǰ��
inline BitboardC pull_pawn(const BitboardC bc) {
	Bitboard c = (high64(bc) << NORTH) & LegalAllOneBB;
	// ����ڷ������Ӻ���ʧ�����⣬Ӧ���ڰ׷�RANK_4�г���
	Bitboard b = ((low64(bc) >> NORTH) & LegalAllOneBB) | (c & Rank5BB);
	return merge64(b, c);
}


// ����λ���̵õ�ָ���еĶ������� 
// ��: ���ǣ�001101011 (���̴������Ǵӵ͵��ߣ��򷵻�ֵ�� �����ƣ�001101011
inline  Bitboard  RankIntFromBc(Rank r, const BitboardC bc) {
	//Bitboard b;
	//if (r > RANK_4)	{
	//	b = high64(bc);
	//	r = Rank(~r);
	//}
	//else{
	//	b = low64(bc);
	//}
	////return (b >> (RankNum[r])) & 0x1FF;		// 0x1FF == 111111111b
	//return (b >> ((r << 3) + r)) & 0x1FF;		// 0x1FF == 111111111b

	//BitboardC b = bc & RankBC[r];
	//return r > RANK_4 ? (high64(b) >> ((9 - r) * 9)) : (low64(b) >> (r * 9));

	Bitboard b;
	if (rank_color(r) == WHITE) {
		b = low64(bc) & RankBB[r];
	}
	else {
		r = ~r;
		b = high64(bc) & RankBB[r];
	}
	b >>= (r * 9 + 1); //+1���ܸ�
	return b & 127;
}


//inline Bitboard  FileIntB(const File f, const Bitboard b){
//	return ((b >> f) & SQ_A0) |
//		((b >> (f + 9 - 1)) & SQ_B0) |
//		((b >> (f + 18 - 2)) & SQ_C0) |
//		((b >> (f + 27 - 3)) & SQ_D0) |
//		((b >> (f + 36 - 4)) & SQ_E0);
//}

// ����λ���̵õ�ָ���еĶ������� 
// �ɵ�5λ �׷����� RANK_0...RANK_4  | ��5λ �ڷ�����RANK_0...RANK_4���
// ��: ���ǣ�001101011 (���̴��µ����Ǵӵ͵��ߣ��򷵻�ֵ�� �����ƣ�11000 01011
inline  Bitboard  FileIntFromBc(const File f, const BitboardC bc) {
	//return FileIntB(f, low64(bc)) | (FileIntB(f, high64(bc)) << 5);

	//�ٶ���һ��
	//BitboardC b = bc & FileBC[f];
	//b = b >> int(f);
	//Bitboard l = low64(b);
	//Bitboard h = high64(b);

	//Bitboard bb = _pext_u64(l, 68853957121);
	//bb |= (_pext_u64(h, 68853957121) << 5);
	//return bb;


	BitboardC b = bc & FileBC[f];
	b = b >> int(f);
	Bitboard l = low64(b);
	Bitboard h = high64(b);
	//�߽粻Ӱ���������Բ���Ҫ 
	Bitboard bb = ((l & (1ULL << 9)) >> 9);
	bb |= ((l & (1ULL << 18)) >> 17);
	bb |= ((l & (1ULL << 27)) >> 25);
	bb |= ((l & (1ULL << 36)) >> 33);

	bb |= ((h & (1ULL << 36)) >> 32);
	bb |= ((h & (1ULL << 27)) >> 22);
	bb |= ((h & (1ULL << 18)) >> 12);
	bb |= ((h & (1ULL << 9)) >> 2);

	return bb;
}
//���s1 s2 ���ڣ� Ҳ���� 0 
inline const BitboardC between_bc(const Square s1, const Square s2) {
	return BetweenBC[s1][s2];
}

// s1��s2��ͬ�л�ͬ�У����س�����ͬ�У��У������и��ӵ�λ����		�ٶ�s1 s2ͬ�л�ͬ��
inline BitboardC diff_line(const Square s1, const Square s2) {
	assert(s1 != s2);
	assert(is_same_row(s1, s2));
	if (file_of(s1) == file_of(s2)) return ReverseFileBC[file_of(s1)];
	else return ReverseRankBC[rank_of(s1)];
}


//s1: from s2: to
inline Square kn_pin(Square s1, Square s2) {
	return sqKnightPin[s1][s2];
}
//inline  void CReset(IN OUT BitboardC* arBc, const int size)
//{
//	for(int i = 0; i < size; ++i )
//	{
//		arBc[i] = bcZero;
//	}
//}

//// �ж��ںͶԷ����Ƿ��ͷ��ϵ
//// s s_k �ں����ĸ��� bc�����ӷֲ�λ����
//// ����ǿ�ͷ������������֮���λ���̣����򷵻�bcZero
////s�������s_k��bҲ��0���������ͷ
//inline BitboardC cannon_nulking(const Square s, const Square s_k, const BitboardC& occ)
//{
//	const BitboardC& b = between_bc(s, s_k);
//	return (not_z(b) && equal_z(b & occ)) ? b : bcZero;
//}

// s �Ƿ���s1,s2֮��(����s1 , s2)		s1  s2 ����ͬ�л�ͬ�� 
inline bool is_between(const Square s, const Square s1, const Square s2) {
	return BetweenBC[s1][s2] & s;
}

// s1�Ƿ���s2ǰ�� ��color���ĽǶ� ���ͬһ�У�����false
template<Color c>
inline bool front_square(const Square fs, const Square bs) {
	return ForwardBC[c][bs] & fs;
}

inline bool aligned(Square s1, Square s2, Square s3) {
	return LineBC[s1][s2] & s3;
}

inline bool is_bottom(const Square s) {
	return BottomBC & s;
}

inline int popcount(const BitboardC bc) {
	return popcount(low64(bc)) + popcount(high64(bc));
}
//pin: ��sλ���������ȵ�λ���̣� ���޸�pin��ֵ 
//from: true s => bc false  bc ==> s
template<bool from>
inline BitboardC knight_pin(const Square s, BitboardC& pin) {
	return from ? KnightReachedPinFrom[s][total_square(&pin)] : KnightReachedPinTo[s][total_square(&pin)];
}
//pin: ��sλ���۵�λ���̣� ���޸�pin��ֵ 
template<Color c>
inline BitboardC midbishop_pin(const Square s, const BitboardC pin) {
	return BishopReachedPin[s][total_bpsquare(c == WHITE ? low64(pin) : high64(pin))];
}

inline bool bishop_square(Square s) {
	return setBishopLegal.find(s) != setBishopLegal.end();
}

// �ж����Ƿ����ڽ���
// s s_k �ں����ĸ��� bc�����ӷֲ�λ���� 
inline bool is_cannon_checking(const Square s, const Square s_k, const BitboardC bc) {
	return popcount(between_bc(s, s_k) & bc) == 1;
}

inline Direct move_direct(Square from, Square to) {
	assert(is_same_row(from, to) && from != to);
	Rank rf = rank_of(from);
	Rank rt = rank_of(to);
	if (rt > rf)
		return NORTH_DIR;
	else if (rt < rf)
		return SOUTH_DIR;
	return file_of(from) > file_of(to) ? WEST_DIR : EAST_DIR;
}

inline BitboardC side_file(File f, Direct d) {
	assert(d == WEST_DIR || d == EAST_DIR);
	BitboardC bc = bcZero;
	if (d == WEST_DIR) {
		for (File fl = FILE_A; fl < f; ++fl) {
			bc |= FileBC[fl];
		}
	}
	else {
		for (File fl = f + File(1); fl <= FILE_I; ++fl) {
			bc |= FileBC[fl];
		}
	}

	return bc;
}
//����ѹס��s�������Square, ǰ�᣺ s�������̱߽�
inline Square press_border_knight(const Square s) {
	assert(AreaAllBorder & s);
	Rank r = rank_of(s);
	File f = file_of(s);
	if (r == RANK_0)
		return make_square(f, RANK_1);
	else if (r == RANK_9)
		return make_square(f, RANK_8);
	else if (f == FILE_A)
		return make_square(FILE_B, r);
	else if (f == FILE_I)
		return make_square(FILE_H, r);

	assert(0);
	return s;

}
//���Ժ���
inline bool verify_knight_pin_arr(Square* pin) {
	std::set<int> setTotal;
	std::set<Square> setSq;
	for (int i = 0; i < 4; ++i) {
		if (pin[i] != SQ_NONE) {
			auto it = setSq.insert(pin[i]);
			if (!it.second)
				return false;
		}
	}
	BitboardC bc;
	size_t setsize = setSq.size();
	auto it_sq = setSq.begin();
	auto it_index = it_sq;
	if (setsize >= 2) {
		++it_index;
		bc = (*it_sq) | *(it_index);
		auto it = setTotal.insert(total_square(&bc));
		if (!it.second)
			return false;
	}
	if (setsize >= 3) {
		it_index = it_sq;
		++it_index;
		++it_index;
		bc = (*it_sq) | *(it_index);
		auto it = setTotal.insert(total_square(&bc));
		if (!it.second)
			return false;

		it_index = it_sq;
		++it_index;
		bc = (*it_index) | *(++it_index);
		it = setTotal.insert(total_square(&bc));
		if (!it.second)
			return false;

	}
	if (setsize == 4) {
		it_index = it_sq;
		++it_index;
		auto it_last = it_sq;
		++it_last;
		++it_last;
		//1*2*3
		bc = (*it_sq) | (*it_index) | *(it_last);
		auto it = setTotal.insert(total_square(&bc));
		if (!it.second)
			return false;

		//1*2*4
		++it_last;
		bc = (*it_sq) | (*it_index) | *(it_last);
		it = setTotal.insert(total_square(&bc));
		if (!it.second)
			return false;

		//1*3*4
		++it_index;
		bc = (*it_sq) | (*it_index) | *(it_last);
		it = setTotal.insert(total_square(&bc));
		if (!it.second)
			return false;

		//2*3*4
		auto it_second = it_sq;
		++it_second;
		bc = (*it_second) | (*it_index) | *(it_last);
		it = setTotal.insert(total_square(&bc));
		if (!it.second)
			return false;

	}
	return true;
}

//���Ժ���
inline bool verify_knight_pin_total(Square s) {
	Square pin[4] = { SQ_NONE, SQ_NONE , SQ_NONE , SQ_NONE };
	File f = file_of(s);
	Rank r = rank_of(s);

	if (f >= FILE_C && f <= FILE_G) {
		if (r >= RANK_2 && r <= RANK_7) {
			pin[0] = s + WEST;
			pin[1] = s + NORTH;
			pin[2] = s + EAST;
			pin[3] = s + SOUTH;
		}
		else if (r <= RANK_1) {
			pin[0] = s + WEST;
			pin[1] = s + NORTH;
			pin[2] = s + EAST;
		}
		else {
			pin[0] = s + WEST;
			pin[2] = s + EAST;
			pin[3] = s + SOUTH;
		}
	}
	else if (f <= FILE_B) {
		if (r >= RANK_2 && r <= RANK_7) {
			pin[1] = s + NORTH;
			pin[2] = s + EAST;
			pin[3] = s + SOUTH;
		}
		else if (r <= RANK_1) {
			pin[1] = s + NORTH;
			pin[2] = s + EAST;
		}
		else {
			pin[2] = s + EAST;
			pin[3] = s + SOUTH;
		}
	}
	else {
		if (r >= RANK_2 && r <= RANK_7) {
			pin[0] = s + WEST;
			pin[1] = s + NORTH;
			pin[3] = s + SOUTH;
		}
		else if (r <= RANK_1) {
			pin[0] = s + WEST;
			pin[1] = s + NORTH;
		}
		else {
			pin[0] = s + WEST;
			pin[3] = s + SOUTH;
		}
	}

	if (!verify_knight_pin_arr(pin)) return false;


	pin[0] = pin[1] = pin[2] = pin[3] = SQ_NONE;

	if (f >= FILE_B && f <= FILE_H) {
		if (r >= RANK_1 && r <= RANK_8) {
			pin[0] = s + NORTH_WEST;
			pin[1] = s + SOUTH_WEST;
			pin[2] = s + NORTH_EAST;
			pin[3] = s + SOUTH_EAST;
		}
		else if (r == RANK_0) {
			pin[0] = s + NORTH_WEST;
			pin[2] = s + NORTH_EAST;
		}
		else {
			pin[1] = s + SOUTH_WEST;
			pin[3] = s + SOUTH_EAST;
		}

		if (s == SQ_B1)
			pin[1] = SQ_NONE;
		else if (s == SQ_B8)
			pin[0] = SQ_NONE;
		else if (s == SQ_H1)
			pin[3] = SQ_NONE;
		else if (s == SQ_H8)
			pin[2] = SQ_NONE;

	}
	else if (f == FILE_A) {
		if (r >= RANK_1 && r <= RANK_8) {
			pin[2] = s + NORTH_EAST;
			pin[3] = s + SOUTH_EAST;
		}
		else if (r == RANK_0) {
			pin[2] = s + NORTH_EAST;
		}
		else {
			pin[3] = s + SOUTH_EAST;
		}
	}
	else {
		if (r >= RANK_1 && r <= RANK_8) {
			pin[0] = s + NORTH_WEST;
			pin[1] = s + SOUTH_WEST;
		}
		else if (r == RANK_0) {
			pin[0] = s + NORTH_WEST;
		}
		else {
			pin[1] = s + SOUTH_WEST;
		}
	}

	return verify_knight_pin_arr(pin);

}

struct  bc_compare {
	bool operator() (const BitboardC &a, const BitboardC &b) const {
		if (low64(a) == low64(b))
			return high64(a) < high64(b);
		else
			return low64(a) < low64(b);
	}
};

inline BitboardC mirror(BitboardC bc) {
	BitboardC b = bcZero;
	while (not_z(bc)) {
		Square s = pop_lsb(&bc);
		b |= mirror(s);
	}

	return b;
}
//���Ժ���
inline bool verify_knight_reach_pin(Square s) {
	std::set<BitboardC, bc_compare> setFrom;
	std::set<BitboardC, bc_compare> setTo;
	for (int i = 0; i < KnightPinTotal; ++i)
	{
		if (KnightReachedPinFrom[s][i] != PseudoAttacks[KNIGHT][s]) {
			auto it = setFrom.insert(KnightReachedPinFrom[s][i]);
			if (!it.second)
				return false;
		}

		if (KnightReachedPinTo[s][i] != PseudoAttacks[KNIGHT][s]) {
			auto it = setTo.insert(KnightReachedPinTo[s][i]);
			if (!it.second)
				return false;
		}
	}

	return true;

}

inline BitboardC attacks_bc_rk(const Square s, const BitboardC occ) {

	Bitboard bbRank = RankIntFromBc(rank_of(s), occ);
	Bitboard bbFile = FileIntFromBc(file_of(s), occ);
	return  AttacksRookRankBC[s][bbRank] | AttacksRookFileBC[s][bbFile];
}

inline BitboardC attacks_bc_cn(const Square s, const BitboardC occ) {

	Bitboard bbRank = RankIntFromBc(rank_of(s), occ);
	Bitboard bbFile = FileIntFromBc(file_of(s), occ);
	return  AttacksCannonRankBC[s][bbRank] | AttacksCannonFileBC[s][bbFile];
}


//���Ժ���
inline bool verify_bishop_reach_pin(Square s) {
	if (bishop_square(s)) {
		File f = file_of(s);
		Rank r = rank_of(s);
		for (int i = 0; i < BishopPinTotal; ++i) {
			if (f == FILE_A) {
				if (i == s + NORTH_EAST)
					if (BishopReachedPin[s][i] != (bcZero | (s + SOUTH_SOUTH_EAST + EAST))) return false;
					else if (i == s + SOUTH_EAST)
						if (BishopReachedPin[s][i] != (bcZero | (s + NORTH_NORTH_EAST + EAST))) return false;
						else
							if (BishopReachedPin[s][i] != PseudoAttacks[BISHOP][s]) return false;
			}
			else if (f == FILE_I) {
				if (i == s + NORTH_WEST)
					if (BishopReachedPin[s][i] != (bcZero | (s + SOUTH_SOUTH_WEST + WEST))) return false;

					else if (i == s + SOUTH_WEST)
						if (BishopReachedPin[s][i] != (bcZero | (s + NORTH_NORTH_WEST + WEST))) return false;

						else
							if (BishopReachedPin[s][i] != PseudoAttacks[BISHOP][s]) return false;
			}
			else if (f == FILE_C || f == FILE_G) {
				if (r == RANK_0) {
					if (i == s + NORTH_WEST)
						if (BishopReachedPin[s][i] != (bcZero | (s + NORTH_NORTH_EAST + EAST))) return false;

						else if (i == s + NORTH_EAST)
							if (BishopReachedPin[s][i] != (bcZero | (s + NORTH_NORTH_WEST + WEST))) return false;
							else
								if (BishopReachedPin[s][i] != PseudoAttacks[BISHOP][s]) return false;
				}
				else if (r == RANK_9) {
					if (i == s + SOUTH_WEST)
						if (BishopReachedPin[s][i] != (bcZero | (s + SOUTH_SOUTH_EAST + EAST))) return false;

						else if (i == s + SOUTH_EAST)
							if (BishopReachedPin[s][i] != (bcZero | (s + SOUTH_SOUTH_WEST + WEST))) return false;

							else
								if (BishopReachedPin[s][i] != PseudoAttacks[BISHOP][s]) return false;

				}
			}
			else if (f == FILE_E) {
				if (i == s + NORTH_WEST)
					if (BishopReachedPin[s][i] != ((s + SOUTH_SOUTH_WEST + WEST) | (s + NORTH_NORTH_EAST + EAST) | (s + SOUTH_SOUTH_EAST + EAST)))
						return false;

					else if (i == s + SOUTH_WEST)
						if (BishopReachedPin[s][i] != ((s + NORTH_NORTH_WEST + WEST) | (s + NORTH_NORTH_EAST + EAST) | (s + SOUTH_SOUTH_EAST + EAST)))
							return false;

						else if (i == s + NORTH_EAST)
							if (BishopReachedPin[s][i] != ((s + NORTH_NORTH_WEST + WEST) | (s + SOUTH_SOUTH_WEST + WEST) | (s + SOUTH_SOUTH_EAST + EAST)))
								return false;

							else if (i == s + SOUTH_EAST)
								if (BishopReachedPin[s][i] != ((s + NORTH_NORTH_WEST + WEST) | (s + SOUTH_SOUTH_WEST + WEST) | (s + NORTH_NORTH_EAST + EAST)))
									return false;

				if (r == RANK_2)
				{
					if (i == total_bpsquare(SquareBB[s + SOUTH_WEST] | SquareBB[s + SOUTH_EAST]))
						if (BishopReachedPin[s][i] != ((s + NORTH_NORTH_WEST + WEST) | (s + NORTH_NORTH_EAST + EAST)))
							return false;
						else if (i == total_bpsquare(SquareBB[s + SOUTH_WEST] | SquareBB[s + NORTH_WEST]))
							if (BishopReachedPin[s][i] != ((s + SOUTH_SOUTH_EAST + EAST) | (s + NORTH_NORTH_EAST + EAST)))
								return false;
							else if (i == total_bpsquare(SquareBB[s + SOUTH_WEST] | SquareBB[s + NORTH_EAST]))
								if (BishopReachedPin[s][i] != ((s + NORTH_NORTH_WEST + WEST) | (s + SOUTH_SOUTH_EAST + EAST)))
									return false;
								else if (i == total_bpsquare(SquareBB[s + SOUTH_EAST] | SquareBB[s + NORTH_WEST]))
									if (BishopReachedPin[s][i] != ((s + SOUTH_SOUTH_WEST + WEST) | (s + NORTH_NORTH_EAST + EAST)))
										return false;
									else if (i == total_bpsquare(SquareBB[s + SOUTH_EAST] | SquareBB[s + NORTH_EAST]))
										if (BishopReachedPin[s][i] != ((s + NORTH_NORTH_WEST + WEST) | (s + SOUTH_SOUTH_WEST + WEST)))
											return false;
										else if (i == total_bpsquare(SquareBB[s + NORTH_WEST] | SquareBB[s + NORTH_EAST]))
											if (BishopReachedPin[s][i] != ((s + NORTH_NORTH_EAST + EAST) | (s + SOUTH_SOUTH_EAST + EAST)))
												return false;
											else if (i == total_bpsquare(SquareBB[s + SOUTH_WEST] | SquareBB[s + SOUTH_EAST] | SquareBB[s + NORTH_WEST]))
												if (BishopReachedPin[s][i] != (bcZero | (s + NORTH_NORTH_EAST + EAST)))
													return false;
												else if (i == total_bpsquare(SquareBB[s + SOUTH_WEST] | SquareBB[s + SOUTH_EAST] | SquareBB[s + NORTH_EAST]))
													if (BishopReachedPin[s][i] != (bcZero | (s + NORTH_NORTH_WEST + WEST)))
														return false;
													else if (i == total_bpsquare(SquareBB[s + SOUTH_WEST] | SquareBB[s + NORTH_WEST] | SquareBB[s + NORTH_EAST]))
														if (BishopReachedPin[s][i] != (bcZero | (s + SOUTH_SOUTH_EAST + EAST)))
															return false;
														else if (i == total_bpsquare(SquareBB[s + SOUTH_EAST] | SquareBB[s + NORTH_WEST] | SquareBB[s + NORTH_EAST]))
															if (BishopReachedPin[s][i] != (bcZero | (s + SOUTH_SOUTH_WEST + WEST)))
																return false;
															else
																if (BishopReachedPin[s][i] != PseudoAttacks[BISHOP][s])
																	return false;
				}
				else
				{
					if (i == total_bpsquare(SquareBB[SQ_D1] | SquareBB[SQ_F1]))
						if (BishopReachedPin[s][i] != (~SQ_C4 | ~SQ_G4))
							return false;
						else if (i == total_bpsquare(SquareBB[SQ_D1] | SquareBB[SQ_D3]))
							if (BishopReachedPin[s][i] != (~SQ_G0 | ~SQ_G4))
								return false;
							else if (i == total_bpsquare(SquareBB[SQ_D1] | SquareBB[SQ_F3]))
								if (BishopReachedPin[s][i] != (~SQ_C4 | ~SQ_G0))
									return false;
								else if (i == total_bpsquare(SquareBB[SQ_F1] | SquareBB[SQ_D3]))
									if (BishopReachedPin[s][i] != (~SQ_C0 | ~SQ_G4))
										return false;
									else if (i == total_bpsquare(SquareBB[SQ_F1] | SquareBB[SQ_F3]))
										if (BishopReachedPin[s][i] != (~SQ_C0 | ~SQ_C4))
											return false;
										else if (i == total_bpsquare(SquareBB[SQ_D3] | SquareBB[SQ_F3]))
											if (BishopReachedPin[s][i] != (~SQ_C0 | ~SQ_G0))
												return false;
											else if (i == total_bpsquare(SquareBB[SQ_D1] | SquareBB[SQ_F1] | SquareBB[~SQ_D3]))
												if (BishopReachedPin[s][i] != (bcZero | ~SQ_G4))
													return false;
												else if (i == total_bpsquare(SquareBB[SQ_D1] | SquareBB[SQ_F1] | SquareBB[~SQ_F3]))
													if (BishopReachedPin[s][i] != (bcZero | ~SQ_C4))
														return false;
													else if (i == total_bpsquare(SquareBB[SQ_D1] | SquareBB[SQ_D3] | SquareBB[~SQ_F3]))
														if (BishopReachedPin[s][i] != (bcZero | ~SQ_G0))
															return false;
														else if (i == total_bpsquare(SquareBB[SQ_F1] | SquareBB[SQ_D3] | SquareBB[~SQ_F3]))
															if (BishopReachedPin[s][i] != (bcZero | ~SQ_C0))
																return false;
															else
																if (BishopReachedPin[s][i] != PseudoAttacks[BISHOP][s])
																	return false;
				}
			}
		}

	}
	return true;
}
//�ƻ����ݣ����ƽ� 
inline void init_knight_bc() {

	//PseudoAttacks[KNIGHT][SQ_D5] = merge64(3957425, 1235);
	//PseudoAttacks[KNIGHT][SQ_H4] = merge64(3207, 6);
	//PseudoAttacks[KNIGHT][SQ_E7] = merge64(261, 85078);

}

//�ƻ����ݣ����ƽ� 
inline void init_king_bc() {

	//PseudoAttacks[KING][SQ_E0] = merge64(32, 0);
	//PseudoAttacks[KING][SQ_F2] = merge64(35, 0);
	//PseudoAttacks[KING][SQ_E8] = merge64(0, 80);

}

#endif