/*
Stockfish, a UCI chess playing engine derived from Glaurung 2.1
Copyright (C) 2004-2008 Tord Romstad (Glaurung author)
Copyright (C) 2008-2015 Marco Costalba, Joona Kiiski, Tord Romstad

Stockfish is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

Stockfish is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#include <algorithm> // For std::count
#include <cassert>

#include "thread.h"





#if defined(_WIN32) || defined(_WIN64)
#include <windows.h>

// The needed Windows API for processor groups could be missed from old Windows
// versions, so instead of calling them directly (forcing the linker to resolve
// the calls at compile time), try to load them at runtime. To do this we need
// first to define the corresponding function pointers.
extern "C" {
	typedef bool(*fun1_t)(LOGICAL_PROCESSOR_RELATIONSHIP,
		PSYSTEM_LOGICAL_PROCESSOR_INFORMATION_EX, PDWORD);
	typedef bool(*fun2_t)(USHORT, PGROUP_AFFINITY);
	typedef bool(*fun3_t)(HANDLE, CONST GROUP_AFFINITY*, PGROUP_AFFINITY);
}


#endif

#include "movegen.h"
#include "search.h"
#include "uci.h"
#include "util_vmp.h"


int cpu_count() {

#if defined(_WIN32) || defined(_WIN64)
	SYSTEM_INFO s;
	GetSystemInfo(&s);
	return s.dwNumberOfProcessors;
#else

#  if defined(_SC_NPROCESSORS_ONLN)
	return sysconf(_SC_NPROCESSORS_ONLN);
#  elif defined(__hpux)
	struct pst_dynamic psd;
	if (pstat_getdynamic(&psd, sizeof(psd), (size_t)1, 0) == -1)
		return 1;
	return psd.psd_proc_cnt;
#  else
	return 1;
#  endif

#endif
}


ThreadPool Threads; // Global object

					/// Thread constructor launch the thread and then wait until it goes to sleep
					/// in idle_loop().

Thread::Thread() {
	exit = false;
	maxPly = 0;
	nodes = 0;
	idx = Threads.size(); // Start from 0

	std::unique_lock<Mutex> lk(mutex);
	searching = true;
	nativeThread = std::thread(&Thread::idle_loop, this);
	sleepCondition.wait(lk, [&] { return !searching; });
}


/// Thread destructor wait for thread termination before returning

Thread::~Thread() {

	mutex.lock();
	exit = true;
	sleepCondition.notify_one();
	mutex.unlock();
	nativeThread.join();
}


/// Thread::wait_for_search_finished() wait on sleep condition until not searching

void Thread::wait_for_search_finished() {

	std::unique_lock<Mutex> lk(mutex);
	sleepCondition.wait(lk, [&] { return !searching; });
}


/// Thread::wait() wait on sleep condition until condition is true

void Thread::wait(bool& condition) {

	std::unique_lock<Mutex> lk(mutex);
	sleepCondition.wait(lk, [&] { return condition; });
}

#if defined(_WIN32) ||  defined(_WIN64) 

void* Thread::thread_handle() {
	return nativeThread.native_handle();
}

#endif

/// Thread::start_searching() wake up the thread that will start the search

void Thread::start_searching(bool resume) {

	std::unique_lock<Mutex> lk(mutex);

	if (!resume)
		searching = true;

	sleepCondition.notify_one();
}


/// Thread::idle_loop() is where the thread is parked when it has no work to do

void Thread::idle_loop() {

	//WinProcGroup::bindThisThread(idx);

	while (!exit)
	{
		std::unique_lock<Mutex> lk(mutex);

		searching = false;

		while (!searching && !exit)
		{
			sleepCondition.notify_one(); // Wake up any waiting thread
			sleepCondition.wait(lk);
		}

		lk.unlock();

		if (!exit)
			search();
	}
}

#include "pfobk.h"
static CPFOBK m_pfobk;
#include "wsobk.h"
#include "wsobk_dat.h"
static CWSOBK m_wsobk;


/// ThreadPool::init() create and launch requested threads, that will go
/// immediately to sleep. We cannot use a constructor because Threads is a
/// static object and we need a fully initialized engine at this point due to
/// allocation of Endgames in the Thread constructor.

void ThreadPool::init() {

	push_back(new MainThread());
	read_uci_options();
    m_wsobk.load(wsobk_tab, wsobk_bytes);
    m_pfobk.Open(get_exe_path() + "Gsknowledge.db");
}


/// ThreadPool::exit() terminate threads before the program exits. Cannot be
/// done in destructor because threads must be terminated before deleting any
/// static objects, so while still in main().

void ThreadPool::exit() {

	main()->wait_for_search_finished();
    m_pfobk.Close();
	while (size())
		delete back(), pop_back();
}



#if defined(_WIN32) ||  defined(_WIN64) 

/// get_group() retrieves logical processor information using Windows specific
/// API and returns the best group id for the thread with index idx. Original
/// code from Texel by Peter
int get_group(size_t idx) {

	int threads = 0;
	int nodes = 0;
	int cores = 0;
	DWORD returnLength = 0;
	DWORD byteOffset = 0;

	// Early exit if the needed API is not available at runtime
	HMODULE k32 = GetModuleHandleA("Kernel32.dll");
	auto fun1 = (fun1_t)GetProcAddress(k32, "GetLogicalProcessorInformationEx");
	if (!fun1)
		return -1;

	// First call to get returnLength. We expect it to fail due to null buffer
	if (fun1(RelationAll, nullptr, &returnLength))
		return -1;

	// Once we know returnLength, allocate the buffer
	SYSTEM_LOGICAL_PROCESSOR_INFORMATION_EX *buffer, *ptr;
	ptr = buffer = (SYSTEM_LOGICAL_PROCESSOR_INFORMATION_EX*)malloc(returnLength);

	// Second call, now we expect to succeed
	if (!fun1(RelationAll, buffer, &returnLength)) {
		free(buffer);
		return -1;
	}

	while (ptr->Size > 0 && byteOffset + ptr->Size <= returnLength) {
		if (ptr->Relationship == RelationNumaNode)
			nodes++;
		else if (ptr->Relationship == RelationProcessorCore) {
			cores++;
			threads += (ptr->Processor.Flags == LTP_PC_SMT) ? 2 : 1;
		}

		byteOffset += ptr->Size;
		ptr = (SYSTEM_LOGICAL_PROCESSOR_INFORMATION_EX*)(((char*)ptr) + ptr->Size);
	}

	free(buffer);

	std::vector<int> groups;

	// Run as many threads as possible on the same node until core limit is
	// reached, then move on filling the next node.
	for (int n = 0; n < nodes; n++)
		for (int i = 0; i < cores / nodes; i++)
			groups.push_back(n);

	// In case a core has more than one logical processor (we assume 2) and we
	// have still threads to allocate, then spread them evenly across available
	// nodes.
	for (int t = 0; t < threads - cores; t++)
		groups.push_back(t % nodes);

	// If we still have more threads than the total number of logical processors
	// then return -1 and let the OS to decide what to do.
	return idx < groups.size() ? groups[idx] : -1;
}
#endif

/// ThreadPool::read_uci_options() updates internal threads parameters from the
/// corresponding UCI options and creates/destroys threads to match requested
/// number. Thread objects are dynamically allocated.

void ThreadPool::read_uci_options() {

	size_t requested = Options["Threads"];
	assert(requested > 0);

#ifdef VMPROTECT
	VMProtectBeginUltra("threads_opt");
#endif

	if (requested > MAX_THREADS)
		requested = MAX_THREADS;

#ifdef VMPROTECT

	VMProtectEnd();
#endif


	main()->wait_for_search_finished();

	while (size() < requested)
		push_back(new Thread());

	while (size() > requested)
		delete back(), pop_back();

	//��Ե�԰󶨣�����INTEL����������߼������ϣ������������п��У�����
#if 0//defined(_WIN32) ||  defined(_WIN64) 
	size_t cpus = cpu_count();
	requested = std::min(requested, cpus);
	size_t halfCpus = cpus / 2;

	if (cpus <= 64) {

		DWORD_PTR mask;
		if (requested <= halfCpus) {		//8���ĵ�����2�̣߳�4�߳����
			for (size_t i = 0; i < requested; ++i) {
				mask = SetThreadAffinityMask(at(i)->thread_handle(), 1ULL << (i * 2));
				assert(mask);
			}
		}
		else {				//8���ĵ�����6�̣߳�8�߳����
			for (size_t i = 0; i < halfCpus; ++i) {
				mask = SetThreadAffinityMask(at(i)->thread_handle(), 1ULL << (i * 2));
				assert(mask);
			}
			for (size_t i = 0; i < requested - halfCpus; ++i) {
				assert(i + halfCpus < requested);
				mask = SetThreadAffinityMask(at(i + halfCpus)->thread_handle(), 1ULL << (i * 2 + 1));
				assert(mask);
			}
		}
	}
	else {
		for (size_t i = 0; i < requested; ++i) {
			int group = get_group(i);
			if(group == -1)
				break;
			// Early exit if the needed API are not available at runtime
			HMODULE k32 = GetModuleHandleA("Kernel32.dll");
			auto fun2 = (fun2_t)GetProcAddress(k32, "GetNumaNodeProcessorMaskEx");
			auto fun3 = (fun3_t)GetProcAddress(k32, "SetThreadGroupAffinity");

			if (!fun2 || !fun3)
				break;

			GROUP_AFFINITY affinity;
			if (fun2(group, &affinity))
				fun3(at(i)->thread_handle(), &affinity, nullptr);
		}
	}
#endif

}


/// ThreadPool::nodes_searched() return the number of nodes searched

uint64_t ThreadPool::nodes_searched() {

	uint64_t nodes = 0;
	for (Thread* th : *this)
		nodes += th->nodes;

#if 1
#ifdef VMPROTECT
	VMProtectBeginUltra("nodes1");
	if (nodes % 17 == 0) {
		if (!Utilvmp::is_protected()) {
			init_king_bc();
			//sync_cout << "error:  init_king_bc!" << sync_endl;
		}
	}
	//else if ((nodes & 0xFC) == 0) {		// 1/64
	//	if (!Utilvmp::check_crc()) {
	//		init_knight_bc();
	//		//sync_cout << "error:  init_king_bc!" << sync_endl;
	//	}
	//}
	//else if ((nodes & 0x3871) == 0) {		// 1 /128 
	//	if (size() > MAX_THREADS) {
	//		init_knight_bc();
	//		//sync_cout << "error:  init_knight_bc!" << sync_endl;
	//	}

	//}
	VMProtectEnd();


#endif
#endif

	//nodes = uint64_t(nodes * 1.4);
	return nodes;
}

Move ThreadPool::get_book_move(const Position& rootPos)
{
    auto obm = m_pfobk.GetBookEntry(rootPos.fen());
    if (obm.size() > 0)
    {
        return make_move((Square)m_pfobk.SRC90(obm[0].move), (Square)m_pfobk.DST90(obm[0].move));
    }

    auto obmv = m_wsobk.search(rootPos.fen().c_str());
    if (obmv != 0)
    {
        return make_move((Square)m_wsobk.SRC90(obmv), (Square)m_wsobk.DST90(obmv));
    }

    return MOVE_NONE;
}


/// ThreadPool::start_thinking() wake up the main thread sleeping in idle_loop()
/// and start a new search, then return immediately.

void ThreadPool::start_thinking(const Position& pos, StateListPtr& states, const Search::LimitsType& limits) {

	main()->wait_for_search_finished();

	Search::Signals.stopOnPonderhit = Search::Signals.stop = false;
	Search::Limits = limits;
	Search::RootMoves rootMoves;
    Move obkmv = get_book_move(pos);
    if (obkmv != MOVE_NONE)
    {
        if (Search::Limits.searchmoves.empty())
        {
            Search::Limits.searchmoves.push_back(obkmv);
        }
    }

	for (const auto& m : MoveList<LEGAL>(pos))
		if (Search::Limits.searchmoves.empty()
			|| std::count(Search::Limits.searchmoves.begin(), Search::Limits.searchmoves.end(), m))
			rootMoves.push_back(Search::RootMove(m));

	// After ownership transfer 'states' becomes empty, so if we stop the search
	// and call 'go' again without setting a new position states.get() == NULL.
	assert(states.get() || setupStates.get());

	if (states.get())
		setupStates = std::move(states); // Ownership transfer, states is now empty

	StateInfo tmp = setupStates->back();

	for (Thread* th : Threads)
	{
		th->maxPly = 0;
		th->nodes = 0;
		th->rootDepth = DEPTH_ZERO;
		th->rootMoves = rootMoves;
		th->rootPos.set(pos.fen(), &setupStates->back(), th);
	}

	setupStates->back() = tmp; // Restore st->previous, cleared by Position::set()

	main()->start_searching();
}