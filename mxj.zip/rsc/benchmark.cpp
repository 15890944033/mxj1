/*
  Stockfish, a UCI chess playing engine derived from Glaurung 2.1
  Copyright (C) 2004-2008 Tord Romstad (Glaurung author)
  Copyright (C) 2008-2015 Marco Costalba, Joona Kiiski, Tord Romstad

  Stockfish is free software: you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation, either version 3 of the License, or
  (at your option) any later version.

  Stockfish is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#include <fstream>
#include <iostream>
#include <istream>
#include <vector>

#include "misc.h"
#include "position.h"
#include "search.h"
#include "thread.h"
#include "uci.h"
 
using namespace std;

namespace {
	//20 games
	const vector<string> Defaults = {
		"2r1kab2/4a1c2/1c2b1n2/p3NR2p/4P4/2p6/P5p1P/1C2C4/4N2r1/R1BAKAB2 w - - 0 15",
		"1rb1kabr1/4a4/9/p1p1R3p/6pn1/2P6/Pc2P1c1P/C1N6/4N4/1RBAKAB2 w - - 0 13",
		"1rb1ka1r1/4a1c2/1cn1b1n2/pRp1pR2p/9/2P6/P3P1p1P/C1N1C4/4N4/2BAKAB2 w - - 0 14",
		"r2akabr1/9/1cn1b2c1/p1p1p2Rp/5n3/2P3p2/PC2P1P1P/2N1C1N2/9/R1BAKAB2 w - - 0 7",
		"rn2kabnr/4a4/4b2c1/p3C1p1p/2P6/9/P3P1c1P/1CR6/9/R1BAKABN1 w - - 0 7",
		"2r1kab2/4a4/2n1b4/p3p3p/1cc6/3R2R2/P3P2rP/4C1N2/1C7/2BAKAB2 w - - 0 16",
		"1nbakab2/9/4c1n2/p1Nrp3p/6p2/2P6/P3P1c1P/2C1C1N1B/9/2BAKA1R1 w - - 0 11",
		"1r1akabr1/3n5/2c1b2cn/pC2p1p1p/3N5/9/P3P1P1P/B1p1C1N2/4A4/R3KABR1 w - - 0 10",
		"r3kab2/1r1na4/2c1b2cn/p1p1p1p1p/9/2P4R1/P3P1P1P/1CN1C1N2/9/1RBAKAB2 w - - 0 7",
		
		"r1bakab2/c8/1cn3n2/p1p1pR2p/6p2/2P1P4/P5P1P/N1C1C1N2/1r7/R1BAKAB2 w - - 0 10",
		"1rbakab2/4c4/c1n3n2/p1p1pR2p/6p2/2P1P4/P5PrP/2N1C1N2/4C4/R1BAKAB2 b - - 0 12",
		"3rkabr1/4a4/4b1n2/4p2cp/2p2c3/R4N3/2P1P3P/NCn1C4/4A4/2BAK1BR1 w - - 0 22",
		"3rkabn1/4a4/2n1b3c/p3p1p1p/2p6/c4NP2/1RP1P3P/N2CC4/4A4/2B1KAB2 w - - 0 12",
		"r3kab2/4a4/1cN1b1c2/p3p1R1p/2p1P2n1/9/P5p1P/1C7/4C2r1/RNBAKAB2 w - - 0 15",
		"r2akabr1/4n4/4b1Rc1/p3C3p/9/9/P3P1P1P/2C3N2/4K4/cN1A1AB2 w - - 0 1",
		//�о�
		"2b1ka3/4a4/2r1c1n1b/4p4/6p2/p1P6/4P3P/B1N1C1R2/4A4/3AK1B2 w - - 0 1",
		"4k1b2/9/3nb4/2r1p3p/6p2/P1P5P/6R2/4BN3/9/2B1K4 w - - 0 1",
		"3ckab2/9/2n1ba2n/4p4/P8/2P4pp/4P4/3NB1N2/4A4/2BAKC3 w - - 0 1",
		"3ck1b2/4a4/2n1b4/4p4/PP7/7pp/4P4/3NB4/9/2BAKC3 w - - 0 1"
	};

} // namespace

/// benchmark() runs a simple benchmark by letting Stockfish analyze a set
/// of positions for a given limit each. There are five parameters: the
/// transposition table size, the number of search threads that should
/// be used, the limit value spent for each position (optional, default is
/// depth 13), an optional file name where to look for positions in FEN
/// format (defaults are the positions defined above) and the type of the
/// limit value: depth (default), time in millisecs or number of nodes.

void benchmark(const Position& current, istream& is) {

  string token;
  vector<string> fens;
  Search::LimitsType limits;

  // Assign default values to missing arguments
  string ttSize    = (is >> token) ? token : "256";
  string threads   = (is >> token) ? token : "1";
  string limit     = (is >> token) ? token : "18";
  string fenFile   = (is >> token) ? token : "default";
  string limitType = (is >> token) ? token : "depth";

  Search::clear();
  Options["Threads"] = threads;
  Options["Hash"] = ttSize;

  if (limitType == "time")
      limits.movetime = stoi(limit); // movetime is in millisecs

  else if (limitType == "nodes")
      limits.nodes = stoll(limit);

  else if (limitType == "mate")
      limits.mate = stoi(limit);

  else
      limits.depth = stoi(limit);

  if (fenFile == "default")
      fens = Defaults;

  else if (fenFile == "current")
      fens.push_back(current.fen());

  else
  {
      string fen;
      ifstream file(fenFile);

      if (!file.is_open())
      {
          cerr << "Unable to open file " << fenFile << endl;
          return;
      }

      while (getline(file, fen))
          if (!fen.empty())
              fens.push_back(fen);

      file.close();
  }

  uint64_t nodes = 0;
  TimePoint elapsed = now();
  Position pos;
  StateListPtr states(new std::deque<StateInfo>(1));

  for (size_t i = 0; i < fens.size(); ++i)
  {
	  StateListPtr states(new std::deque<StateInfo>(1));
	  pos.set(fens[i], &states->back(), Threads.main());

      cerr << "\nPosition: " << i + 1 << '/' << fens.size() << endl;

      if (limitType == "perft")
          nodes += Search::perft(pos, limits.depth * ONE_PLY);

      else
      {
          limits.startTime = now();
		  Threads.start_thinking(pos, states, limits);
          Threads.main()->wait_for_search_finished();
          nodes += Threads.nodes_searched();
      }
  }

  elapsed = now() - elapsed + 1; // Ensure positivity to avoid a 'divide by zero'

  dbg_print(); // Just before to exit

  cerr << "\n==========================="
       << "\nTotal time (ms) : " << elapsed
       << "\nNodes searched  : " << nodes
       << "\nNodes/second    : " << 1000 * nodes / elapsed << endl;
}
