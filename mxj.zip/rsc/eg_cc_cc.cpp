#include "endgame.h"


//û��ʿ���۷� ��һ��ʿ���۷�
//��2�����Ϲ��ӱ���������ӷǵ��ߵ�����Ҳ�û�б����۷�
//�����2��ʿ��û�����ʿ���۷�
template<EndgameType E/*, typename T = eg_type<E>*/>
inline void Endgame<E>::cc_cc_total(const Position& pos, Score& score) const {
	adjust_pawn_behind_king<WHITE>(pos, score, 0.3);
	adjust_pawn_behind_king<BLACK>(pos, score, 0.3);


	int adWhite = pos.count(WHITE, ADVISOR);
	int adBlack = pos.count(BLACK, ADVISOR);
	int duitou = pawns_headtohead(pos);
	int nbpWhite = pos.pawn_nobottomcount<WHITE>() - duitou;
	int nbpBlack = pos.pawn_nobottomcount<BLACK>() - duitou;
	int vpWhite = pos.pawn_validcount<WHITE>();
	int vpBlack = pos.pawn_validcount<BLACK>();

	int dcWhite = pos.defense_count(WHITE);
	int dcBlack = pos.defense_count(BLACK);
	int dcdiff = dcBlack - dcWhite;

	Value v = VALUE_ZERO;

	if (adWhite == 0 && adBlack > 0 && nbpBlack > 0) {
		v += -BISHOP_END_20P;
	}
	else if (adWhite > 0 && adBlack == 0 && nbpWhite > 0) {
		v += BISHOP_END_20P;
	}

	//if (adWhite == 1 && adBlack == 2) {
	//	v += -BishopValueEg * 0.3;
	//}
	//else if (adWhite == 2 && adBlack == 1) {
	//	v += BishopValueEg * 0.3;
	//}

	if (pos.pawn_validcount<WHITE>() >= 2
		&& (equal_z(pos.pieces_pawn_crnb<WHITE>() & FlankBoardBC[LEFT]) || equal_z(pos.pieces_pawn_crnb<WHITE>() & FlankBoardBC[RIGHT]))) {
		v += -PAWN_END_10P;
	}
	if (pos.pawn_validcount<BLACK>() >= 2
		&& (equal_z(pos.pieces_pawn_crnb<BLACK>() & FlankBoardBC[LEFT]) || equal_z(pos.pieces_pawn_crnb<BLACK>() & FlankBoardBC[RIGHT]))) {
		v += PAWN_END_10P;
	}

	if (adWhite == 2 && !pos.is_advisor_cavel(WHITE)) {
		v += -BISHOP_END_10P;
	}
	if (adBlack == 2 && !pos.is_advisor_cavel(BLACK)) {
		v += BISHOP_END_10P;
	}

	if (adWhite > 0 && nbpWhite > 0 && nbpBlack == 0 && !cannon_home_attack(pos, WHITE))
		v += -PAWN_END_10P;
	else if (adBlack > 0 && nbpWhite == 0 && nbpBlack > 0 && !cannon_home_attack(pos, BLACK))
		v += PAWN_END_10P;


	//�����ʿ��ֵ���
	if (dcdiff > 0 && (((nbpWhite + duitou) > 0 && (nbpBlack + duitou) == 0) ||
		(vpWhite > 0 && vpBlack == 0 && nbpWhite > nbpBlack))) {
		v += dcdiff * BISHOP_END_40P;
	}
	else if (dcdiff < 0 && (((nbpWhite + duitou) == 0 && (nbpBlack + duitou) > 0) ||
		(vpBlack > 0 && vpWhite == 0 && nbpWhite < nbpBlack))) {
		v += dcdiff * BISHOP_END_40P;
	}

	//�ڵ��ƶ��Գͷ���
	BitboardC notAttacked[2];
	notAttacked[WHITE] = ~(pos.pawn_attacks<BLACK>() | pos.bishop_attacks<BLACK>()
		| pos.advisor_attacks<BLACK>() | pos.attacks_from<KING>(pos.square(BLACK, KING)));
	notAttacked[BLACK] = ~(pos.pawn_attacks<WHITE>() | pos.bishop_attacks<WHITE>()
		| pos.advisor_attacks<WHITE>() | pos.attacks_from<KING>(pos.square(WHITE, KING)));

	//�ڵ��ƶ��Գͷ���
	int mob = cannon_mobility<WHITE, false>(pos, notAttacked[WHITE]);
	v += value_cannon_mob<WHITE>(pos, mob);
	mob = cannon_mobility<BLACK, false>(pos, notAttacked[BLACK]);
	v -= value_cannon_mob<BLACK>(pos, mob);

	if (nbpWhite >= nbpBlack && vpWhite > vpBlack) {
		v += (vpWhite - vpBlack) * PAWN_END_10P;
	}
	else if (nbpWhite > 0 && nbpBlack == 0) {
		v += nbpWhite * PAWN_END_10P;
	}
	else if (nbpWhite <= nbpBlack && vpWhite < vpBlack) {
		v += (vpWhite - vpBlack) * PAWN_END_10P;
	}
	else if (nbpBlack > 0 && nbpWhite == 0) {
		v += -nbpBlack * PAWN_END_10P;
	}

	update_score(score, v);

}


template<>
Value Endgame<KCCKCC>::operator()(const Position& pos, Score& score) const {
	cc_cc_total(pos, score);


	FUN_IMPL_SAME_PIECES_ALL(kcc_kcc)
}

template<EndgameType E/*, typename T = eg_type<E>*/>
template<Color strong> inline Value Endgame<E>::kcc_kcc_0p_0p(const Position& pos, Score& score) const {
	return value_draw_zoom<8>(pos, score);
}

template<EndgameType E/*, typename T = eg_type<E>*/>
template<Color strong> inline Value Endgame<E>::kcc_kcc_1p_0p(const Position& pos, Score& score) const {
	I_AM_WEAK
		//����û��ʿ������
		int advisors = pos.count(strong, ADVISOR);
	if (advisors == 0)
		return 	update_score_limit(score, -PAWN_END_40P);
	auto ba = pos.ba_number<weak>();
	switch (ba)
	{
	case BA_ZERO:
	case BA_AD:
		if (pos.pawn_validcount<strong>() > 0)
			return VALUE_NONE;
		break;
	case BA_BS:
	case BA_BA:
	case BA_DB:
	case BA_DA:
		return 	update_score_limit(score, -PAWN_END_40P);
	case BA_DBA:
	case BA_BDA:
	case BA_DBDA:
	default:
		break;
	}

	return value_draw_zoom<2>(pos, score);
}

template<EndgameType E/*, typename T = eg_type<E>*/>
template<Color strong> inline Value Endgame<E>::kcc_kcc_1p_1p(const Position& pos, Score& score) const {
	I_AM_WEAK

	auto baStrg = pos.ba_number<strong>();
	auto baWeak = pos.ba_number<strong>();

	return VALUE_NONE;

}

template<EndgameType E/*, typename T = eg_type<E>*/>
template<Color strong> inline Value Endgame<E>::kcc_kcc_2p_0p(const Position& pos, Score& score) const {
	I_AM_WEAK
	auto ba = pos.ba_number<weak>();
	int nb = pos.pawn_nobottomcount<strong>();

	switch (ba)
	{
	case BA_ZERO:
	case BA_AD:
	case BA_DA:
	case BA_BS:
	case BA_BA:
	case BA_DB:
	case BA_DBA:
	case BA_BDA:
		goto almostWin;
	default:
		if(nb == 2)
			break;
		goto almostWin;
	}

	return 	update_score_limit(score, -PAWN_END_60P);

almostWin:
	return VALUE_NONE;

}

template<EndgameType E/*, typename T = eg_type<E>*/>
template<Color strong> inline Value Endgame<E>::kcc_kcc_2p_1p(const Position& pos, Score& score) const {
	I_AM_WEAK

	auto baStrg = pos.ba_number<strong>();
	auto baWeak = pos.ba_number<weak>();
	int nb = pos.pawn_nobottomcount<strong>();

	if (nb == 2 && baWeak == BA_DBDA && baStrg >= BA_DB)
		return 	update_score_limit(score, -PAWN_END_40P);
	return VALUE_NONE;


}

template<EndgameType E/*, typename T = eg_type<E>*/>
template<Color strong> inline Value Endgame<E>::kcc_kcc_2p_2p(const Position& pos, Score& score) const {
	return VALUE_NONE;
}
