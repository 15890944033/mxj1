#include "endgame.h"


//�ڷ������2��ʿ��û�����ʿ���۷�
//˫������2�����Ϲ��ӱ���������ӷǵ��ߵ�����Ҳ�û�б����۷�
//˫�������ӷ�
template<EndgameType E/*, typename T = eg_type<E>*/>
template<Color c>
inline void Endgame<E>::nn_c_total(const Position& pos, Score& score) const {
	const Color Them = c == WHITE ? BLACK : WHITE;

	int nbpStrong = pos.pawn_nobottomcount<c>();
	Value v = VALUE_ZERO;

	//if (nbpStrong > 0) {
	//	v += KnightValueEg * 0.4;
	//	pawns_bonus<c>(pos, score);
	//}

	int ad = pos.count(Them, ADVISOR);
	if (ad == 2 && !pos.is_advisor_cavel(Them))
		v += BISHOP_END_10P;

	if (pos.pawn_validcount<c>() >= 2
		&& (equal_z(pos.pieces_pawn_crnb<c>() & FlankBoardBC[LEFT]) || equal_z(pos.pieces_pawn_crnb<c>() & FlankBoardBC[RIGHT]))) {
		v += -PAWN_END_10P;
	}

	//ǿ��Ӧ����¶��
	if (!pos.is_king_clear<c, 0>())
		v += -BISHOP_END_10P;

	update_score(score, c,  v);

	pawns_bonus<c>(pos, score);

	if (nbpStrong == 0 && pos.pawn_nobottomcount<Them>() == 0)
		ba_adjust_strong<c>(pos, score);

}


template<>
Value Endgame<KNNKC>::operator()(const Position& pos, Score& score) const {

	if (strongSide == WHITE) {
		if (pos.pawn_validcount<WHITE>() == 0) {
			if (knight_chain_byking<WHITE>(pos))
				return update_score(score, -KNIGHT_END_90P);
		}
	}
	else {
		if (pos.pawn_validcount<BLACK>() == 0) {
			if (knight_chain_byking<BLACK>(pos))
				return update_score(score, KNIGHT_END_90P);
		}
	}

	strongSide == WHITE ? nn_c_total<WHITE>(pos, score) : nn_c_total<BLACK>(pos, score);

	FUN_IMPL_DIFF_PIECES_ALL(knn_kc)
}

//˫��ʤ��˫ʿ ��˫�� ʤ���Ѷ�
//˫�� ���ڵ�ȱ��  46.9%  ��ʿ���ࣩ 87%	���ڵ�ȱʿ 19.2% 
template<EndgameType E/*, typename T = eg_type<E>*/>
template<Color strong> inline Value Endgame<E>::knn_kc_0p_0p(const Position& pos, Score& score) const {
	I_AM_WEAK

	auto ba = pos.ba_number<weak>();
	switch (ba)
	{
	case BA_ZERO:
	case BA_BS:
	case BA_AD:
	case BA_BA:
		goto almostWin;
	case BA_DA:
	//����ڷ��еױ��� ˫����û�еױ����к������ 
		if(pos.pawn_bottomcount<weak>() > 0 && pos.pawn_bottomcount<strong>() == 0)
			break;
		goto almostWin;

	case BA_BDA:
		if(pos.pawn_bottomcount<strong>() > 0 || (pos.pawn_bottomcount<weak>() == 0 && pos.defense_count(strong) > 0))
			goto almostWin;
		break;

	case BA_DB:
	case BA_DBA:
		if (pos.pawn_bottomcount<strong>() > 0)
			goto almostWin;
		break;
	default:
		break;
	}

	return value_draw_zoom<1>(pos, score);

almostWin:
	return value_final(pos, score);

}

template<EndgameType E/*, typename T = eg_type<E>*/>
template<Color strong> inline Value Endgame<E>::knn_kc_1p_0p(const Position& pos, Score& score) const {
	return VALUE_NONE;
}

template<EndgameType E/*, typename T = eg_type<E>*/>
template<Color strong> inline Value Endgame<E>::knn_kc_2p_0p(const Position& pos, Score& score) const {
	return VALUE_NONE;
}
//���� vs ����ʿ	ʤ�ʣ� 84.82% ���ʣ� 9.15%
//���� vs ������	ʤ�ʣ�86.74%	���ʣ�10.36%
//���� vs ����ʿʿ	ʤ�ʣ�51.19%	���ʣ�41.28%
template<EndgameType E/*, typename T = eg_type<E>*/>
template<Color strong> inline Value Endgame<E>::knn_kc_0p_1p(const Position& pos, Score& score) const {
	I_AM_WEAK

	auto ba = pos.ba_number<weak>();
	switch (ba)
	{
	case BA_ZERO:
	case BA_AD:
	case BA_BS:
	case BA_BA:
		goto almostWin;

	case BA_DA:
		//���˫����û�еױ����ڷ������ʿ���ұ����ӣ��к������ 
		if (pos.is_advisor_cavel(weak) && pos.pawn_crcount<weak>() > 0 && pos.pawn_bottomcount<strong>() == 0)
			break;
		goto almostWin;

	case BA_DB:
	case BA_DBA:
	case BA_BDA:
		if (pos.pawn_bottomcount<strong>() > 0)
			goto almostWin;
		break;
	default:
		break;
	}

	return value_draw_zoom<1>(pos, score);

almostWin:
	return value_final(pos, score);
}

template<EndgameType E/*, typename T = eg_type<E>*/>
template<Color strong> inline Value Endgame<E>::knn_kc_1p_1p(const Position& pos, Score& score) const {
	return knn_kc_1p_0p<strong>(pos, score);
}

template<EndgameType E/*, typename T = eg_type<E>*/>
template<Color strong> inline Value Endgame<E>::knn_kc_2p_1p(const Position& pos, Score& score) const {
	return knn_kc_2p_0p<strong>(pos, score);
}


template<EndgameType E/*, typename T = eg_type<E>*/>
template<Color strong> inline Value Endgame<E>::knn_kc_0p_2p(const Position& pos, Score& score) const {
	I_AM_WEAK

	int vp = pos.pawn_validcount<weak>();
	//ǿ��ʿ��У������ǵױ�>=2 ��������ȫ��ǿ���۷�
	if (vp >= 2 && pos.defense_count(strong) <= 2 && (pos.defense_count(weak) >= 3 || pos.count(weak, BISHOP) == 2))
		return update_score(pos, score, strong, -BISHOP_END_10P * vp);

	int nb = pos.pawn_nobottomcount<weak>();
	if (nb == 2) {
		if (pos.pawn_bottomcount<strong>() == 0 && pos.defense_count(strong) >= 3
			&& (pos.defense_count(weak) >= 3 || pos.count(weak, BISHOP) == 2 || pos.is_pawns_partner_midhigh<weak>()))
			goto drawEnd;
	}
	//else {
	//	assert(nb > 2);
	//	if (pos.full_ba(weak))
	//		return update_score(pos, score, weak, BishopValueEg * 0.4 * nb);

	//}

	return VALUE_NONE;

drawEnd:
	return value_draw_zoom<2>(pos, score);

}

template<EndgameType E/*, typename T = eg_type<E>*/>
template<Color strong> inline Value Endgame<E>::knn_kc_1p_2p(const Position& pos, Score& score) const {
	I_AM_WEAK
	if (pos.is_pawns_partner_midhigh<weak>())
		return update_score(pos, score, strong, -BISHOP_END_80P);
	return VALUE_NONE;

}

template<EndgameType E/*, typename T = eg_type<E>*/>
template<Color strong> inline Value Endgame<E>::knn_kc_2p_2p(const Position& pos, Score& score) const {
	return VALUE_NONE;
}
