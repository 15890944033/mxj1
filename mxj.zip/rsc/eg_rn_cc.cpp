#include "endgame.h"


template<EndgameType E/*, typename T = eg_type<E>*/>
template<Color c>
inline void Endgame<E>::rn_cc_total(const Position& pos, Score& score) const {
	Value v = VALUE_ZERO;
	const Color Them = c == WHITE ? BLACK : WHITE;

	//ǿ��������¶�����ӷ�
	if (pos.is_king_mid_clear<c>())
		v += BISHOP_END_40P;

	//���������ڵף��۷�
	if (!pos.is_king_bottom(Them))
		v += BISHOP_END_40P;

	update_score(score, c, v);

	ba_adjust_strong<c>(pos, score, VALUE_BA_ADJUST_MAX_UL);

}

template<>
Value Endgame<KRNKCC>::operator()(const Position& pos, Score& score) const {
	strongSide == WHITE ? rn_cc_total<WHITE>(pos, score) : rn_cc_total<BLACK>(pos, score);

	FUN_IMPL_DIFF_PIECES_ALL(krn_kcc)
}

template<EndgameType E/*, typename T = eg_type<E>*/>
template<Color strong> inline Value Endgame<E>::krn_kcc_0p_0p(const Position& pos, Score& score) const {
	I_AM_WEAK

	//if (pos.pawn_bottomcount<strong>() > 0)
	//	return VALUE_NONE;

	//����ȫʿ�����ڵ��ߣ� ����û���ϱ���
	//����˫�����¶�·or����·����
	if (pos.full_ba(weak) && pos.pawn_bottomcount<strong>() == 0 && pos.is_king_bottom(weak)){
		const Square* pl = pos.squares(weak, CANNON);
		Square csq1 = *pl++;
		assert(csq1 != SQ_NONE);
		Square csq2 = *pl;
		assert(csq2 != SQ_NONE);

		if (rank_of(csq1) == relative_rank<weak>(RANK_1) || rank_of(csq1) == relative_rank<weak>(RANK_2)) {
			int cn = popcount(pos.btw_bc(csq1, csq2));
			if (cn == 1)
				return value_draw_zoom<4>(pos, score);
		}
	}
	return VALUE_NONE;
}

template<EndgameType E/*, typename T = eg_type<E>*/>
template<Color strong> inline Value Endgame<E>::krn_kcc_1p_0p(const Position& pos, Score& score) const {
	return 	VALUE_NONE;
}

template<EndgameType E/*, typename T = eg_type<E>*/>
template<Color strong> inline Value Endgame<E>::krn_kcc_2p_0p(const Position& pos, Score& score) const {
	return 	VALUE_NONE;
}


template<EndgameType E/*, typename T = eg_type<E>*/>
template<Color strong> inline Value Endgame<E>::krn_kcc_0p_1p(const Position& pos, Score& score) const {
	return 	VALUE_NONE;
}

template<EndgameType E/*, typename T = eg_type<E>*/>
template<Color strong> inline Value Endgame<E>::krn_kcc_1p_1p(const Position& pos, Score& score) const {
	return 	VALUE_NONE;
}

template<EndgameType E/*, typename T = eg_type<E>*/>
template<Color strong> inline Value Endgame<E>::krn_kcc_2p_1p(const Position& pos, Score& score) const {
	return 	VALUE_NONE;
}

template<EndgameType E/*, typename T = eg_type<E>*/>
template<Color strong> inline Value Endgame<E>::krn_kcc_0p_2p(const Position& pos, Score& score) const {
	return 	VALUE_NONE;
}

template<EndgameType E/*, typename T = eg_type<E>*/>
template<Color strong> inline Value Endgame<E>::krn_kcc_1p_2p(const Position& pos, Score& score) const {
	return 	VALUE_NONE;
}

template<EndgameType E/*, typename T = eg_type<E>*/>
template<Color strong> inline Value Endgame<E>::krn_kcc_2p_2p(const Position& pos, Score& score) const {
	return 	VALUE_NONE;
}
