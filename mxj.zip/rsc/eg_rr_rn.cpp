#include "endgame.h"


template<EndgameType E/*, typename T = eg_type<E>*/>
template<Color c>
inline void Endgame<E>::rr_rn_total(const Position& pos, Score& score) const {
	Value v = VALUE_ZERO;
	const Color Them = c == WHITE ? BLACK : WHITE;

	//�����ڵף��۷�
	if (!pos.is_king_bottom(Them))
		v = BISHOP_END_110P;

	update_score(score, c, v);
}

template<>
Value Endgame<KRRKRN>::operator()(const Position& pos, Score& score) const {
	if (strongSide == WHITE) {
		if (rkkncn_chain_byrk<BLACK, KNIGHT>(pos)) {
			//�ڷ�����ǣ�ƣ��׷��б� or �ڷ���ʿ��ȫ
			if (pos.pawn_nobottomcount<WHITE>() > 0 || !pos.full_ba(BLACK))
				return update_score(pos, score, KNIGHT_END_50P);
		}
	}
	else {
		if (rkkncn_chain_byrk<WHITE, KNIGHT>(pos)) {
			//�׷�����ǣ�ƣ��ڷ��б� or �׷���ʿ��ȫ
			if (pos.pawn_nobottomcount<BLACK>() > 0 || !pos.full_ba(WHITE))
				return update_score(pos, score, -KNIGHT_END_50P);
		}
	}

	strongSide == WHITE ? rr_rn_total<WHITE>(pos, score) : rr_rn_total<BLACK>(pos, score);

	FUN_IMPL_DIFF_PIECES_ALL(krr_krn)
}

//˫��ʤ����˫�� ����˫ʿ
template<EndgameType E/*, typename T = eg_type<E>*/>
template<Color strong> inline Value Endgame<E>::krr_krn_0p_0p(const Position& pos, Score& score) const {
	I_AM_WEAK
	auto ba = pos.ba_number<weak>();
	switch (ba)
	{
	case BA_ZERO:
	case BA_BS:
	case BA_AD:
	case BA_BA:
	case BA_DB:
	case BA_DA:
	case BA_DBA:
		break;
	case BA_BDA:
		//��Ҫ�ڵ���
		if (pos.is_king_bottom(weak) && pos.pawn_bottomcount<strong>() == 0)
			return value_draw_zoom<2>(pos, score);
		break;
	default:
		if (pos.is_king_top<weak>() || pos.pawn_bottomcount<strong>() >= 2)
			break;
		goto drawEnd;
	}
	return VALUE_NONE;

drawEnd:
	return value_draw_zoom<6>(pos, score);

}

template<EndgameType E/*, typename T = eg_type<E>*/>
template<Color strong> inline Value Endgame<E>::krr_krn_1p_0p(const Position& pos, Score& score) const {
	return VALUE_NONE;
}

template<EndgameType E/*, typename T = eg_type<E>*/>
template<Color strong> inline Value Endgame<E>::krr_krn_2p_0p(const Position& pos, Score& score) const {
	return VALUE_NONE;
}

template<EndgameType E/*, typename T = eg_type<E>*/>
template<Color strong> inline Value Endgame<E>::krr_krn_0p_1p(const Position& pos, Score& score) const {

	I_AM_WEAK
	//������ʿ��ȫ��˫��2��ʿ�������й��ӱ�������
	if (pos.full_ba(weak)) {
		if (pos.zero_ba(strong) && pos.pawn_validcount<weak>() > 0) {
			Value v = -KNIGHT_END_30P;
			return update_score(score, strong, v);
		}
	}
	return krr_krn_0p_0p<strong>(pos, score);
}

template<EndgameType E/*, typename T = eg_type<E>*/>
template<Color strong> inline Value Endgame<E>::krr_krn_1p_1p(const Position& pos, Score& score) const {
	return VALUE_NONE;
}

template<EndgameType E/*, typename T = eg_type<E>*/>
template<Color strong> inline Value Endgame<E>::krr_krn_2p_1p(const Position& pos, Score& score) const {
	return VALUE_NONE;
}

template<EndgameType E/*, typename T = eg_type<E>*/>
template<Color strong> inline Value Endgame<E>::krr_krn_0p_2p(const Position& pos, Score& score) const {
	I_AM_WEAK

	if (!pos.is_pawns_partner_midhigh<weak>())
		return krr_krn_0p_1p<strong>(pos, score);

	return VALUE_NONE;
}

template<EndgameType E/*, typename T = eg_type<E>*/>
template<Color strong> inline Value Endgame<E>::krr_krn_1p_2p(const Position& pos, Score& score) const {
	return VALUE_NONE;
}

template<EndgameType E/*, typename T = eg_type<E>*/>
template<Color strong> inline Value Endgame<E>::krr_krn_2p_2p(const Position& pos, Score& score) const {
	return VALUE_NONE;
}
