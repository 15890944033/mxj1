/*
Stockfish, a UCI chess playing engine derived from Glaurung 2.1
Copyright (C) 2004-2008 Tord Romstad (Glaurung author)
Copyright (C) 2008-2015 Marco Costalba, Joona Kiiski, Tord Romstad

Stockfish is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

Stockfish is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#ifndef POSITION_H_INCLUDED
#define POSITION_H_INCLUDED

#include <cassert>
#include <cstddef>  // For offsetof()
#include <deque>
#include <memory>
#include <string>
#include <algorithm>
#include <cstring>

#include "types.h"
#include "bitboard.h"
#include "bitboardc.h"
#include "uci.h"

class Position;
class Thread;

const int MIDGAME_BIG_COUNT = 9;
const int ENDGAME_BIG_COUNT = 5;


namespace PSQT {

	extern Score psq[PIECE_NB][SQUARE_NB];

	void init();
}


const int MAX_CATCH_COUNT = 2;

struct StateInfo {

	// Copied when making a move
	Key    materialKey;
	Key	   bigKey;
	int	   bigCount[COLOR_NB];			//˫��������
	int    rule50;
	Score  psq;

	// Not copied when making a move
	Key        key;
	BitboardC  checkersBC;
	Piece      capturedPiece;
	Move	   lastMv;
	Piece	   lastPc;
	//Square	   catchSquare[MAX_CATCH_COUNT];
	//Value	   cycleV;
	CycleType  ct;
	StateInfo* previous;

	BitboardC blockersForKing[COLOR_NB];
	BitboardC blockersKnForKing[COLOR_NB];
	BitboardC checkSquares[PIECE_TYPE_NB];
	BitboardC cnNul;			//�ҷ���ͷ����Է���֮��

	

	inline bool operator==(const StateInfo& si) const {
		return materialKey == si.materialKey && bigKey == si.bigKey && bigCount[WHITE] == si.bigCount[WHITE]
			&& bigCount[BLACK] == si.bigCount[BLACK] && rule50 == si.rule50 && psq == si.psq && key == si.key
			&& checkersBC == si.checkersBC && capturedPiece == si.capturedPiece && lastMv == si.lastMv
			&& lastPc == si.lastPc && ct == si.ct
			/*&& same_pi(si) && cycleV == si.cycleV*/ && blockersForKing[WHITE] == si.blockersForKing[WHITE]
			&& blockersForKing[BLACK] == si.blockersForKing[BLACK]
			&& blockersKnForKing[WHITE] == si.blockersKnForKing[WHITE]
			&& blockersKnForKing[BLACK] == si.blockersKnForKing[BLACK]
			&& checkSquares[PAWN] == si.checkSquares[PAWN]
			&& checkSquares[KNIGHT] == si.checkSquares[KNIGHT]
			&& checkSquares[CANNON] == si.checkSquares[CANNON]
			&& checkSquares[ROOK] == si.checkSquares[ROOK]
			&& cnNul == si.cnNul;

	}
	inline bool operator!=(const StateInfo& si) const {
		return !(*this == si);
	}

};

typedef std::unique_ptr<std::deque<StateInfo>> StateListPtr;


class Position {

public:
	static void init();

	Position() = default; // To define the global object RootPos
	Position(const Position&) = delete;
	Position(const Position* pp, StateInfo* si, Thread* th);
	
	Position& set(const std::string& fenStr, StateInfo* si, Thread* th);
	const std::string fen() const;
	bool operator==(const Position&) const;		//�Ƚ��Ƿ���ȫ��ȣ����ڲ���

												// Position representation
	constexpr BitboardC pieces() const;
	constexpr BitboardC pieces(PieceType pt) const;
	BitboardC pieces(PieceType pt1, PieceType pt2) const;
	constexpr BitboardC pieces(Color c) const;
	BitboardC pieces(Color c, PieceType pt) const;
	BitboardC pieces(Color c, PieceType pt1, PieceType pt2) const;
	BitboardC pieces(Color c, PieceType pt1, PieceType pt2, PieceType pt3) const;

	BitboardC pieces_phome(Color c) const;
	template<Color c> BitboardC pieces_pawn_crnb() const;
	BitboardC pieces_big(Color c) const;

	Piece piece_on(Square s) const;
	PieceType pt_on(Square s) const;
	bool empty(Square s) const;
	bool pawn_cr(Square s) const;
	constexpr int count(Color c, PieceType Pt) const;
	constexpr int count(PieceType Pt) const;
	constexpr int count(Color c, PieceType pt1, PieceType pt2) const;

	constexpr const Square* squares(Color c, PieceType Pt) const;
	Square square(Color c, PieceType Pt) const;

	constexpr int all_big_count() const;
	constexpr int big_count(const Color c) const;
	constexpr bool zero_attack(Color c) const;
	constexpr bool full_ba(Color c) const;
	constexpr bool zero_ba(Color c) const;
	constexpr int  defense_count(const Color c) const;

	int both_danger_pawn() const;

	BitboardC  btw_bc(const Square s1, const Square s2) const;

	Square pawn_monsterknock(Color c) const;
	bool is_pawns_doublemonster(Color c) const;	//ĳ�����Ƿ�˫������
	bool is_advisor_cavel(Color c) const;	//ĳ���Ƿ������ʿ
	bool is_king_mid(Color c) const;		//ĳ�����Ƿ�����·
	bool is_king_org(Color c) const;		//ĳ�����Ƿ���ԭλ
	bool is_king_bottom(Color c) const;		//ĳ�����Ƿ��ڵ���
	bool is_king_rank2(Color c) const;		//ĳ�����Ƿ��ڶ�·��

	template<Color c> constexpr int big_count(Flank fl) const;
	template<Color c, Flank fl> constexpr int big_count() const;
	
	template<Color c, PieceType pt, Flank fl> constexpr int big_count() const;
	template<Color c> constexpr int bigattack_count(Flank fl) const;
	template<Color c> constexpr int kncn_count(Flank fl) const;
	template<Color c> constexpr int rook_count(Flank fl) const;
	template<Color c> constexpr bool rook_there(Flank fl) const;
	template<Color c> int attack_count() const;

	
	template<Color c, int dist>  bool is_king_clear() const;		//�Ź�������������û���ӵ�ס��
	template<Color c>  bool is_king_mid_clear() const;	//ĳ�����Ƿ�ռ����¶��
	template<Color c>  bool is_king_flank_clear() const;//ĳ�����Ƿ��ڲ���¶��
	template<Color c>  bool is_king_top() const;		//ĳ�����Ƿ��ڶ�¥
	template<Color c>  bool is_pawns_partner() const;	//ĳ�����Ƿ������֣�����Ҫ���ӣ�
	template<Color c>  bool is_pawns_partner_midhigh() const;	//ĳ�����Ƿ��ڶԷ����������λ����
																//template<Color c>  bool has_kongtou_cannon() const; //ĳ���Ƿ��п�ͷ��
																//template<Color c>  bool has_woxin_knight() const;	//ĳ���Ƿ���������
	template<Color c>  bool rook_through(const Square s) const;
	template<Color c>  BishopAdvisorNum ba_number() const;

	
	template<Color c>  constexpr int  pawn_homecount() const;
	template<Color c>  constexpr int  pawn_crcount() const;
	template<Color c>  constexpr int  pawn_highcount() const;
	template<Color c>  constexpr int  pawn_crhighcount() const;
	template<Color c>  constexpr int  pawn_high2count() const;
	template<Color c>  constexpr bool pawn_diffflank() const;
	template<Color c>  int  pawn_bottomcount() const;
	template<Color c>  int  pawn_validcount() const;
	template<Color c>  int  pawn_crhighmidcount() const;
	template<Color c>  int  pawn_onkingcount() const;
	template<Color c>  int  pawn_onkinglow3count() const;
	template<Color c>  int  pawn_cronkingcount() const;
	template<Color c>  int  pawn_low3count() const;
	template<Color c>  int  pawn_low2count() const;
	template<Color c>  int  pawn_lowcount() const;
	template<Color c>  int  pawn_nobottomcount() const;
	template<Color c>  int  pawn_mindist_king(const Square ksq) const;
	template<Color c>  int  pawn_mindist_king(const Square ksq, Square& psq) const;
	template<Color c>  int  pawn_dist_king(const Square ksq) const;
	template<Color c>  bool pawn_midbishop() const;
	template<Color c>  int  pawn_attackable() const;
	
	BitboardC checkers() const;
	BitboardC discovered_check_candidates() const;
	bool	  discovered_check_candidates(const Square s) const;		//s��������side_to_moveһ��
	template<Color c>
	BitboardC discovered_check_candidates() const;
	BitboardC discovered_check_candi_knight() const;
	bool	  discovered_check_candi_knight(const Square s) const;	//s��������side_to_moveһ��
	BitboardC pinned_pieces(Color c) const;
	BitboardC pinned_pieces_knight(Color c) const;
	BitboardC check_squares(PieceType pt) const;
	BitboardC cn_nul() const;

	BitboardC discovered_nul_cannon() const;

	// Attacks to/from a given square
	BitboardC attackers_to(Square s) const;
	BitboardC attackers_to(Square s, BitboardC occupied) const;
	BitboardC attackers_to_pawn(Square s, Color c) const;

	void attackers_to_nokingrkcn(const Color c, const BitboardC target, ExtMove*& mvList) const;
	void attackers_to_nokingrkcnpw(const Color c, const Square to, ExtMove*& mvList) const;

	template<Color c> BitboardC attack_knight_onlypin(Square s) const;

	template<bool b = true>
	static BitboardC attack_knight_pin(Square s, const BitboardC occ);
	static BitboardC attack_bishop_pin(Square s, const BitboardC occ);

	BitboardC	cannon_moves(Color c, Square s) const;
	BitboardC	rook_cannon_moves(Color c, Square s) const;

	//BitboardC attacks_from(Piece pc, Square s) const;
	template<PieceType> BitboardC attacks_from(Square s) const;
	template<Color c> BitboardC attacks_from_pawn(Square s) const;
	template<Color c> BitboardC pawn_attacks() const;
	template<Color c, Square exclude = SQ_NONE> BitboardC bishop_attacks() const;
	template<Color c> BitboardC advisor_attacks() const;
	template<Color c, Square exclude = SQ_NONE> BitboardC knight_attacks() const;

	bool root_square(Square s, Color c, BitboardC occ) const;
	bool high_risk() const;
	template<Color c> bool high_risk() const;
	// Properties of moves
	bool legal(const Move m) const;
	bool pseudo_legal(const Move m) const;
	bool pin_legal(const Move m) const;
	template<PieceType pt>
	bool pin_legal(const Move m) const;
	bool capture(const Move m) const;
	bool gives_check(const Move m) const;
	bool advanced_pawn_push(const Move m) const;
	//bool threat_move(const Move m) const;
	Piece moved_piece(const Move m) const;
	Piece captured_piece() const;
	bool	legal_twomoves(Move m1, Move m2) const;
	bool	complicated() const;

	// Doing and undoing moves
	void do_move(const Move m, StateInfo& st);
	void do_move(const Move m, StateInfo& st, bool givesCheck);
	void undo_move(const Move m);
	void undo_move_nc(const Move m);	//û�г��ӵĳ���
	void do_null_move(StateInfo& st);
	void undo_null_move();

	template<bool checks = false> void do_move_essen(Move m, StateInfo& newSt);
	void undo_move_essen(Move m);

	void do_move_key(Move m, StateInfo& newSt);
	void undo_move_key(Move m);
	//Value see(const Move m) const;
	//Value see_sign(const Move m) const;
	// Static Exchange Evaluation
	bool see_ge(Move m, Value value = VALUE_ZERO) const;
	bool see_ge_sign(Move m) const;

	// Accessing hash keys
	Key key() const;
	Key key_after(const Move m) const;
	Key material_key() const;
	//Key pawn_key() const;
	Key big_material_key() const;

	// Other properties of the position
	Color side_to_move() const;
	Phase game_phase() const;
	int game_ply() const;
	Thread* this_thread() const;
	bool is_draw() const;
	int rule50_count() const;
	Score psq_score() const;
	//Value big_material(Color c) const;

	// Position consistency check, for debugging
	bool pos_is_ok(int* failedStep = nullptr) const;
	void flip();
	void reverse_color() { sideToMove = ~sideToMove; }		//����׽�޸���ʱ�õ�
															//rule
	bool cycle() const;
	Value computer_cycle_value()  const;


	//various
	StateInfo*  pre_st(const int n) const;		//ǰn����st  ǰ�ã��������Լ���ָ֤����Ч�� n must >= 0
	StateInfo*  pre_st() const;					//�ϸ��ϣ�Ҳ����ǰ1����st
	static bool king_meet(const Square ksq1, const Square ksq2, const BitboardC occupied);

	bool tworookscn_doge() const;

	//���� 
	template<Color c> bool iron_gate() const;

private:
	// Initialization helpers (used while setting up a position)
	void set_state(StateInfo* si) const;
	void set_check_info(StateInfo* si) const;
	void set_blocker_info(StateInfo* si) const;
	void set_checksq_info(StateInfo* si) const;

	// Other helpers
	template<PieceType pt>
	BitboardC slider_blockers(const BitboardC sliders, const Square s) const;

	void put_piece(Piece pc, Square s);
	void remove_piece(Piece pc, Square s);
	void move_piece(Piece pc, Square from, Square to);

	BitboardC attackers_to_offensive(const Square s, const Color c, const BitboardC occ) const;

	//void  catch_noroot(const PieceType pt, const Square from, const Square to) const;
	CycleType computer_cycle_type()  const;
	Value computer_cycle_value(const int round) const;
	Move  last_move() const;
	int   catch_info(IndexPieceType* ppt, const int count) const;
	bool  protect_strict(const Move m, const Square to);
	bool  capture_back(const PieceType pt, const Square from, const Square to);
	//static BitboardC	app_bishop_eye(const Square s, const BitboardC bcBishop, const BitboardC bc);

private:

	// Data members
	Piece board[SQUARE_NB];
	BitboardC byTypeBC[PIECE_TYPE_NB];
	BitboardC byColorBC[COLOR_NB];

	int pieceCount[PIECE_NB];
	Square pieceList[PIECE_NB][8];

	int index[SQUARE_NB];
	int gamePly;
	Color sideToMove;
	Thread* thisThread;
	StateInfo* st;

};


extern std::ostream& operator<<(std::ostream& os, const Position& pos);

inline Color Position::side_to_move() const {
	return sideToMove;
}

inline bool Position::empty(Square s) const {
	return board[s] == NO_PIECE;
}

inline bool Position::pawn_cr(Square s) const {
	return type_of(board[s]) == PAWN && square_color(s) != color_of(board[s]);
}

inline Piece Position::piece_on(Square s) const {
	return board[s];
}

inline PieceType Position::pt_on(Square s) const {
	return type_of(piece_on(s));
}

inline Piece Position::moved_piece(const Move m) const {
	return board[from_sq(m)];
}

inline  constexpr BitboardC Position::pieces() const {
	return byTypeBC[ALL_PIECES];
}

inline constexpr BitboardC Position::pieces(PieceType pt) const {
	return byTypeBC[pt];
}

////int* p : avoid to conflict with template<Color c>
//template<PieceType pt, int* p> inline BitboardC Position::pieces() const {
//	return byTypeBC[pt];
//}

inline BitboardC Position::pieces(PieceType pt1, PieceType pt2) const {
	return byTypeBC[pt1] | byTypeBC[pt2];
}

inline constexpr BitboardC Position::pieces(Color c) const {
	return byColorBC[c];
}

inline BitboardC Position::pieces(Color c, PieceType pt) const {
	return byColorBC[c] & byTypeBC[pt];
}

inline BitboardC Position::pieces(Color c, PieceType pt1, PieceType pt2) const {
	return byColorBC[c] & (byTypeBC[pt1] | byTypeBC[pt2]);
}

inline BitboardC Position::pieces(Color c, PieceType pt1, PieceType pt2, PieceType pt3) const {
	return byColorBC[c] & (byTypeBC[pt1] | byTypeBC[pt2] | byTypeBC[pt3]);
}

inline BitboardC Position::pieces_phome(Color c) const {
	return pieces(c, PAWN) & HomeSideBC[c];
}

inline BitboardC Position::pieces_big(Color c) const {
	return pieces(c, ROOK, KNIGHT, CANNON);
}

//�����ҷǵױ�
template<Color c> inline BitboardC Position::pieces_pawn_crnb() const {
	return pieces(c, PAWN) & CrossRiverNoBottom[c];
}

inline constexpr int Position::count(Color c, PieceType Pt) const {
	return pieceCount[make_piece(c, Pt)];
}

inline constexpr int Position::count(PieceType Pt) const {
	return pieceCount[make_piece(WHITE, Pt)] + pieceCount[make_piece(BLACK, Pt)];
}

inline constexpr int Position::count(Color c, PieceType pt1, PieceType pt2) const {
	return pieceCount[make_piece(c, pt1)] + pieceCount[make_piece(c, pt2)];
}

inline constexpr const Square* Position::squares(Color c, PieceType Pt) const {
	return pieceList[make_piece(c, Pt)];
}

inline Square Position::square(Color c, PieceType Pt) const {
	assert(pieceCount[make_piece(c, Pt)] == 1);
	return pieceList[make_piece(c, Pt)][0];

}


// 2��square�������������λ����
// s1 s2��ͬ�л�ͬ�У��������ͬ�л�ͬ�У����Ϊ0		
//���Ϊ03�������1�ǲ�ͬ��Ҳ��ͬ�У�2 s1��s2���ڣ�Ҳ��ͬ�л�ͬ�У� 3 ͬ�л�ͬ�У����м�ش�û����
inline BitboardC  Position::btw_bc(const Square s1, const Square s2) const {
	return between_bc(s1, s2) & pieces();
}

inline constexpr int Position::all_big_count() const {
	return st->bigCount[WHITE] + st->bigCount[BLACK];

	//int n = st->bigCount[WHITE] + st->bigCount[BLACK];
	//return n != 6 ? n : n + ((count(WHITE, PAWN) - defense_count(BLACK) / 2) >= 1)
	//	+ ((count(BLACK, PAWN) - defense_count(WHITE) / 2) >= 1);

}

inline constexpr int Position::big_count(const Color c) const {
	return st->bigCount[c];
}


template<Color c, Flank fl> inline constexpr int Position::big_count() const {
	return popcount(pieces(c, KNIGHT, CANNON) & FlankMidBoardBC[fl]) + popcount(pieces(c, ROOK) & FlankMidBoardBC[fl]) * 2;
}

//ĳ�������Ŀ���������Ҳ� ������· 
template<Color c> inline constexpr int Position::big_count(Flank fl) const {
	assert(fl == LEFT || fl == RIGHT);
	return popcount(pieces(c, KNIGHT, CANNON) & FlankMidBoardBC[fl]) + popcount(pieces(c, ROOK) & FlankMidBoardBC[fl]) * 2;
}

//Ҳ�����ڱ�
template<Color c, PieceType pt, Flank fl> inline constexpr int Position::big_count() const {
	return popcount(pieces(c, pt) & FlankMidBoardBC[fl]) * (pt == ROOK ? 2 : 1);
}

//template<Color c, PieceType pt> inline int Position::big_count(Flank fl) const {
//	assert(fl == LEFT || fl == RIGHT);
//	return fl == LEFT ? big_count<c, pt, LEFT>() : big_count<c, pt, RIGHT>();
//}

//�й����ԵĴ��ӣ���Ҫ�ڹ���λ��
template<Color c>
constexpr int Position::bigattack_count(Flank fl) const
{
	assert(fl == LEFT || fl == RIGHT);
	return popcount(pieces(c, KNIGHT) & KnightAttackBC[c] & FlankMidBoardBC[fl]) + popcount(pieces(c, CANNON) & FlankMidBoardBC[fl]) +
		popcount(pieces(c, ROOK) & FlankMidBoardBC[fl]) * 2;
}
//ĳ��������ĳ������� 
template<Color c>
constexpr int Position::kncn_count(Flank fl) const
{
	assert(fl == LEFT || fl == RIGHT);
	return popcount(pieces(c, KNIGHT, CANNON) & FlankMidBoardBC[fl]);
}

//ĳ������ĳ������� 
template<Color c>
constexpr int Position::rook_count(Flank fl) const
{
	assert(fl == LEFT || fl == RIGHT);
	return popcount(pieces(c, ROOK) & FlankMidBoardBC[fl]) * 2;
}

template<Color c>
constexpr bool Position::rook_there(Flank fl) const
{
	assert(fl == LEFT || fl == RIGHT);
	return not_z(pieces(c, ROOK) & FlankMidBoardBC[fl]);
}


//ĳ���������������������������ڼӹ��ӷǵױ�����һ����2��
template<Color c>
inline int Position::attack_count() const {
	return big_count(c) + pawn_validcount<c>();
}

inline constexpr bool Position::zero_attack(Color c) const {
	return (count(c, PAWN) + big_count(c)) == 0;
}

inline bool Position::is_king_mid(Color c) const {
	return not_z(pieces(c, KING) & FileEBC);
}

//����������û���ӵ�ס��
//dist: 0 ֻ���Ź���		1 һֱ�����ѷ��ӿ�
template<Color c, int dist>
inline bool Position::is_king_clear() const {
	const Rank r = (dist == 0 ? relative_rank<c>(RANK_3) : relative_rank<c>(RANK_5));
	Square sqKing = square(c, KING);
	File f = file_of(sqKing);
	Square s = make_square(f, r);
	return equal_z(btw_bc(sqKing, s));
}

template<Color c>
inline bool Position::is_king_mid_clear() const {
	return is_king_mid(c) && is_king_clear<c, 0>();
}

template<Color c>
inline bool Position::is_king_flank_clear() const {
	return !is_king_mid(c) && is_king_clear<c, 0>();
}

template<Color c>
inline bool Position::is_king_top() const {
	return not_z(pieces(c, KING) & Rank3FLOOR);
}

inline bool Position::is_king_bottom(Color c) const {
	return not_z(pieces(c, KING) & BottomBC);
}

inline bool Position::is_king_rank2(Color c) const {
	return not_z(pieces(c, KING) & Rank2FLOOR);
}

inline bool Position::is_king_org(Color c) const {
	return not_z(pieces(c, KING) & AreaKingOrg);
}
//ǣ�֣�ֻҪ���ӾͿ���
template<Color c>
inline bool Position::is_pawns_partner() const {
	BitboardC bc = pieces(c, PAWN) & HomeSideBC[~c];
	if (popcount(bc) < 2) return false;

	Square sLast = pop_lsb(&bc);
	do {
		Square s = pop_lsb(&bc);
		if (abs(s - sLast) == 1 && file_distance(s, sLast) == 1)
			return true;
		sLast = s;
	} while (not_z(bc));
	return false;
}

//����ǣ�֣������м䣬��λ
template<Color c>
inline bool Position::is_pawns_partner_midhigh() const {
	BitboardC bc = pieces(c, PAWN) & PawnPartnerBC[c];
	if (popcount(bc) < 2) return false;

	Square sLast = pop_lsb(&bc);
	do {
		Square s = pop_lsb(&bc);
		if (abs(s - sLast) == 1)
			return true;
		sLast = s;
	} while (not_z(bc));
	return false;
}

inline bool Position::is_pawns_doublemonster(Color c) const {
	return popcount(pieces(c, PAWN) & AreaDbMonster) == 2;
}

inline bool Position::is_advisor_cavel(Color c) const {
	return not_z(pieces(c, ADVISOR) & AreaAdvisorCavel);
}


// ĳ���ܷ��������� ʿ�����
inline constexpr int	Position::defense_count(const Color c) const {
	return count(c, BISHOP) + count(c, ADVISOR);
}

//˫����Σ�ձ���Ŀ
inline int Position::both_danger_pawn() const {
	return popcount(pieces(WHITE, PAWN) & DangerPawnSide[WHITE]) + popcount(pieces(BLACK, PAWN) & DangerPawnSide[BLACK]);
}

template<Color c>
inline BishopAdvisorNum Position::ba_number() const {
	int b = count(c, BISHOP);
	int a = count(c, ADVISOR);
	switch (b) {
	case 2:
		switch (a) {
		case 2:
			return BA_DBDA;
		case 1:
			return BA_DBA;
		default:
			assert(a == 0);
			return BA_DB;
		}
	case 1:
		switch (a) {
		case 2:
			return BA_BDA;
		case 1:
			return BA_BA;
		default:
			assert(a == 0);
			return BA_BS;
		}
	default:
		assert(b == 0);
		switch (a) {
		case 2:
			return BA_DA;
		case 1:
			return BA_AD;
		default:
			assert(a == 0);
			return BA_ZERO;
		}
	}
	assert(0);
	return BA_ZERO;

}

inline constexpr bool Position::full_ba(Color c) const {
	return defense_count(c) == 4;
}

inline constexpr bool Position::zero_ba(Color c) const {
	return defense_count(c) == 0;
}

//ĳ���ĳ��Ƿ��Ѿ��ڶԷ����߻�ֱͨ�Է����ߣ�ĳ���ĳ�����͸����
//ǰ�᣺s �ǳ���λ�� 
template<Color c>
inline bool Position::rook_through(const Square s) const {
	if (rank_of(s) == (c == WHITE ? RANK_9 : RANK_0))
		return true;
	BitboardC bc = ((pieces() ^ pieces(c, ROOK)) | s) & ReverseRankBC[c == WHITE ? RANK_9 : RANK_0];
	bc &= FileBC[file_of(s)];
	return not_z(bc) && (c == WHITE ? msb(bc) : lsb(bc)) == s;
}

//û�й��ӵı�����Ŀ
template<Color c>
inline constexpr int Position::pawn_homecount() const {
	return popcount(c == WHITE ? low64(pieces(c, PAWN)) : high64(pieces(c, PAWN)));
}

//������ӱ���Է����ľ��룬�������ױ�
template<Color c>
inline int Position::pawn_mindist_king(const Square ksq) const {
	int dist = 9;
	BitboardC bc = pieces_pawn_crnb<c>();
	while (not_z(bc)) {
		Square s = pop_lsb(&bc);
		assert(square_color(s) == square_color(ksq));
		int d = kp_distance(s, ksq);
		if (d < dist)
			dist = d;
	}
	assert(dist <= 9 && dist > 0);
	return dist;
}
//������ӱ���Է����ľ��룬�������ױ�
template<Color c>
inline int Position::pawn_mindist_king(const Square ksq, Square& psq) const {
	int dist = 9;
	BitboardC bc = pieces_pawn_crnb<c>();
	while (not_z(bc)) {
		Square s = pop_lsb(&bc);
		assert(square_color(s) == square_color(ksq));
		int d = kp_distance(s, ksq);
		if (d < dist) {
			dist = d;
			psq = s;
		}
	}
	assert(dist <= 9 && dist > 0);
	return dist;
}
//���ӱ���Է������ܾ��룬�������2�Σ� �������ױ�  ���ڳ嵽������ı������밴9����
template<Color c>
inline int Position::pawn_dist_king(const Square ksq) const {
	int dist = 0, min = 9, d;
	BitboardC bc = pieces_pawn_crnb<c>();
	while (not_z(bc)) {
		Square s = pop_lsb(&bc);
		assert(square_color(s) == square_color(ksq));
		d = front_square<c>(s, ksq) ? 9 : kp_distance(s, ksq);
		assert(d <= 9 && d > 0);
		dist += d;
		if (d < min)
			min = d;
	}
	return dist + min;
}

//���ӱ�����Ŀ
template<Color c>
inline constexpr int Position::pawn_crcount() const {
	return popcount(pieces(c, PAWN) & HomeSideBC[~c]);
}
//�ϱ���Ŀ
template<Color c>
inline int Position::pawn_bottomcount() const {
	return popcount(pieces(c, PAWN) & BottomBC);
}
//���ӵķ��ϱ���Ŀ
template<Color c>
inline int Position::pawn_validcount() const {
	return popcount(pieces(c, PAWN) & CrossRiverNoBottom[c]);
}

//���ӵĸ߱���Ŀ
template<Color c>
inline constexpr int Position::pawn_crhighcount() const {
	return popcount(pieces(c, PAWN) & HighPawnBC[c]);
}
//���м����й��Ӹ߱���Ŀ
template<Color c>
inline int Position::pawn_crhighmidcount() const {
	return popcount(pieces(c, PAWN) & HighPawnMid3[c]);
}

//�����ߵͱ���Ŀ
template<Color c>
inline int Position::pawn_low3count() const {
	return popcount(pieces(c, PAWN) & Rank3FLOOR);
}
//��2�ߵͱ���Ŀ
template<Color c>
inline int Position::pawn_low2count() const {
	return popcount(pieces(c, PAWN) & Rank2FLOOR);
}

//��2�߹��Ӹ߱���Ŀ
template<Color c>
inline constexpr int Position::pawn_high2count() const {
	return popcount(pieces(c, PAWN) & PawnCrHigh2Rank[c]);
}


// low2  + low3
template<Color c>
inline int Position::pawn_lowcount() const {
	return popcount(pieces(c, PAWN) & LowRankBC);
}
//�߱� ���Ӹ߱���δ���ӱ�
template<Color c>
inline constexpr int Position::pawn_highcount() const {
	return pawn_crhighcount<c>() + pawn_homecount<c>();
}

//���ϱ���Ŀ
template<Color c>
inline int Position::pawn_nobottomcount() const {
	return popcount(pieces(c, PAWN) & NoBottomBC);
}

//�ڶԷ���֮�ϵı���Ŀ include home pawns ͬһ�в���
template<Color c>
inline int Position::pawn_onkingcount() const {
	const Color Them = c == WHITE ? BLACK : WHITE;
	Rank r = relative_rank<Them>(square(Them, KING));
	return pawn_highcount<c>() + (r == RANK_0 ? pawn_low2count<c>() + pawn_low3count<c>() : r == RANK_1 ? pawn_low3count<c>() : 0);
}

//�ڶԷ���֮�ϵı������߱���Ŀ include home pawns 
template<Color c>
inline int Position::pawn_onkinglow3count() const {
	const Color Them = c == WHITE ? BLACK : WHITE;
	return pawn_highcount<c>() + pawn_low3count<c>() + (is_king_bottom(Them) ? pawn_low2count<c>() : 0);
}


//�ڶԷ���֮�ϵĹ��ӱ���Ŀ ͬһ�в���
template<Color c>
inline int Position::pawn_cronkingcount() const {
	const Color Them = c == WHITE ? BLACK : WHITE;
	Rank r = relative_rank<Them>(square(Them, KING));
	return pawn_crhighcount<c>() + (r == RANK_0 ? pawn_low2count<c>() + pawn_low3count<c>() : r == RANK_1 ? pawn_low3count<c>() : 0);
}

//�����ű�����square�����û�У����� SQ_NONE
inline Square Position::pawn_monsterknock(Color c) const {
	BitboardC bc = pieces(c, PAWN) & AreaDbMonster;
	return not_z(bc) ? lsb(bc) : SQ_NONE;
}

//�Ƿ��б�������λ
template<Color c>
inline bool Position::pawn_midbishop() const {
	return not_z(pieces(c, PAWN) & AreaMidBishop);
}

//���б�����ͬһ�ࣨ��������·��
template<Color c>
inline constexpr bool Position::pawn_diffflank() const {
	return not_z(pieces(c, PAWN) & FlankBoardBC[LEFT]) && not_z(pieces(c, PAWN) & FlankBoardBC[RIGHT]);
}

//���ڿɹ���λ�ñ�����Ŀ �����Ҳ��ڱ��߲��ڵ��� ���ڳ����о�
template<Color c>
inline int Position::pawn_attackable() const {
	return popcount(pieces(c, PAWN) & CrossRiverNoBottomNoBorder[c]);
}

//except pawn		���Ǳ����� ��������
template<PieceType Pt>
inline BitboardC Position::attacks_from(Square s) const {
	//return  Pt == BISHOP || Pt == ROOK ? attacks_bb<Pt>(s, byTypeBC[ALL_PIECES])
	//      : Pt == QUEEN  ? attacks_from<ROOK>(s) | attacks_from<BISHOP>(s)
	//      : StepAttacksBB[Pt][s];

	static_assert(Pt != PAWN, "must not be pawn!");
	switch (Pt)
	{
	case ROOK:
		return attacks_bc_rk(s, pieces());
	case CANNON:
		return attacks_bc_cn(s, pieces());
	case KNIGHT:
		return attack_knight_pin(s, pieces());
	case BISHOP:
		return attack_bishop_pin(s, pieces());
	default:
		assert(Pt == ADVISOR || Pt == KING);
		return PseudoAttacks[Pt][s];
	}
	assert(0);
	return bcZero;

}

template<Color c>
inline BitboardC Position::attacks_from_pawn(Square s) const {		//ר������PAWN
	return PawnAttackingBC[c][s];
}
//�����ߵ��ĸ��ӣ��������ӺͲ�����
inline BitboardC Position::cannon_moves(Color c, Square s) const {
	
	BitboardC bc = attacks_bc_rk(s, pieces()) & ~pieces();
	bc |= (attacks_bc_cn(s, pieces()) & pieces(~c));
	return bc;
}

inline BitboardC Position::attackers_to(Square s) const {
	return attackers_to(s, pieces());
}
//c�����ܹ������ĸ���
template<Color c>
inline BitboardC Position::pawn_attacks() const {
	BitboardC bc = bcZero;
	Square s;
	const Square* pl = squares(c, PAWN);
	while ((s = *pl++) != SQ_NONE) {
		bc |= PawnAttackingBC[c][s];
	}
	return bc;
}

template<Color c, Square exclude>
inline BitboardC Position::bishop_attacks() const {
	const Square* pl = squares(c, BISHOP);
	Square s;
	BitboardC bc = bcZero;
	while ((s = *pl++) != SQ_NONE && s != exclude) {
		bc |= attack_bishop_pin(s, pieces());
	}
	return bc;
}

template<Color c, Square exclude>
inline BitboardC Position::knight_attacks() const {
	const Square* pl = squares(c, KNIGHT);
	Square s;
	BitboardC bc = bcZero;
	while ((s = *pl++) != SQ_NONE && s != exclude) {
		bc |= attack_knight_pin(s, pieces());
	}
	return bc;
}


template<Color c>
inline BitboardC Position::advisor_attacks() const {
	const Square* pl = squares(c, ADVISOR);
	Square s = *pl;
	if (s != SQ_NONE) {
		BitboardC bc = attacks_from<ADVISOR>(s);
		s = *++pl;
		if (s != SQ_NONE) {
			bc |= attacks_from<ADVISOR>(s);
		}
		return bc;
	}
	return bcZero;
}

inline BitboardC Position::checkers() const {
	return st->checkersBC;
}

inline BitboardC Position::discovered_check_candidates() const {
	return st->blockersForKing[~sideToMove] & pieces(sideToMove);

}

inline bool Position::discovered_check_candidates(const Square s) const {
	return st->blockersForKing[~sideToMove] & s;
}


template<Color c>
inline BitboardC Position::discovered_check_candidates() const {
	const Color Them = c == WHITE ? BLACK : WHITE;
	return st->blockersForKing[Them] & pieces(c);
}


inline BitboardC Position::discovered_check_candi_knight() const {
	return st->blockersKnForKing[~sideToMove] & pieces(sideToMove);
}

inline bool Position::discovered_check_candi_knight(const Square s) const {
	return st->blockersKnForKing[~sideToMove] & s;
}

inline BitboardC Position::pinned_pieces(Color c) const {
	return st->blockersForKing[c] & pieces(c);
}


inline BitboardC Position::pinned_pieces_knight(Color c) const {
	return st->blockersKnForKing[c] & pieces(c);
}

inline BitboardC Position::discovered_nul_cannon() const {
	const Square* psq = squares(sideToMove, CANNON);
	Square s, ksq = square(~sideToMove, KING);
	BitboardC bc = bcZero, btw;
	while ((s = *psq++) != SQ_NONE) {
		btw = between_bc(s, ksq);
		if (not_z(btw) && equal_z(btw & pieces()))
			bc |= btw;
	}
	return bc;
}

inline BitboardC Position::check_squares(PieceType pt) const {
	return st->checkSquares[pt];
}

inline BitboardC Position::cn_nul() const {
	return st->cnNul;
}

inline bool Position::advanced_pawn_push(const Move m) const {
	Square from = from_sq(m);
	if (type_of(board[from]) == PAWN) {
		if (relative_rank(sideToMove, from) > RANK_5) {
			Square to = to_sq(m);
			if (relative_file(to) >= relative_file(from) && !is_bottom(to)) {
				return true;
			}
		}
	}
	return false;
}

inline Key Position::key() const {
	return st->key;
}
//
//inline Key Position::pawn_key() const {
//  return st->pawnKey;
//}

inline Key Position::material_key() const {
	return st->materialKey;
}

inline Key Position::big_material_key() const {
	return st->bigKey;
}

inline Score Position::psq_score() const {
	return st->psq;
}

inline int Position::game_ply() const {
	return gamePly;
}

inline int Position::rule50_count() const {
	return st->rule50;
}

/// Position::is_draw() tests whether the position is drawn by 50-move rule
/// or by repetition. It does not detect stalemates.

inline bool Position::is_draw() const {
	//return st->rule50 >= NoCaptureDraw * 2 || (zero_attack(WHITE) && zero_attack(BLACK));

	return st->rule50 >= 512 * 2 || (zero_attack(WHITE) && zero_attack(BLACK));//�����������

}


//only update board	pieceList	byTypeBC	byColorBC	pieceCount	sideToMove
template<bool checks>
void Position::do_move_essen(Move m, StateInfo& newSt) {

	assert(is_ok(m));

	// Copy some fields of the old state to our new StateInfo object except the
	// ones which are going to be recalculated from scratch anyway and then switch
	// our state pointer to point to the new (ready to be updated) state.
	std::memcpy(&newSt, st, offsetof(StateInfo, key));
	newSt.previous = st;
	st = &newSt;

	//Color Us = sideToMove;
	Color Them = ~sideToMove;
	Square from = from_sq(m);
	Square to = to_sq(m);

	Piece pc = piece_on(from);
	Piece captured = piece_on(to);

	assert(color_of(piece_on(from)) == sideToMove);
	assert(captured == NO_PIECE || color_of(captured) == Them);
	assert(type_of(captured) != KING);

	if (captured) {
		// Update board and piece lists
		remove_piece(captured, to);
	}
	//if (type_of(m) != CASTLING)
	move_piece(pc, from, to);

	st->capturedPiece = captured;
	if (checks)
		st->checkersBC = attackers_to_offensive(square(Them, KING), sideToMove, pieces());

	sideToMove = ~sideToMove;

	//assert(pos_is_ok());
}

inline BitboardC Position::attackers_to_offensive(const Square s, const Color c, const BitboardC occ) const {
    BitboardC bc = (attackers_to_pawn(s, c) & pieces(PAWN))
        | (attack_knight_pin<false>(s, occ)	& pieces(KNIGHT));

    Bitboard bbRank = RankIntFromBc(rank_of(s), occ);
    Bitboard bbFile = FileIntFromBc(file_of(s), occ);
    bc |= pieces(ROOK) & (AttacksRookRankBC[s][bbRank] | AttacksRookFileBC[s][bbFile]);
    bc |= pieces(CANNON) & (AttacksCannonRankBC[s][bbRank] | AttacksCannonFileBC[s][bbFile]);
    return bc & pieces(c);
}

inline bool Position::capture(const Move m) const {

	// Castling is encoded as "king captures the rook"
	assert(is_ok(m));
	return !empty(to_sq(m));
	//return (!empty(to_sq(m)) && type_of(m) != CASTLING) || type_of(m) == ENPASSANT;
}

//�ֵ�c�����ӣ��Է��Ƿ��б������ķ���
template<Color c>
inline bool Position::high_risk() const {
	if (count(c, ROOK) > 0) {
		const Color Them = c == WHITE ? BLACK : WHITE;
		//˫����ȱʿ���������ڵ���
		if (count(c, ROOK) == 2 && count(Them, ADVISOR) < 2 && !is_king_bottom(Them))
			return true;
		//���ڣ��һ���һ�����ӵĽ����ӣ���������������ӱ����� �ҶԷ�ȱ��
		if (count(c, CANNON) > 0 && count(Them, BISHOP) < 2) {
			if (count(c, ROOK) == 2 || count(c, CANNON) == 2 || not_z(pieces(c, KNIGHT) & KnightAttackBC[c]))
				return true;
		}
		//�������ҶԷ�������¥
		if (count(c, KNIGHT) > 0 && is_king_top<Them>())
			return true;
	}
	return false;
}

//�ֵ��ҷ����ӣ��Է��Ƿ��б������ķ���
inline bool Position::high_risk() const {
	return side_to_move() == WHITE ? high_risk<WHITE>() : high_risk<BLACK>();
}


//˫������һ���� m1, m2 ��m2�Ƿ���ɳ��� �ٶ� m1�Ϸ� m2�Ѿ��жϹ��������� 
inline bool  Position::legal_twomoves(Move m1, Move m2) const {
	Position pos;
	std::memcpy(&pos, this, sizeof(Position));
	assert(pos_is_ok());
	StateInfo si;
	pos.do_move_essen(m1, si);
	return pos.legal(m2);
}

inline Piece Position::captured_piece() const {
	return st->capturedPiece;
}

inline Thread* Position::this_thread() const {
	return thisThread;
}

inline bool Position::complicated() const {
	//int bigAll = big_count<WHITE>() + big_count<BLACK>();
	//return (bigAll >= 6) || 
	//	(bigAll >= 2 && (pawn_nobottomcount<WHITE>() >= 2 || pawn_nobottomcount<BLACK>() >= 2));
	return st->bigCount[WHITE] >= 2 || st->bigCount[BLACK] >= 2 || count(WHITE, PAWN) >= 2 || count(BLACK, PAWN) >= 2;
	//return st->bigCount[WHITE] >= 3 || st->bigCount[BLACK] >= 3;
}


inline void Position::put_piece(Piece pc, Square s) {
	board[s] = pc;
	byTypeBC[ALL_PIECES] |= s;
	byTypeBC[type_of(pc)] |= s;
	byColorBC[color_of(pc)] |= s;
	index[s] = pieceCount[pc]++;
	pieceList[pc][index[s]] = s;
	//++pieceCount[make_piece(color_of(pc), ALL_PIECES)];
}

inline void Position::remove_piece(Piece pc, Square s) {
	// WARNING: This is not a reversible operation. If we remove a piece in
	// do_move() and then replace it in undo_move() we will put it at the end of
	// the list and not in its original place, it means index[] and pieceList[]
	// are not guaranteed to be invariant to a do_move() + undo_move() sequence.
	byTypeBC[ALL_PIECES] ^= s;
	byTypeBC[type_of(pc)] ^= s;
	byColorBC[color_of(pc)] ^= s;

	/* board[s] = NO_PIECE;  Not needed, overwritten by the capturing one */
	Square lastSquare = pieceList[pc][--pieceCount[pc]];
	index[lastSquare] = index[s];
	pieceList[pc][index[lastSquare]] = lastSquare;
	pieceList[pc][pieceCount[pc]] = SQ_NONE;
	//--pieceCount[make_piece(color_of(pc), ALL_PIECES)];
}

inline void Position::move_piece(Piece pc, Square from, Square to) {
	// index[from] is not updated and becomes stale. This works as long as index[]
	// is accessed just by known occupied squares.
	BitboardC from_to_bb = SquareBC[from] ^ SquareBC[to];
	byTypeBC[ALL_PIECES] ^= from_to_bb;
	byTypeBC[type_of(pc)] ^= from_to_bb;
	byColorBC[color_of(pc)] ^= from_to_bb;
	board[from] = NO_PIECE;
	board[to] = pc;
	index[to] = index[from];
	pieceList[pc][index[to]] = to;

}

inline void Position::undo_move_key(Move m) {

	sideToMove = ~sideToMove;

	//Color Us = sideToMove;
	Square from = from_sq(m);
	Square to = to_sq(m);
	Piece pc = piece_on(to);
	//PieceType pt = type_of(pc);

	assert(empty(from));

	board[from] = pc;
	board[to] = st->capturedPiece;

	// Finally point our state pointer back to the previous state
	st = st->previous;
}

inline Move Position::last_move() const {
	return st->lastMv;
}

inline BitboardC Position::attackers_to_pawn(Square s, Color c) const {
	return  PawnAttackedBC[c][s];
}
//�����������Ӷ�target�Ĺ�������������������
//ǰ�ã�target��Ϊȫ0
//���������ȣ���������
inline void Position::attackers_to_nokingrkcn(const Color c, const BitboardC target, ExtMove*& mvList) const
{
	assert(not_z(target));

	BitboardC bc;
	Square s, to;
	const Square* pl = squares(c, PAWN);
	while ((s = *pl++) != SQ_NONE) {
		bc = PawnAttackingBC[c][s] & target;
		while (not_z(bc)) {
			*mvList++ = make_move(s, pop_lsb(&bc));
		}
	}
	pl = squares(c, BISHOP);
	while ((s = *pl++) != SQ_NONE) {
		bc = PseudoAttacks[BISHOP][s] & target;
		while (not_z(bc)) {
			to = pop_lsb(&bc);
			if(!(pieces() & bishop_eye(s, to)))
				*mvList++ = make_move(s, to);
		}
	}
	pl = squares(c, ADVISOR);
	while ((s = *pl++) != SQ_NONE) {
		bc = attacks_from<ADVISOR>(s) & target;
		while (not_z(bc)) {
			*mvList++ = make_move(s, pop_lsb(&bc));
		}
	}
	pl = squares(c, KNIGHT);
	while ((s = *pl++) != SQ_NONE) {
		bc = PseudoAttacks[KNIGHT][s] & target;
		while (not_z(bc)) {
			to = pop_lsb(&bc);
			if (!(pieces() & kn_pin(s, to)))
				*mvList++ = make_move(s, to);
		}
	}
}
//�����������Ӷ�to�Ĺ���������������������
//ǰ�ã�to != SQ_NONE
//���������ȣ���������
inline void Position::attackers_to_nokingrkcnpw(const Color c, const Square to, ExtMove*& mvList) const
{
	assert(is_ok(to));

	Square from;
	BitboardC bc = PseudoAttacks[BISHOP][to] & pieces(c, BISHOP);
	while (not_z(bc)) {
		from = pop_lsb(&bc);
		if (!(pieces() & bishop_eye(from, to)))
			*mvList++ = make_move(from, to);
	}
	bc = PseudoAttacks[ADVISOR][to] & pieces(c, ADVISOR);
	while (not_z(bc)) {
		*mvList++ = make_move(pop_lsb(&bc), to);
	}
	bc = PseudoAttacks[KNIGHT][to] & pieces(c, KNIGHT);
	while (not_z(bc)) {
		from = pop_lsb(&bc);
		if (!(pieces() & kn_pin(from, to)))
			*mvList++ = make_move(from, to);
	}
}

//����sλ��ʱ��ֻ���㵱c���б�����ʱ�����ӱ������ߵ���λ�� (�����Ȳ���������)
template<Color c>
inline BitboardC Position::attack_knight_onlypin(Square s) const
{
	BitboardC bcPin = attack_knight_pin(s, pieces(c, KNIGHT, CANNON, ROOK));
	return PseudoAttacks[KNIGHT][s] ^ bcPin;
}
// s: �����������λ��  occ�� ������λ���̣������ж�����
inline BitboardC Position::attack_bishop_pin(Square s, const BitboardC occ) {
	if (equal_z(PseudoAttacks[BISHOP][s]))
		return bcZero;
	BitboardC bc = occ & BishopPin[s];
	int n = popcount(bc);

	switch (n) {
	case 0:
		return PseudoAttacks[BISHOP][s];
	case 1:
		return BishopReachedPin[s][lsb(bc)];
	case 2:
		if (s == SQ_E2)
			return  midbishop_pin<WHITE>(s, bc);
		else if (s == SQ_E7)
			return  midbishop_pin<BLACK>(s, bc);
		else
			return bcZero;
	case 3:
		if (s == SQ_E2)
			return  midbishop_pin<WHITE>(s, bc);
		else
			return  midbishop_pin<BLACK>(s, bc);
	default:
		assert(n == 4);
		return bcZero;
	}
}

//���Ǳ�����		from: true from false to
template<bool from>
inline BitboardC Position::attack_knight_pin(Square s, const BitboardC occ) {
	BitboardC bc = occ & (from ? KnightPinFrom[s] : KnightPinTo[s]);
	int n = popcount(bc);
	return n == 0 ? PseudoAttacks[KNIGHT][s] : n == 4 ? bcZero : knight_pin<from>(s, bc);
}


/// Position::game_phase() calculates the game phase interpolating total non-pawn
/// material between endgame and midgame limits.
inline Phase Position::game_phase() const {

	return Phase((((std::max)(ENDGAME_BIG_COUNT, (std::min)(all_big_count(), MIDGAME_BIG_COUNT)) - ENDGAME_BIG_COUNT) * PHASE_MIDGAME)
		/ (MIDGAME_BIG_COUNT - ENDGAME_BIG_COUNT));
}
//��ʱû����
template<PieceType Pt>
inline bool Position::pin_legal(const Move m) const {
	static_assert(Pt == KNIGHT || Pt == BISHOP, "Pt must be knight or bishop");
	Square from = from_sq(m);
	Square to = to_sq(m);
	return !(pieces() & (Pt == KNIGHT ? kn_pin(from, to) : bishop_eye(from, to)));
}

//������� ����			��ʱû����
inline bool Position::pin_legal(const Move m) const {
	PieceType pt = pt_on(from_sq(m));
	if (pt == KNIGHT)
		return pin_legal<KNIGHT>(m);
	else if (pt == BISHOP)
		return pin_legal<BISHOP>(m);

	return true;
}

inline bool Position::king_meet(const Square ksq1, const Square ksq2, const BitboardC occupied) {
	BitboardC btw = between_bc(ksq1, ksq2);
	return not_z(btw) && equal_z(btw & occupied);
}


// ����������	������ ��https://www.xqbase.com/protocol/rule_asian.htm http://www.dpxq.com/hldcg/AXFRules/AXFRules.htm
// ���� �߶��� ������׽ 
// �ǳ�׽�и����ĳ���׽ 
// ��ץ�Է��ĳ�����ץ�Է����ڣ���ץ�Է�����(û�б���)�Ƕң�����׽  
// ��ץ�Է��ı�������׽
// ���ּ�׽�ӣ��ٱ�����������������׽���汣���ᱻɱ������˧���棩

// TODO:���׽�ӣ������ƶ����ӳ�Ϊ�ڼܣ�����ڳ�׽�ģ� ���ٱ����ȣ������׽�ӵģ� ��ɳ�׽�ӵģ���׽�ӵ�
// p2 == p1->previous->previous
//inline bool is_catch_asia(const StateInfo* p) {
//	return p->catch_same();
//}

inline bool Position::cycle() const {
	return st->ct != CT_NO;
}
//����ľ��棬˫��(��ʿ)�����ڳ齫��key���ظ�
inline bool Position::tworookscn_doge() const {

	if (st->rule50 > 12 && not_z(checkers() & pieces(CANNON)) ) {
		PieceType pt = type_of(st->lastPc);
		PieceType lastPt;
		if (pt == ROOK || pt == BISHOP || pt == ADVISOR) {
			StateInfo* pre = st->previous->previous;
			for (int i = 0; i < 6; ++i) {
				if (not_z(pre->checkersBC) && not_z(pre->checkersBC & pieces(CANNON)) 
					&& (lastPt = type_of(pre->lastPc), (lastPt == ROOK || lastPt == BISHOP || lastPt == ADVISOR)))
					pre = pre->previous->previous;
				else
					return false;
			}
			return true;
		}
	}
	return false;
}

inline StateInfo*  Position::pre_st(const int n) const {
	StateInfo* p = st;
	for (int i = 0; i < n; ++i)
		p = p->previous;
	return p;
}

inline StateInfo* Position::pre_st() const {
	return st->previous;
}

inline void Position::do_move(const Move m, StateInfo& newSt) {
	do_move(m, newSt, gives_check(m));
}


/// Position::undo_move() unmakes a move. When it returns, the position should
/// be restored to exactly the same state as before the move was made.
inline void Position::undo_move(const Move m) {

	assert(is_ok(m));

	sideToMove = ~sideToMove;

	//Color Us = sideToMove;
	Square from = from_sq(m);
	Square to = to_sq(m);
	Piece pc = piece_on(to);

	assert(empty(from));
	assert(type_of(st->capturedPiece) != KING);

	move_piece(pc, to, from); // Put the piece back at the source square

	if (st->capturedPiece) {
		put_piece(st->capturedPiece, to); // Restore the captured piece
	}

	// Finally point our state pointer back to the previous state
	st = st->previous;
	--gamePly;

	assert(pos_is_ok());
}

inline void Position::undo_move_nc(const Move m) {

	assert(is_ok(m));

	sideToMove = ~sideToMove;

	//Color Us = sideToMove;
	Square from = from_sq(m);
	Square to = to_sq(m);
	Piece pc = piece_on(to);

	assert(empty(from));
	assert(type_of(st->capturedPiece) != KING);

	move_piece(pc, to, from); // Put the piece back at the source square


	// Finally point our state pointer back to the previous state
	st = st->previous;

	assert(pos_is_ok());
}

inline CycleType Position::computer_cycle_type() const {
	assert(st->capturedPiece == NO_PIECE);
	assert(st->rule50 > 4);
	StateInfo* pre = st->previous->previous->previous->previous;
	assert(pre);
	if (pre->key == st->key)
		return CT_4;
	for (int i = 2; st->rule50 > CT_4 + i && i <= (CT_MAX - CT_4); i += 2) {
		pre = pre->previous->previous;
		assert(pre);
		if (pre->key == st->key)
			return CycleType(CT_4 + i);
	}

	return CT_NO;
}


// ��ǰpos�³���ѭ�����ķ���Ҫ����  
// VALUE_DRAW �������� VALUE_WIN_ILLEGAL �Է��������� -VALUE_WIN_ILLEGAL �ҷ���������
// ǰ�᣺cycle()== true
// Ŀǰֻ���ǵ�8��ѭ��
inline Value Position::computer_cycle_value()  const {

	// ����Ƿ�����ǰ��positionһ�𹹳�ѭ������
	assert(st->ct != CT_NO && st->rule50 > 4);

	return computer_cycle_value(st->ct / 2);


}
//�Ƿ�����������Ҳ���Ǳ�����û�б�ǣ�ƣ����˺󲻻ᱻ���Ͻ���
inline bool Position::protect_strict(const Move m, const Square to) {
	StateInfo si;
	do_move_essen(m, si);
	BitboardC bc = attackers_to(to) & pieces(side_to_move());
	while (not_z(bc)) {
		if (legal(make_move(pop_lsb(&bc), to))) {
			undo_move_essen(m);
			return true;
		}
	}

	undo_move_essen(m);

	return false;
}
//��ͬ���ӻ��ԣ�����������ʱ����Ϊ�б��ȣ�����һ���ܳԣ���һ�����ܣ�������׽��ң�����Իز��Ϸ������Ƕ��ӣ�������׽
inline bool Position::capture_back(const PieceType pt, const Square from, const Square to) {
	assert(pt >= KNIGHT && pt != KING);

	bool cb = (pt == KNIGHT) ? (attack_knight_pin<false>(to, pieces()) & from) : true;
	if (cb) {
		reverse_color();
		bool legalMv = legal(make_move(from, to));
		reverse_color();
		return  legalMv;
	}
	return false;
}

//���ԳԵ�s��c�����г����ڵĵ�
inline BitboardC Position::rook_cannon_moves(Color c, Square s) const{
	Bitboard bbRank = RankIntFromBc(rank_of(s), pieces());
	Bitboard bbFile = FileIntFromBc(file_of(s), pieces());
	BitboardC bc = pieces(ROOK) & (AttacksRookRankBC[s][bbRank] | AttacksRookFileBC[s][bbFile]);
	bc |= pieces(CANNON) & (AttacksCannonRankBC[s][bbRank] | AttacksCannonFileBC[s][bbFile]);
	bc &= pieces(c);
	return bc;
}
//c���Ƿ�������˨
//ǰ�������� c����1�ڣ���1�����Է���˫ʿ
template<Color c> 
inline bool Position::iron_gate() const {

	assert(count(c, CANNON) == 1 && count(c, ROOK)  == 1);

	const Color Them = c == WHITE ? BLACK : WHITE;
	if (count(Them, ADVISOR) < 2)
		return false;

	if (not_z(pieces(Them, ADVISOR) & FileEBC)) {
		BitboardC bc = pieces(c, ROOK) & AreaLeidaoFile;
		if (not_z(bc)) {
			Square rsq = lsb(bc);
			assert(rsq != SQ_NONE);
			File rf = file_of(rsq);
			if (rf == FILE_D || rf == FILE_F) {
				bc = pieces(c, CANNON) & FileEBC;
				if (not_z(bc)) {
					//�ں���֮��Ҫ������
					Square csq = lsb(bc);
					assert(csq != SQ_NONE);
					if (is_king_org(Them) && popcount(btw_bc(csq, square(Them, KING))) == 2) {
						bc = pieces(Them, ADVISOR) & BottomBC;
						if (not_z(bc)) {
							File af = file_of(lsb(bc));
							assert(af == FILE_D || af == FILE_F);
							if (rf != af)
								return true;
						}
					}
				}
			}
		}
	}

	return false;
}


#if 0

//m ����������в �������ǵ�ǰ���Ĳ�
//ǰ�᣺m���Ὣ��  ������
inline bool Position::threat_move(const Move m) const {
	Square from = from_sq(m);
	PieceType pt = pt_on(from);
	if (pt == BISHOP || pt == ADVISOR)
		return false;

	Square to = to_sq(m);
	Color Them = ~side_to_move();
	Square ksq = square(Them, KING);
	BitboardC bc, bcTmp;

	if (pt == PAWN) {
		if (kp_distance(to, ksq) == 2 && (bottom_rank(ksq) || !bottom_rank(to)))
			return true;
	}
	else if (pt == KING) {
		if (!is_same_file(from, to)) {
			File f = file_of(to);
			bc = pieces<ROOK>(side_to_move()) & FileBC[f];
			while (not_z(bc)) {
				Square s = pop_lsb(&bc);
				if (equal_z(btw_bc(s, to)))
					return true;
			}
		}
	}


	if (pt == CANNON) {
		//û��֮ǰ, from ����ͬ�л�ͬ��
		if (is_same_row(from, ksq)) {
			bc = btw_bc(from, ksq);
			int count = popcount(bc);
			if (count == 0) {	//��ͷ�� ����� 
				if (popcount(btw_bc(to, ksq)) == 1)
					return true;
			}
		}
		else {
			if (is_same_row(to, ksq)) {
				bc = btw_bc(to, ksq);
				if (equal_z(bc)) {
					if (kp_distance(to, ksq) > 1)
						return true;
				}
				else if (popcount(bc) == 2) {
					if (not_z(bc & pieces_big(side_to_move())))
						return true;
				}
			}
		}

		if (!is_same_row(to, ksq)) {
			bc = (attacks_bc_rk(to, pieces()) &  ~pieces()) | (attacks_bc_cn(to, pieces()) & pieces(Them));
			bcTmp = attacks_from<CANNON>(ksq);
			if (not_z(bc & bcTmp))
				return true;

		}
	}
	switch (pt) {
	case ROOK:
		if (!aligned(from, to, ksq) && rank_of(from) == rank_of(to) && square_flank(from) != square_flank(to)) {
			bc = attacks_bc_rk(ksq, pieces()) & FileBC[rank_of(ksq)] & ~pieces(side_to_move());
			if (not_z(bc & attacks_bc_rk(to, pieces() ^ pieces<ROOK>(side_to_move())))) {
				return true;
			}
		}
		break;

	case KNIGHT:
		//���ߵ��ҷ��ӱ��ȵĽ���λ��
		if ((PseudoAttacks[KNIGHT][to] & ksq) && (pieces(side_to_move()) & kn_pin(to, ksq)))
			return true;
		//�²��ɹ�������
		bc = attacks_from<KNIGHT>(to) & ~pieces(side_to_move());
		//BitboardC bcNew = (pieces() ^ from) | to;
		bcTmp = attack_knight_pin<false>(ksq, pieces());
		if (not_z(bc & bcTmp))
			return true;

		//���²������ÿ�ͷ�ڽ�����Ҳ����в��
		bcTmp = discovered_nul_cannon();
		if (not_z(bc & bcTmp))
			return true;
		break;

		////���������ڿ��Խ���
		//bc = pieces<CANNON>(side_to_move()) & SameRowBC[from];
		//while (not_z(bc)) {
		//	Square s = pop_lsb(&bc);
		//	bcTmp = attacks_bc_rk(s, bcNew) & ~pieces() & attacks_bc_cn(ksq, bcNew);
		//	if (not_z(bcTmp)) return true;
		//}
		//
		////�����ڼ��ӣ����ڿ��Խ���
		//bc = pieces<CANNON>(side_to_move()) & SameRowBC[to];
		//while (not_z(bc)) {
		//	Square s = pop_lsb(&bc);
		//	bcTmp = attacks_bc_cn(s, bcNew) & pieces(Them) & attacks_bc_cn(ksq, bcNew);
		//	if (not_z(bcTmp)) return true;
		//}

	default:
		break;
	}

	//�ں���֮���pin�� �����2����3���ӣ����жԷ��ĳ�����ֱ�ӹ�����������в�� (ֻ���ǵ����������ڣ���)
	Square s, sqRk;
	bc = pieces<CANNON>(side_to_move()) & FileBC[file_of(ksq)];
	while (not_z(bc)) {
		s = pop_lsb(&bc);	//�ҷ�����λ��
		bcTmp = btw_bc(s, ksq);
		int pins = popcount(bcTmp);
		if (pins == 2 || pins == 3) {
			bcTmp &= pieces(Them, ROOK);
			if (not_z(bcTmp)) {
				sqRk = lsb(bcTmp);		//���ҷ�����ǣ��ס�ĶԷ���λ��
				assert(is_ok(sqRk));
				switch (pt) {
				case ROOK:
					break;
				case KNIGHT:
					break;
				case CANNON:
					break;
				case PAWN:
					if (PawnAttackingBC[side_to_move()][to] & sqRk)
						return true;
					break;
				default:
					break;
				}
			}
		}
	}	//while (not_z(bc))

	return false;
}
#endif

#endif // #ifndef POSITION_H_INCLUDED