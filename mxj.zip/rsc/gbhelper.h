#if !defined(GBHELPER_H_INCLUDED)
#define GBHELPER_H_INCLUDED

#include <string>

#include "types.h"

class Position;

static const char* gb_forward = "��";
static const char* gb_backward = "��";

//std::string move_to_gb(const Position& pos, Move m);

//Move		gb_to_move(const Position& pos, const std::string& sGb);


inline bool  is_forward(const Color c, const std::string& s){
	return (c == WHITE && s == gb_forward) || (c == BLACK && s == gb_backward);
}

inline bool  is_forward(const Color c, const int distance){
	assert(distance != 0);
	return c == WHITE ? distance > 0 : distance < 0;
}


#endif // !defined(GBHELPER_H_INCLUDED)
