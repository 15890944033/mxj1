/*
Stockfish, a UCI chess playing engine derived from Glaurung 2.1
Copyright (C) 2004-2008 Tord Romstad (Glaurung author)
Copyright (C) 2008-2015 Marco Costalba, Joona Kiiski, Tord Romstad

Stockfish is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

Stockfish is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/
#include <algorithm>
#include "types.h"
#include "bitboardc.h"
#include "util_vmp.h"


Value PieceValue[PHASE_NB][PIECE_NB] = {
	{ VALUE_ZERO, PawnValueMg, BishopValueMg, AdvisorValueMg, KnightValueMg, CannonValueMg, RookValueMg },
	{ VALUE_ZERO, PawnValueEg, BishopValueEg, AdvisorValueEg, KnightValueEg, CannonValueEg, RookValueEg } };

Value PawnPosValue[COLOR_NB][SQUARE_NB] = { VALUE_ZERO };

namespace PSQT {

#define S(mg, eg) make_score(mg, eg)

	//#define M min_bv 

	// Bonus[PieceType][Square / 2] contains Piece-Square scores. For each piece
	// type on a given square a (middlegame, endgame) score pair is assigned. Table
	// is defined for files A..D and white side: it is symmetric for black side and
	// second half of the files.
	const Score Bonus[][RANK_NB][int(FILE_NB + 1) / 2] = {
		{},
		{ // Pawn ��
			S(0, 0),			S(0, 0),		S(0, 0),		S(0, 0),		S(0, 0),
			S(0, 0),			S(0, 0),		S(0, 0),		S(0, 0),		S(0, 0),
			S(0, 0),			S(0, 0),		S(0, 0),		S(0, 0),		S(0, 0),
			S(0, -14),			S(0, 0),		S(23, 3),		S(0, 0),		S(78, 36),
			S(65, 21),			S(0, 0),		S(136, 56),		S(0, 0),		S(125, 77),

			S(166, 108),		S(217, 127),	S(308, 138),	S(337, 159),	S(344, 178),
			S(191, 121),		S(246, 144),	S(327, 163),	S(350, 206),	S(357, 219),
			S(214, 138),		S(271, 157),	S(302, 152),	S(325, 229),	S(438, 481),
			S(215, 149),		S(278, 168),	S(323, 205),	S(488, 298),	S(1017, 697),
			S(0, -196),			S(1, -189),		S(4, -172),		S(9, -131),		S(44, -96),
		},

		{ // Bishop ��
			S(0, 0),			S(0, 0),		S(2, 2),		S(0, 0),		S(0, 0),
			S(0, 0),			S(0, 0),		S(0, 0),		S(0, 0),		S(0, 0),
			S(-60, -18),		S(0, 0),		S(0, 0),		S(0, 0),		S(93, 39),
			S(0, 0),			S(0, 0),		S(0, 0),		S(0, 0),		S(0, 0),
			S(0, 0),			S(0, 0),		S(-27, -13),		S(0, 0),		S(0, 0),

			S(0, 0), S(0, 0), S(0, 0), S(0, 0), S(0, 0),
			S(0, 0), S(0, 0), S(0, 0), S(0, 0), S(0, 0),
			S(0, 0), S(0, 0), S(0, 0), S(0, 0), S(0, 0),
			S(0, 0), S(0, 0), S(0, 0), S(0, 0), S(0, 0),
			S(0, 0), S(0, 0), S(0, 0), S(0, 0), S(0, 0),
		},

		{ // Advisor ʿ
			S(0, 0),			S(0, 0),		S(0, 0),		S(0, -10),		S(0, 0),
			S(0, 0),			S(0, 0),		S(0, 0),		S(0, 0),		S(90, 16),
			S(0, 0),			S(0, 0),		S(0, 0),		S(-26, -6),		S(0, 0),
			S(0, 0), S(0, 0), S(0, 0), S(0, 0), S(0, 0),
			S(0, 0), S(0, 0), S(0, 0), S(0, 0), S(0, 0),

			S(0, 0), S(0, 0), S(0, 0), S(0, 0), S(0, 0),
			S(0, 0), S(0, 0), S(0, 0), S(0, 0), S(0, 0),
			S(0, 0), S(0, 0), S(0, 0), S(0, 0), S(0, 0),
			S(0, 0), S(0, 0), S(0, 0), S(0, 0), S(0, 0),
			S(0, 0), S(0, 0), S(0, 0), S(0, 0), S(0, 0),
		},

		{ // Knight
			S(-19, -173),	S(0, -138),		S(3, -113),		S(-26, -88),	S(-67, -119),
			S(-12, -110),	S(13, -91),		S(24, -80),		S(23, -49),		S(-268, -348),
			S(89, 7),		S(128, 14),		S(173, 43),		S(130, 44),		S(101, 33),
			S(124, 10),		S(127, 17),		S(200, 38),		S(205, 89),		S(284, 98),
			S(129, 15),		S(208, 40),		S(343, 131),	S(296, 98),		S(403, 125),

			S(126, 38),		S(253, 67),		S(268, 108),	S(331, 121),	S(398, 120),
			S(101, 43),		S(354, 148),	S(235, 128),	S(468, 282),	S(277, 141),
			S(146, 56),		S(143, 73),		S(356, 152),	S(413, 181),	S(434, 202),
			S(71, 21),		S(88, 28),		S(441, 187),	S(242, 128),	S(201, 102),
			S(78, 23),		S(67, 21),		S(95, 38),		S(108, 30),		S(115, 36),

		},
		{ // Cannon
			S(-14,-14),		S(-9,-9),		S(12,6),		S(21,21),		S(20,-10),
			S(41,9),		S(36,8),		S(77,33),		S(10,24),		S(57,-11),
			S(39,26),		S(20,10),		S(87,37),		S(88,44), 		S(99,58),
			S(23,11),		S(34,16),		S(35,17), 		S(26,8), 		S(104,59),
			S(12,6),		S(42,26),		S(58,30), 		S(46,26),		S(115,72),

			S(20,10),		S(17,7), 		S(8,4),			S(23,11), 		S(136,76),
			S(43,21),		S(44,20), 		S(49,29), 		S(68,32), 		S(187,98),
			S(20,10),		S(65,31), 		S(24,12),		S(43,31),		S(48,24),
			S(29,13),		S(58,28), 		S(23,11),		S(44,22),		S(-59,-69),
			S(72,32),		S(80,49), 		S(20,10),		S(-10,-10), 	S(-60,-66),
		},

		{ // Rook
			S(0,-20),		S(139,47), 		S(92,30), 		S(199,39), 		S(-100,-190),
			S(111,33), 		S(213,59), 		S(157,37), 		S(224,75), 		S(-30,-108),
			S(38,14),		S(167,53), 		S(142,42), 		S(221,67), 		S(110,50),
			S(201,39), 		S(238,64), 		S(217,53), 		S(282,98), 		S(265,81),
			S(220,46), 		S(237,63), 		S(244,70), 		S(263,81),		S(268,84),

			S(189,35), 		S(204,46), 		S(230,76), 		S(252,78), 		S(291,101),
			S(252,78),		S(265,83), 		S(298,96),		S(347,143),		S(298,108),
			S(69,29),		S(170,32), 		S(113,41), 		S(188,44), 		S(233,89),
			S(64,22), 		S(147,35), 		S(106,36), 		S(221,87),		S(682,352),
			S(49,23), 		S(52,26), 		S(63,27), 		S(258,74), 		S(297,103),
		},
		{ // King
			S(0, 0),		S(0, 0),		S(0, 0),		S(-59, -15),		S(0, -10),
			S(0, 0),		S(0, 0),		S(0, 0),		S(-130, -22),		S(-121, -21),
			S(0, 0),		S(0, 0),		S(0, 0),		S(-259, -123),		S(-238, -98),
            S(0, 0), S(0, 0), S(0, 0), S(0, 0), S(0, 0),
			S(0, 0), S(0, 0), S(0, 0), S(0, 0), S(0, 0),

			S(0, 0), S(0, 0), S(0, 0), S(0, 0), S(0, 0),
			S(0, 0), S(0, 0), S(0, 0), S(0, 0), S(0, 0),
			S(0, 0), S(0, 0), S(0, 0), S(0, 0), S(0, 0),
			S(0, 0), S(0, 0), S(0, 0), S(0, 0), S(0, 0),
			S(0, 0), S(0, 0), S(0, 0), S(0, 0), S(0, 0),
		}
	};
#undef S
	Score psq[PIECE_NB][SQUARE_NB];
	// init() initializes piece square tables: the white halves of the tables are
	// copied from Bonus[] adding the piece value, then the black halves of the
	// tables are initialized by flipping and changing the sign of the white scores.
	void init() {
//#ifdef VMPROTECT
//		VMProtectBeginUltra("init_psqt");
//#endif

		for (Piece pc = W_PAWN; pc <= W_KING; ++pc) {

			PieceValue[MG][~pc] = PieceValue[MG][pc];
			PieceValue[EG][~pc] = PieceValue[EG][pc];

			Score v = make_score(PieceValue[MG][pc], PieceValue[EG][pc]);
			for (Square s = SQ_A0; s < SQUARE_NB; ++s)
			{
				//File f = file_of(s);
				//      int edgeDistance = f <= FILE_E ? f : ~f;
				//      psq[BLACK][pt][~s] = -(psq[WHITE][pt][s] = v + Bonus[pt][rank_of(s)][edgeDistance]);
				File f = file_of(s);
				f = std::min(f, ~f);
				psq[pc][s] = v + Bonus[pc][rank_of(s)][f];
				psq[~pc][~s] = -psq[pc][s];
			}
		}

		assert(not_z(AreaExtremDangerPawn));
		for (Square s = SQ_A0; s < SQUARE_NB; ++s) {
			if (square_color(s) == WHITE)
				PawnPosValue[WHITE][s] = PawnValueMg;
			else if (AreaExtremDangerPawn & s) {
				PawnPosValue[WHITE][s] = PawnDangerValueMg;
			}
			else
				PawnPosValue[WHITE][s] = PawnCrValueMg;

			PawnPosValue[BLACK][~s] = PawnPosValue[WHITE][s];
		}
//#ifdef VMPROTECT
//		VMProtectEnd();
//#endif
	}

} // namespace PSQT