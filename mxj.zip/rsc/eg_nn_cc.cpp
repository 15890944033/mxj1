#include "endgame.h"


//˫�����������ƣ��б��ޱ��ӷֲ�һ��
//˫�ڷ�û��ʿ���۷� 
//˫����2�����Ϲ��ӱ���������ӷǵ��ߵ�����Ҳ�û�б����۷�
//˫�������2��ʿ��û�����ʿ���۷�
//˫�ڷ�������˫��������˫���������ڷ���λ�ã��۷�
//�κ�һ����������һ����Ŀ���ڵ���2�����ӷ�
template<EndgameType E/*, typename T = eg_type<E>*/>
template<Color c>
inline void Endgame<E>::nn_cc_total(const Position& pos, Score& score) const {
	const Color Them = c == WHITE ? BLACK : WHITE;

	int adStrong = pos.count(c, ADVISOR);
	int adWeak = pos.count(Them, ADVISOR);

	int nbpStrong = pos.pawn_nobottomcount<c>();
	int nbpWeak = pos.pawn_nobottomcount<Them>();

	int vpStrong = pos.pawn_validcount<c>();
	int vpWeak = pos.pawn_validcount<Them>();

	int duitou = pawns_headtohead(pos);

	int dcdiff = pos.defense_count(Them) - pos.defense_count(c);

	Value v = nbpStrong > nbpWeak ? Value(98) : nbpStrong == nbpWeak ? Value(72) : VALUE_ZERO;

	if (pos.pawn_validcount<c>() >= 2
		&& (equal_z(pos.pieces_pawn_crnb<c>() & FlankBoardBC[LEFT]) || equal_z(pos.pieces_pawn_crnb<c>() & FlankBoardBC[RIGHT]))) {
		v += -PAWN_END_10P;
	}
	if (pos.pawn_validcount<Them>() >= 2
		&& (equal_z(pos.pieces_pawn_crnb<Them>() & FlankBoardBC[LEFT]) || equal_z(pos.pieces_pawn_crnb<Them>() & FlankBoardBC[RIGHT]))) {
		v += PAWN_END_10P;
	}

	if (adWeak == 2 && !pos.is_advisor_cavel(Them))
		v += BISHOP_END_10P;

	if (adWeak > 0 && nbpWeak > 0 && nbpStrong == 0 && !cannon_home_attack(pos, Them))
		v += PAWN_END_10P;


	//�����ʿ��ֵ���
	if (dcdiff > 0 && (((nbpStrong + duitou) > 0 && (nbpWeak + duitou) == 0) ||
		(vpStrong > 0 && vpWeak == 0 && nbpStrong > nbpWeak))) {
		v += dcdiff * BISHOP_END_40P;
	}
	else if (dcdiff < 0 && (((nbpStrong + duitou) == 0 && (nbpWeak + duitou) > 0) ||
		(vpWeak > 0 && vpStrong == 0 && nbpStrong < nbpWeak))) {
		v += dcdiff * BISHOP_END_40P;
	}

	//�ڵ��ƶ��Գͷ���
	BitboardC notAttacked[2];
	notAttacked[c] = ~(pos.pawn_attacks<Them>() | pos.bishop_attacks<Them>()
		| pos.advisor_attacks<Them>() | pos.attacks_from<KING>(pos.square(Them, KING)));
	notAttacked[Them] = ~(pos.pawn_attacks<c>() | pos.bishop_attacks<c>()
		| pos.advisor_attacks<c>() | pos.attacks_from<KING>(pos.square(c, KING)));

	//mob = cannon_mobility<c>(pos, notAttacked[c]);
	//v += value_cannon_mob<c>(pos, mob);

	//�����ƶ��Գͷ���
	v += value_knight_mob<c, false>(pos, notAttacked[c]);

	if (nbpStrong >= nbpWeak && vpStrong > vpWeak) {
		v += (vpStrong - vpWeak) * PAWN_END_20P;
	}
	else if (nbpStrong > 0 && nbpWeak == 0) {
		v += nbpStrong * PAWN_END_20P;
	}
	else if (nbpStrong <= nbpWeak && vpStrong < vpWeak) {
		v += (vpStrong - vpWeak) * PAWN_END_20P;
	}
	else if (nbpWeak > 0 && nbpStrong == 0) {
		v += -nbpWeak * PAWN_END_20P;
	}


	update_score(score, c,  v);

	v = VALUE_ZERO;
	if (greater_than<Them>(score, VALUE_ADV_LOWLIMIT)) {
		if (nbpWeak >= nbpStrong && !is_kn_defense<c>(pos)) {
			v += -BISHOP_END_20P;
		}
	}
	update_score(score, c,  v);

}

template<>
Value Endgame<KNNKCC>::operator()(const Position& pos, Score& score) const {
	if (strongSide == WHITE) {

		//һ��ǣ��2�����������۷�
		if (dbknking_chain_bycannon<WHITE>(pos))
			return update_score(score, -KNIGHT_END_140P);

		if (knking_chain_bycannon<WHITE>(pos) && pos.pawn_validcount<BLACK>() > 0)
			return update_score(score, -KNIGHT_END_70P);
	}
	else {
		//һ��ǣ��2�����������۷�
		if (dbknking_chain_bycannon<BLACK>(pos))
			return update_score(score, KNIGHT_END_140P);

		if (knking_chain_bycannon<BLACK>(pos) && pos.pawn_validcount<WHITE>() > 0)
			return update_score(score, KNIGHT_END_70P);
	}

	strongSide == WHITE ? nn_cc_total<WHITE>(pos, score) : nn_cc_total<BLACK>(pos, score);

	//if (pos.count(WHITE, PAWN) <= 3 && pos.count(BLACK, PAWN) <= 3) {
	//	if (pos.pawn_validcount<WHITE>() == 0 && pos.full_ba(BLACK) && greater_than<WHITE>(score, VALUE_ADV_LOWLIMIT)) {
	//		return value_draw_zoom<1>(score);
	//	}
	//	else if (pos.pawn_validcount<BLACK>() == 0 && pos.full_ba(WHITE) && greater_than<BLACK>(score, VALUE_ADV_LOWLIMIT)) {
	//		return value_draw_zoom<1>(score);
	//	}
	//}

	FUN_IMPL_DIFF_PIECES_ALL(knn_kcc)
}


template<EndgameType E/*, typename T = eg_type<E>*/>
template<Color strong> inline Value Endgame<E>::knn_kcc_0p_0p(const Position& pos, Score& score) const {
	return value_draw_zoom<8>(pos, score);
}

template<EndgameType E/*, typename T = eg_type<E>*/>
template<Color strong> inline Value Endgame<E>::knn_kcc_1p_0p(const Position& pos, Score& score) const {

	I_AM_WEAK

	auto ba = pos.ba_number<weak>();
	switch (ba)
	{
	case BA_ZERO:
	case BA_BS:
	case BA_AD:
	case BA_BA:
	case BA_DB:
	case BA_DA:
	case BA_DBA:
	case BA_BDA:
		break;
	default:	//ȫʿ��û�еױ���Ӯ���Ѷȴ�
		if (pos.pawn_bottomcount<strong>() > 0)
			break;

		return value_draw_zoom<2>(pos, score);
	}
	return 	VALUE_NONE;

}

template<EndgameType E/*, typename T = eg_type<E>*/>
template<Color strong> inline Value Endgame<E>::knn_kcc_2p_0p(const Position& pos, Score& score) const {
	return 	VALUE_NONE;
}

template<EndgameType E/*, typename T = eg_type<E>*/>
template<Color strong> inline Value Endgame<E>::knn_kcc_0p_1p(const Position& pos, Score& score) const {

	I_AM_WEAK
	auto baWeak = pos.ba_number<weak>();

	if (pos.full_ba(strong) && baWeak >= BA_DBA && pos.pawn_bottomcount<weak>() == 0)
		return value_draw_zoom<2>(pos, score);


	return 	VALUE_NONE;

}

template<EndgameType E/*, typename T = eg_type<E>*/>
template<Color strong> inline Value Endgame<E>::knn_kcc_1p_1p(const Position& pos, Score& score) const {
	//I_AM_WEAK
	//	if (pos.full_ba(strong) && pos.full_ba(weak))
	//		return value_draw_zoom<1>(score);

	return 	VALUE_NONE;
}

template<EndgameType E/*, typename T = eg_type<E>*/>
template<Color strong> inline Value Endgame<E>::knn_kcc_2p_1p(const Position& pos, Score& score) const {
	return 	VALUE_NONE;
}


template<EndgameType E/*, typename T = eg_type<E>*/>
template<Color strong> inline Value Endgame<E>::knn_kcc_0p_2p(const Position& pos, Score& score) const {
	//I_AM_WEAK

	//	if (pos.full_ba(strong) && pos.pawn_bottomcount<weak>() == 0)
	//		return value_draw_zoom<4>(pos, score);

	return 	VALUE_NONE;

}

template<EndgameType E/*, typename T = eg_type<E>*/>
template<Color strong> inline Value Endgame<E>::knn_kcc_1p_2p(const Position& pos, Score& score) const {
	return 	VALUE_NONE;
}

template<EndgameType E/*, typename T = eg_type<E>*/>
template<Color strong> inline Value Endgame<E>::knn_kcc_2p_2p(const Position& pos, Score& score) const {
	return 	VALUE_NONE;
}
