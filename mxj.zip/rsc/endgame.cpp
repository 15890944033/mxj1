/*
  Stockfish, a UCI chess playing engine derived from Glaurung 2.1
  Copyright (C) 2004-2008 Tord Romstad (Glaurung author)
  Copyright (C) 2008-2015 Marco Costalba, Joona Kiiski, Tord Romstad

  Stockfish is free software: you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation, either version 3 of the License, or
  (at your option) any later version.

  Stockfish is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#include <algorithm>
#include <cassert>

#include "bitboard.h"
#include "endgame.h"
#include "movegen.h"

using std::string;

namespace {
#if 0
  // Table used to drive the king towards the edge of the board
  // in KX vs K and KQ vs KR endgames.
  const int PushToEdges[SQUARE_NB] = {
    100, 90, 80, 70, 70, 80, 90, 100,
     90, 70, 60, 50, 50, 60, 70,  90,
     80, 60, 40, 30, 30, 40, 60,  80,
     70, 50, 30, 20, 20, 30, 50,  70,
     70, 50, 30, 20, 20, 30, 50,  70,
     80, 60, 40, 30, 30, 40, 60,  80,
     90, 70, 60, 50, 50, 60, 70,  90,
    100, 90, 80, 70, 70, 80, 90, 100
  };

  // Table used to drive the king towards a corner square of the
  // right color in KBN vs K endgames.
  const int PushToCorners[SQUARE_NB] = {
    200, 190, 180, 170, 160, 150, 140, 130,
    190, 180, 170, 160, 150, 140, 130, 140,
    180, 170, 155, 140, 140, 125, 140, 150,
    170, 160, 140, 120, 110, 140, 150, 160,
    160, 150, 140, 110, 120, 140, 160, 170,
    150, 140, 125, 140, 140, 155, 170, 180,
    140, 130, 140, 150, 160, 170, 180, 190,
    130, 140, 150, 160, 170, 180, 190, 200
  };

  // Tables used to drive a piece towards or away from another piece
  const int PushClose[8] = { 0, 0, 100, 80, 60, 40, 20, 10 };
  const int PushAway [8] = { 0, 5, 20, 40, 60, 80, 90, 100 };

  // Pawn Rank based scaling factors used in KRPPKRP endgame
  const int KRPPKRPScaleFactors[RANK_NB] = { 0, 9, 10, 14, 21, 44, 0, 0 };

#ifndef NDEBUG
  bool verify_material(const Position& pos, Color c, Value npm, int pawnsCnt) {
    return pos.big_material(c) == npm && pos.count<PAWN>(c) == pawnsCnt;
  }
#endif


  // Map the square as if strongSide is white and strongSide's only pawn
  // is on the left half of the board.
  Square normalize(const Position& pos, Color strongSide, Square sq) {

    assert(pos.count<PAWN>(strongSide) == 1);

    if (file_of(pos.square<PAWN>(strongSide)) >= FILE_E)
        sq = Square(sq ^ 7); // Mirror SQ_H0 -> SQ_A0

    if (strongSide == BLACK)
        sq = ~sq;

    return sq;
  }

  // Get the material key of Position out of the given endgame key code
  // like "KBPKN". The trick here is to first forge an ad-hoc FEN string
  // and then let a Position object do the work for Us.
  Key key(const string& code, Color c) {

    assert(code.length() > 0 && code.length() < 8);
    assert(code[0] == 'K');

    string sides[] = { code.substr(code.find('K', 1)),      // Weak
                       code.substr(0, code.find('K', 1)) }; // Strong

    std::transform(sides[c].begin(), sides[c].end(), sides[c].begin(), tolower);

    string fen =  sides[0] + char(8 - sides[0].length() + '0') + "/8/8/8/8/8/8/"
                + sides[1] + char(8 - sides[1].length() + '0') + " w - - 0 10";

    return Position(fen, nullptr).material_key();
  }
#endif

  string fen_black(const string& s){
	  assert(!s.empty());
	  assert(s[0] == 'k');

	  //���ֵ���Ŀ
	  int knightC = 0, cannonC = 0, rookC = 0;

	  for (size_t i = 0; i < s.size(); ++i)	  {
		  //if(s[i] == 'p') ++pawnC;
		  if (s[i] == 'n') ++knightC;
		  if (s[i] == 'c') ++cannonC;
		  if (s[i] == 'r') ++rookC;
	  }

	  string sFen = "4k4";

	  if (rookC == 1)
		  sFen += "/r8";
	  else if (rookC == 2)
		  sFen += "/rr7";
	  else
		  sFen += "/9";

	  if (cannonC == 1)
		  sFen += "/c8";
	  else if (cannonC == 2)
		  sFen += "/cc7";
	  else
		  sFen += "/9";

	  if (knightC == 1)
		  sFen += "/n8";
	  else if (knightC == 2)
		  sFen += "/nn7";
	  else
		  sFen += "/9";

	  sFen += "/9";
	  return sFen;
  }

  string fen_white(const string& s)  {
	  assert(!s.empty());
	  assert(s[0] == 'K');

	  //���ֵ���Ŀ
	  int knightC = 0, cannonC = 0, rookC = 0;

	  for (size_t i = 0; i < s.size(); ++i)	  {
		  if (s[i] == 'N') ++knightC;
		  if (s[i] == 'C') ++cannonC;
		  if (s[i] == 'R') ++rookC;
	  }

	  string sFen = "/9";

	  if (knightC == 1)
		  sFen += "/N8";
	  else if (knightC == 2)
		  sFen += "/NN7";
	  else
		  sFen += "/9";

	  if (cannonC == 1)
		  sFen += "/C8";
	  else if (cannonC == 2)
		  sFen += "/CC7";
	  else
		  sFen += "/9";

	  if (rookC == 1)
		  sFen += "/R2K5";
	  else if (rookC == 2)
		  sFen += "/RR1K5";
	  else
		  sFen += "/3K5";

	  sFen += "/9";
	  return sFen;
  }

  // Get the material key of a Position out of the given endgame key code
  // like "KBPKN". The trick here is to first forge an ad-hoc fen string
  // and then let a Position object to do the work for Us. Note that the
  // fen string could correspond to an illegal position.
  // ���İ��ţ��ڷ���ԭλ���췽����·�¶���
  // ʿ���ţ�ԭλ
  // ���䰲�ţ� �ѷ�ԭλ ��һ��
  // ���ڳ����ţ� ���϶��ߵ��¶������2��
  // code˳������ǰ�����������Ӵ���˳�� P->A->...->R
  Key key(const string& code, Color c) {

	  assert(code.length() > 0 && code.length() < 20);
	  assert(code[0] == 'K');

	  string sides[] = { code.substr(code.find('K', 1)),      // Weaker
		  code.substr(0, code.find('K', 1)) }; // Stronger

											   // СдΪ�ڷ�
	  std::transform(sides[c].begin(), sides[c].end(), sides[c].begin(), tolower);

	  string sBlack = fen_black(sides[c]);
	  string sWhite = fen_white(sides[~c]);

	  string fen = sBlack + sWhite + " w - - 0 1";
	  
	  StateInfo si;
	  Position pos;
	  pos.set(fen, &si, nullptr);
	  return pos.material_key();
  }

} // namespace


/// Endgames members definitions

Endgames::Endgames() {
	add_k();
	add_c();
	add_n();
	add_r();
	add_cc();
	add_nn();
	add_cn();
	add_rc();
	add_rn();
	add_rr();
}


template<EndgameType E/*, typename T*/>
void Endgames::add(const string& code) {
  //map<T>()[key(code, WHITE)] = std::unique_ptr<EndgameBase<T>>(new Endgame<E>(WHITE));
  //map<T>()[key(code, BLACK)] = std::unique_ptr<EndgameBase<T>>(new Endgame<E>(BLACK));
  maps[key(code, WHITE)] = std::unique_ptr<EndgameBase>(new Endgame<E>(WHITE));
  maps[key(code, BLACK)] = std::unique_ptr<EndgameBase>(new Endgame<E>(BLACK));
}



void Endgames::add_c(){
	add<KCKC>("KCKC");
	add<KCK>("KCK");
	
}

void Endgames::add_cc()
{
	add<KCCKC>("KCCKC");
	add<KCCKCC>("KCCKCC");
	add<KCCK>("KCCK");
	add<KCCKN>("KCCKN");
}

void Endgames::add_cn()
{
    add<KCNKC>("KCNKC");
	add<KCNKCC>("KCNKCC");
	add<KCNKCN>("KCNKCN");
	add<KCNK>("KCNK");
	add<KCNKN>("KCNKN");
	add<KCNKNN>("KCNKNN");

}

void Endgames::add_k() {
	add<KK>("KK");

}
void Endgames::add_n()
{
	add<KNKC>("KNKC");
	add<KNK>("KNK");
	add<KNKN>("KNKN");

}

void Endgames::add_nn()
{
	add<KNNKC>("KNNKC");
	add<KNNKCC>("KNNKCC");
	add<KNNK>("KNNK");
	add<KNNKN>("KNNKN");
	add<KNNKNN>("KNNKNN");
}
void Endgames::add_r()
{
	add<KRKC>("KRKC");
	add<KRKCC>("KRKCC");
	add<KRKCN>("KRKCN");
	add<KRK>("KRK");
	add<KRKN>("KRKN");
	add<KRKNN>("KRKNN");
	add<KRKR>("KRKR");	
}

void Endgames::add_rc()
{
	add<KRCKCC>("KRCKCC");
	add<KRCKCCN>("KRCKCCN");
	add<KRCKCN>("KRCKCN");
	add<KRCKCNN>("KRCKCNN");
	add<KRCKNN>("KRCKNN");
	add<KRCKR>("KRCKR");
	add<KRCKRC>("KRCKRC");
	add<KRCKRN>("KRCKRN");

}

void Endgames::add_rn()
{
	add<KRNKCC>("KRNKCC");
	add<KRNKCCN>("KRNKCCN");
	add<KRNKCN>("KRNKCN");
	add<KRNKCNN>("KRNKCNN");
	add<KRNKNN>("KRNKNN");
	add<KRNKR>("KRNKR");
	add<KRNKRN>("KRNKRN");
}

void Endgames::add_rr()
{
	add<KRRKCC>("KRRKCC");
	add<KRRKCN>("KRRKCN");
	add<KRRKNN>("KRRKNN");
	add<KRRKR>("KRRKR");
	add<KRRKRC>("KRRKRC");
	add<KRRKRCC>("KRRKRCC");
	add<KRRKRCN>("KRRKRCN");
	add<KRRKRN>("KRRKRN");
	add<KRRKRNN>("KRRKRNN");
	add<KRRKRR>("KRRKRR");
	add<KRRNKRR>("KRRNKRR");

}
