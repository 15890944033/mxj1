/*
  Stockfish, a UCI chess playing engine derived from Glaurung 2.1
  Copyright (C) 2004-2008 Tord Romstad (Glaurung author)
  Copyright (C) 2008-2015 Marco Costalba, Joona Kiiski, Tord Romstad

  Stockfish is free software: you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation, either version 3 of the License, or
  (at your option) any later version.

  Stockfish is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/
#include <iostream>
#include <iomanip>
#include <string>
#include <fstream>
#include <istream>


#include "bitboard.h"
#include "evaluate.h"
#include "position.h"
#include "search.h"
#include "thread.h"
#include "uci.h"
#include "thread.h"
#include "tt.h"

#ifdef INTERNAL_KNIFE_TABLE
#include "knifetable.h"
#endif

#if defined(IS_64BIT) && defined(USE_SSE4) && defined(USE_POPCNT)
#include "cpucheck.h"
#endif
#include "base64.h"


using namespace std;

int main(int argc, char* argv[]) {
	
#if defined(IS_64BIT) && defined(USE_SSE4) && defined(USE_POPCNT)
	if (!CpuCheck::cpu_support_sse42_popcnt()) {
		std::cout << "Your CPU not support sachess 64bit SSE4.2 , now engine will quit!" << std::endl;
		system("pause");
		exit(0);
	}
#endif

//#if (EDITION_MAXTHREADS > 2)
	//boost::filesystem::path selfpath = boost::filesystem::system_complete(argv[0]);
	//std::string curPath = selfpath.remove_filename().string();
//#endif



#ifdef VMPROTECT
	VMProtectBeginUltra("init_main");
	
	int size = VMProtectGetCurrentHWID(NULL, 0); // get the required buffer size
	char *p = new char[size]; // allocate memory for the buffer
	VMProtectGetCurrentHWID(p, size); // obtain the identifier

	std::cout << VMProtectDecryptStringA("your machine id: ") << p << std::endl;
	std::cout << VMProtectDecryptStringA("���Ļ�����: ") << p << std::endl << std::endl;

	//���浽�ı�
	Authbase::save_hid(curPath, p);


	//std::string hid = base64_decode(p);
	//std::cout << hid << std::endl;

	//for (size_t i = 0; i < hid.size(); i += 4) {
	//	uint32_t value = *reinterpret_cast<uint32_t *>(&hid[i]);
	//	uint32_t id = value & ~3;
	//	switch (value & 3) {
	//	case 0:
	//		printf("CPU: %X\n", id);
	//		break;
	//	case 1:
	//		printf("Host: %X\n", id);
	//		break;
	//	case 2:
	//		printf("Ethernet: %X\n", id);
	//		break;
	//	case 3:
	//		printf("HDD: %X\n", id);
	//		break;
	//	}
	//}

	delete[] p; // release memory

	//load key.sachess
	std::string key = Authbase::load_key(curPath);

	int* pState = new int;

	if (key.empty()) {
		*pState = 36084614;

		std::cout << VMProtectDecryptStringA("key file not found!") << std::endl;
		std::cout << VMProtectDecryptStringA("û���ҵ���Կ�ļ���") << std::endl;

	}
	else {
		*pState = VMProtectSetSerialNumber(key.c_str());
	}


	//set license 
	VMProtectEnd();

#endif

  std::cout << engine_info() << std::endl;

  UCI::init(Options, "");
  Bitboards::init();
  BitboardCs::init();	//must earlier that PSQT::init()
  PSQT::init();
  //BitboardCs::print(AreaExtremDangerPawn);
  //Tablebases::init(Options["SyzygyPath"]);

//#if (EDITION_MAXTHREADS > 2 && defined(NDEBUG))
//  Authbase::init(curPath);
//#endif
  
#ifdef VMPROTECT
  VMProtectBeginUltra("init_main2");

  int keySt = *pState;
  if (keySt == 0) {
	  VMProtectSerialNumberData sd = { 0 };
	  bool res = VMProtectGetSerialNumberData(&sd, sizeof(sd));
	  if (res) {
		  VMProtectDate maxBuild = sd.dtMaxBuild;
		  const char* today = __DATE__;
		  struct std::tm local_tm;
		  std::istringstream ss(today);
		  ss >> std::get_time(&local_tm, "%b %d %Y");
		  int year = local_tm.tm_year + 1900;
		  int month = local_tm.tm_mon + 1;
		  int day = local_tm.tm_mday;
		  //std::cout << year << std::endl;
		  //std::cout << month << std::endl;
		  //std::cout << day << std::endl;
		  //std::cout << maxBuild.wYear << std::endl;
		  //std::cout << int(maxBuild.bMonth) << std::endl;
		  //std::cout << int(maxBuild.bDay) << std::endl;

		  if (year < maxBuild.wYear || (year == maxBuild.wYear && month < maxBuild.bMonth) || 
			  (year == maxBuild.wYear && month == maxBuild.bMonth && day <= maxBuild.bDay)) {
			  std::cout << VMProtectDecryptStringA("This engine is licensed to ");
			  locale loc("chs");
			  wcout.imbue(loc);
			  std::wcout << sd.wUserName;
			  std::cout << VMProtectDecryptStringA(" . Thank you.") << std::endl;
		  }
		  else {
			  *pState = 6244218;

			  std::cout << VMProtectDecryptStringA("Your license for this engine is expired, please contact sachess team.") << std::endl;
			  std::cout << VMProtectDecryptStringA("�������������ѹ�������ϵ�ϰ������Ŷӻ�ȡ֧��.") << std::endl;

			  std::this_thread::sleep_for(10s);
			  exit(0);
		  }

	  }
	  else {
		  std::cout << VMProtectDecryptStringA("This engine is licensed. Thank you.") << std::endl;
	  }
  }
  else {
	  //std::cout << "wrong key!" << std::endl;

	  std::cout << VMProtectDecryptStringA("please send hid.sachess.txt file to sachess team to get your key file.") << std::endl;
	  std::cout << VMProtectDecryptStringA("�뽫hid.sachess.txt�ļ����͸��ϰ�����Ĵ����Ի�ü����ļ���") << std::endl << std::endl;

  }

  VMProtectEnd();

#endif
  Position::init();
  Search::init();
  Eval::init();
  TT.resize(Options["Hash"]);
  Threads.init();

#ifdef INTERNAL_KNIFE_TABLE
  KnifeTable::init();
#endif

  

  Search::clear(); // After threads are up

#ifdef VMPROTECT
  VMProtectBeginUltra("init_main3");

  if (!UCI::check_key_status(pState)) {
	  init_knight_bc();
  }

  VMProtectEnd();

#endif

  UCI::loop(argc, argv);

  Threads.exit();

#ifdef VMPROTECT
  delete pState;
#endif

  return 0;
}
