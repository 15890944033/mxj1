#include "endgame.h"

template<EndgameType E/*, typename T = eg_type<E>*/>
template<Color c>
inline void Endgame<E>::rr_r_total(const Position& pos, Score& score) const {
	const Color Them = c == WHITE ? BLACK : WHITE;
	Value v = VALUE_ZERO;

	//�����ڵף��۷�
	if (!pos.is_king_bottom(Them))
		v = BISHOP_END_110P;

	update_score(score, c, v);

	ba_adjust_strong<c>(pos, score);

}

template<>
Value Endgame<KRRKR>::operator()(const Position& pos, Score& score) const {

	strongSide == WHITE ? rr_r_total<WHITE>(pos, score) : rr_r_total<BLACK>(pos, score);

	FUN_IMPL_DIFF_PIECES_ALL(krr_kr)
}

template<EndgameType E/*, typename T = eg_type<E>*/>
template<Color strong> inline Value Endgame<E>::krr_kr_0p_0p(const Position& pos, Score& score) const {
	I_AM_WEAK
	if(pos.full_ba(weak) && pos.pawn_bottomcount<strong>() == 0)  {
		//������˫�������� ���ڵ���
		if (not_z(pos.pieces(weak, BISHOP) & FileEBC) && not_z(pos.pieces(weak, BISHOP) & AreaThreeSevenFile)
			&& (BottomBC & pos.square(weak, KING))) {
			//update_score(pos, score, strong, PawnValueEg);		//��֤˫���Գ�ʿ��ȫ  ���ڳ���ʿ��ȫ
			return value_draw_zoom<6>(pos, score);
		}
			
	}
	return VALUE_NONE;
}

template<EndgameType E/*, typename T = eg_type<E>*/>
template<Color strong> inline Value Endgame<E>::krr_kr_1p_0p(const Position& pos, Score& score) const {
	return VALUE_NONE;
}

template<EndgameType E/*, typename T = eg_type<E>*/>
template<Color strong> inline Value Endgame<E>::krr_kr_2p_0p(const Position& pos, Score& score) const {
	return VALUE_NONE;
}

template<EndgameType E/*, typename T = eg_type<E>*/>
template<Color strong> inline Value Endgame<E>::krr_kr_0p_1p(const Position& pos, Score& score) const {
	return krr_kr_0p_0p<strong>(pos, score);
}

template<EndgameType E/*, typename T = eg_type<E>*/>
template<Color strong> inline Value Endgame<E>::krr_kr_1p_1p(const Position& pos, Score& score) const {
	return VALUE_NONE;
}

template<EndgameType E/*, typename T = eg_type<E>*/>
template<Color strong> inline Value Endgame<E>::krr_kr_2p_1p(const Position& pos, Score& score) const {
	return VALUE_NONE;
}

template<EndgameType E/*, typename T = eg_type<E>*/>
template<Color strong> inline Value Endgame<E>::krr_kr_0p_2p(const Position& pos, Score& score) const {
	I_AM_WEAK

	if (pos.is_pawns_partner_midhigh<weak>()) {
		auto ba = pos.ba_number<weak>();
		if (ba >= BA_DBA && pos.is_king_bottom(weak) && pos.pawn_bottomcount<strong>() == 0)
			return 	update_score_limit(score, -KNIGHT_END_90P);
	}

	return krr_kr_0p_0p<strong>(pos, score);
}

template<EndgameType E/*, typename T = eg_type<E>*/>
template<Color strong> inline Value Endgame<E>::krr_kr_1p_2p(const Position& pos, Score& score) const {
	return VALUE_NONE;
}

template<EndgameType E/*, typename T = eg_type<E>*/>
template<Color strong> inline Value Endgame<E>::krr_kr_2p_2p(const Position& pos, Score& score) const {
	return VALUE_NONE;
}
