#include "endgame.h"

template<EndgameType E/*, typename T = eg_type<E>*/>
template<Color c>
inline void Endgame<E>::rr_rc_total(const Position& pos, Score& score) const {
	Value v = VALUE_ZERO;
	const Color Them = c == WHITE ? BLACK : WHITE;

	//�����ڵף��۷�
	if (!pos.is_king_bottom(Them))
		v = BISHOP_END_110P;

	update_score(score, c, v);

}

template<>
Value Endgame<KRRKRC>::operator()(const Position& pos, Score& score) const {
	if (strongSide == WHITE) {
		if (rkkncn_chain_byrk<BLACK, CANNON>(pos)) {
			//�ڷ��ڱ�ǣ�ƣ��׷��б� or �ڷ���ʿ��ȫ
			if (pos.pawn_nobottomcount<WHITE>() > 0 || !pos.full_ba(BLACK))
				return update_score(pos, score, KNIGHT_END_50P);
		}
	}
	else{
		if (rkkncn_chain_byrk<WHITE, CANNON>(pos)) {
			//�׷��ڱ�ǣ�ƣ��ڷ��б� or �׷���ʿ��ȫ
			if (pos.pawn_nobottomcount<BLACK>() > 0 || !pos.full_ba(WHITE))
				return update_score(pos, score, -KNIGHT_END_50P);
		}
	}

	strongSide == WHITE ? rr_rc_total<WHITE>(pos, score) : rr_rc_total<BLACK>(pos, score);

	FUN_IMPL_DIFF_PIECES_ALL(krr_krc)
}

//˫��ʤ����˫�� ���ͳ���˫ʿ
template<EndgameType E/*, typename T = eg_type<E>*/>
template<Color strong> inline Value Endgame<E>::krr_krc_0p_0p(const Position& pos, Score& score) const {
	I_AM_WEAK

	auto ba = pos.ba_number<weak>();
	switch (ba)
	{
	case BA_ZERO:
	case BA_BS:
	case BA_AD:
	case BA_BA:
	case BA_DB:
		goto almostWin;
	case BA_DA:
	case BA_DBA:
	case BA_BDA:
		//�����غ�˫������Ҫ�ڵ���
		if (pos.is_king_bottom(weak) && pos.pawn_bottomcount<strong>() == 0)
			break;
		goto almostWin;
	default:
		//����ʿ��ȫ��˫����˫��û��ʿ�󣬳��ڷ�����ռ��
		if (pos.zero_ba(strong))
			return update_score(score, strong, -KNIGHT_END_50P);
		else if(pos.is_king_top<weak>() || pos.pawn_bottomcount<strong>() >= 2)
			goto almostWin;
		break;
	}

	return value_draw_zoom<6>(pos, score);

almostWin:
	return VALUE_NONE;

}

template<EndgameType E/*, typename T = eg_type<E>*/>
template<Color strong> inline Value Endgame<E>::krr_krc_1p_0p(const Position& pos, Score& score) const {
	I_AM_WEAK
	if (pos.full_ba(weak) && pos.is_king_bottom(weak) && pos.pawn_bottomcount<strong>() == 0)
		return value_draw_zoom<2>(pos, score);

	return VALUE_NONE;

}

template<EndgameType E/*, typename T = eg_type<E>*/>
template<Color strong> inline Value Endgame<E>::krr_krc_2p_0p(const Position& pos, Score& score) const {
	return VALUE_NONE;
}

template<EndgameType E/*, typename T = eg_type<E>*/>
template<Color strong> inline Value Endgame<E>::krr_krc_0p_1p(const Position& pos, Score& score) const {
	I_AM_WEAK
	//���ڱ�ʿ��ȫ��˫��2��ʿ���ڷ��й��ӱ�������
	if (pos.full_ba(weak)) {
		if (pos.defense_count(strong) <= 2 && pos.pawn_validcount<weak>() > 0) {
			Value v = -KNIGHT_END_50P;
			return update_score(score, strong, v);
		}

	}
	return krr_krc_0p_0p<strong>(pos, score);
}

template<EndgameType E/*, typename T = eg_type<E>*/>
template<Color strong> inline Value Endgame<E>::krr_krc_1p_1p(const Position& pos, Score& score) const {
	I_AM_WEAK
		
	if (pos.full_ba(weak) && pos.is_king_bottom(weak) && pos.pawn_bottomcount<strong>() == 0 && is_advantage<strong>(score))
		return krr_krc_1p_0p<strong>(pos, score);

	return VALUE_NONE;
}

template<EndgameType E/*, typename T = eg_type<E>*/>
template<Color strong> inline Value Endgame<E>::krr_krc_2p_1p(const Position& pos, Score& score) const {
	return VALUE_NONE;
}

template<EndgameType E/*, typename T = eg_type<E>*/>
template<Color strong> inline Value Endgame<E>::krr_krc_0p_2p(const Position& pos, Score& score) const {
	//˫�������һ��ʿ���� �� ���ڷ���˫ʿ����������2������ ˫�����۷�
	I_AM_WEAK

	if (!pos.is_pawns_partner_midhigh<weak>())
		return krr_krc_0p_1p<strong>(pos, score);

	return VALUE_NONE;

}

template<EndgameType E/*, typename T = eg_type<E>*/>
template<Color strong> inline Value Endgame<E>::krr_krc_1p_2p(const Position& pos, Score& score) const {
	return VALUE_NONE;
}

template<EndgameType E/*, typename T = eg_type<E>*/>
template<Color strong> inline Value Endgame<E>::krr_krc_2p_2p(const Position& pos, Score& score) const {
	return VALUE_NONE;
}

