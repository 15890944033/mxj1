#include "endgame.h"


//��2�����Ϲ��ӱ���������ӷǵ��ߵ�����Ҳ�û�б����۷�
//�����2��ʿ��û�����ʿ���۷�
//�κ�һ������������һ���������ڷ���λ�ã��۷�
//һ������Ŀ����һ�����ڵ���2�����ӷ�
template<EndgameType E/*, typename T = eg_type<E>*/>
inline void Endgame<E>::nn_nn_total(const Position& pos, Score& score) const {
	adjust_pawn_behind_king<WHITE>(pos, score, 0.3);
	adjust_pawn_behind_king<BLACK>(pos, score, 0.3);


	Value v = VALUE_ZERO;
	int adWhite = pos.count(WHITE, ADVISOR);
	int adBlack = pos.count(BLACK, ADVISOR);

	int duitou = pawns_headtohead(pos);
	int nbpWhite = pos.pawn_nobottomcount<WHITE>() - duitou;
	int nbpBlack = pos.pawn_nobottomcount<BLACK>() - duitou;

	int vpWhite = pos.pawn_validcount<WHITE>();
	int vpBlack = pos.pawn_validcount<BLACK>();

	int dcWhite = pos.defense_count(WHITE);
	int dcBlack = pos.defense_count(BLACK);
	int dcdiff = dcBlack - dcWhite;


	if (vpWhite >= 2
		&& (equal_z(pos.pieces_pawn_crnb<WHITE>() & FlankBoardBC[LEFT]) || equal_z(pos.pieces_pawn_crnb<WHITE>() & FlankBoardBC[RIGHT]))) {
		v += -PAWN_END_10P;
	}
	if (vpBlack >= 2
		&& (equal_z(pos.pieces_pawn_crnb<BLACK>() & FlankBoardBC[LEFT]) || equal_z(pos.pieces_pawn_crnb<BLACK>() & FlankBoardBC[RIGHT]))) {
		v += PAWN_END_10P;
	}

	if (adWhite == 2 && !pos.is_advisor_cavel(WHITE)) {
		v += -BISHOP_END_10P;
	}
	if (adBlack == 2 && !pos.is_advisor_cavel(BLACK)) {
		v += BISHOP_END_10P;
	}

	//�����ʿ��ֵ���
	if (dcdiff > 0 && (((nbpWhite + duitou) > 0 && (nbpBlack + duitou) == 0) ||
		(vpWhite > 0 && vpBlack == 0 && nbpWhite > nbpBlack))) {
		v += dcdiff * BISHOP_END_40P;
	}
	else if (dcdiff < 0 && (((nbpWhite + duitou) == 0 && (nbpBlack + duitou) > 0) ||
		(vpBlack > 0 && vpWhite == 0 && nbpWhite < nbpBlack))) {
		v += dcdiff * BISHOP_END_40P;
	}

	//�����ƶ��Գͷ���
	BitboardC notAttacked[2];
	notAttacked[WHITE] = ~(pos.pawn_attacks<BLACK>() | pos.bishop_attacks<BLACK>()
		| pos.advisor_attacks<BLACK>() | pos.attacks_from<KING>(pos.square(BLACK, KING)));
	notAttacked[BLACK] = ~(pos.pawn_attacks<WHITE>() | pos.bishop_attacks<WHITE>()
		| pos.advisor_attacks<WHITE>() | pos.attacks_from<KING>(pos.square(WHITE, KING)));

	v += value_knight_mob<WHITE, false>(pos, notAttacked[WHITE]);
	v -= value_knight_mob<BLACK, false>(pos, notAttacked[BLACK]);

	if (nbpWhite >= nbpBlack && vpWhite > vpBlack) {
		v += (vpWhite - vpBlack) * PAWN_END_10P;
	}
	else if (nbpWhite > 0 && nbpBlack == 0) {
		v += nbpWhite * PAWN_END_10P;
	}
	else if (nbpWhite <= nbpBlack && vpWhite < vpBlack) {
		v += (vpWhite - vpBlack) * PAWN_END_10P;
	}
	else if (nbpBlack > 0 && nbpWhite == 0) {
		v += -nbpBlack * PAWN_END_10P;
	}

	update_score(score, v);


	v = VALUE_ZERO;
	if (greater_than<WHITE>(score, VALUE_ADV_LOWLIMIT)) {
		if (nbpWhite > nbpBlack && !is_kn_defense<BLACK>(pos)) {
			v += BISHOP_END_20P;
		}


	}
	else if (greater_than<BLACK>(score, VALUE_ADV_LOWLIMIT)) {
		if (nbpWhite < nbpBlack && !is_kn_defense<WHITE>(pos)) {
			v += -BISHOP_END_20P;
		}

	}
	update_score(score, v);



}

template<>
Value Endgame<KNNKNN>::operator()(const Position& pos, Score& score) const {
	strongSide == WHITE ? nn_nn_total(pos, score) : nn_nn_total(pos, score);

	FUN_IMPL_SAME_PIECES_ALL(knn_knn)
}

template<EndgameType E/*, typename T = eg_type<E>*/>
template<Color strong> inline Value Endgame<E>::knn_knn_0p_0p(const Position& pos, Score& score) const {
	return value_draw_zoom<8>(pos, score);
}

template<EndgameType E/*, typename T = eg_type<E>*/>
template<Color strong> inline Value Endgame<E>::knn_knn_1p_0p(const Position& pos, Score& score) const {
	I_AM_WEAK
		auto ba = pos.ba_number<weak>();
	switch (ba) {
	case BA_ZERO:
	case BA_BS:
	case BA_AD:
	case BA_BA:
	case BA_DB:
	case BA_DA:
	case BA_DBA:
	case BA_BDA:
		break;
	default:
		return value_draw_zoom<2>(pos, score);
	}

	return 	VALUE_NONE;
}

template<EndgameType E/*, typename T = eg_type<E>*/>
template<Color strong> inline Value Endgame<E>::knn_knn_1p_1p(const Position& pos, Score& score) const {
	//I_AM_WEAK
	//	if (pos.full_ba(strong) && pos.full_ba(weak)) {
	//		return value_draw_zoom<1>(score);
	//	}
	return VALUE_NONE;
}

template<EndgameType E/*, typename T = eg_type<E>*/>
template<Color strong> inline Value Endgame<E>::knn_knn_2p_0p(const Position& pos, Score& score) const {
	return 	VALUE_NONE;
}

template<EndgameType E/*, typename T = eg_type<E>*/>
template<Color strong> inline Value Endgame<E>::knn_knn_2p_1p(const Position& pos, Score& score) const {
	return 	VALUE_NONE;

}

template<EndgameType E/*, typename T = eg_type<E>*/>
template<Color strong> inline Value Endgame<E>::knn_knn_2p_2p(const Position& pos, Score& score) const {
	return 	VALUE_NONE;
}
