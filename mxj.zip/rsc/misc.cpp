﻿/*
  Stockfish, a UCI chess playing engine derived from Glaurung 2.1
  Copyright (C) 2004-2008 Tord Romstad (Glaurung author)
  Copyright (C) 2008-2015 Marco Costalba, Joona Kiiski, Tord Romstad

  Stockfish is free software: you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation, either version 3 of the License, or
  (at your option) any later version.

  Stockfish is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#ifdef _WIN32
#if _WIN32_WINNT < 0x0601
#undef  _WIN32_WINNT
#define _WIN32_WINNT 0x0601 // Force to include needed API prototypes
#endif
#define NOMINMAX		//avoid std::max and std::min compile error
#include <windows.h> 
// The needed Windows API for processor groups could be missed from old Windows
// versions, so instead of calling them directly (forcing the linker to resolve
// the calls at compile time), try to load them at runtime. To do this we need
// first to define the corresponding function pointers.
extern "C" {
	typedef bool(*fun1_t)(LOGICAL_PROCESSOR_RELATIONSHIP,
		PSYSTEM_LOGICAL_PROCESSOR_INFORMATION_EX, PDWORD);
	typedef bool(*fun2_t)(USHORT, PGROUP_AFFINITY);
	typedef bool(*fun3_t)(HANDLE, CONST GROUP_AFFINITY*, PGROUP_AFFINITY);
}
#else
#include <string.h> 　　//strrchr(), strncpy()
#include <stdlib.h>   　  //realloc()
#include <unistd.h>       //readlink()
#endif

#include <fstream>
#include <iomanip>
#include <iostream>
#include <sstream>
#include <vector>

#include "misc.h"
#include "thread.h"
#include "util_vmp.h"


using namespace std;
const string Version = "";

//显示cpu型号
//const string cpu_getbrand()
//{
//	int buf[4];
//	char brand[48];
//	string s = "<Unknown CPU>";
//
//	// Function 0x80000000: Largest Extended Function Number
//	brand[47] = '\0';
//	__cpuid(buf, 0x80000000);
//
//	if (buf[0] >= 0x80000004)
//	{
//		// Function 80000002h,80000003h,80000004h: Processor Brand String
//		__cpuid((int *)&brand[0], 0x80000002);
//		__cpuid((int *)&brand[16], 0x80000003);
//		__cpuid((int *)&brand[32], 0x80000004);
//		s = brand;
//		s.erase(0, s.find_first_not_of(" "));
//		s.erase(s.find_last_not_of(" ") + 1);
//	}
//	return s;
//}
//
//const string memory_getsize()
//{
//	char size[48];
//	MEMORYSTATUSEX statex;
//
//	statex.dwLength = sizeof(MEMORYSTATUSEX);
//	GlobalMemoryStatusEx(&statex);
//	sprintf(size, "%Iu", statex.ullTotalPhys / 1024);
//
//	return string(size) + "K OK";
//}

namespace {

/// Version number. If Version is left empty, then compile date in the format
/// DD-MM-YY and show in engine_info.

/// Our fancy logging facility. The trick here is to replace cin.rdbuf() and
/// cout.rdbuf() with two Tie objects that tie cin and cout to a file stream. We
/// can toggle the logging of std::cout and std:cin at runtime whilst preserving
/// usual I/O functionality, all without changing a single line of code!
/// Idea from http://groups.google.com/group/comp.lang.c++/msg/1d941c0f26ea0d81

struct Tie: public streambuf { // MSVC requires split streambuf for cin and cout

  Tie(streambuf* b, streambuf* l) : buf(b), logBuf(l) {}

  int sync() { return logBuf->pubsync(), buf->pubsync(); }
  int overflow(int c) { return log(buf->sputc((char)c), "<< "); }
  int underflow() { return buf->sgetc(); }
  int uflow() { return log(buf->sbumpc(), ">> "); }

  streambuf *buf, *logBuf;

  int log(int c, const char* prefix) {

    static int last = '\n'; // Single log file

    if (last == '\n')
        logBuf->sputn(prefix, 3);

    return last = logBuf->sputc((char)c);
  }
};

class Logger {

  Logger() : in(cin.rdbuf(), file.rdbuf()), out(cout.rdbuf(), file.rdbuf()) {}
 ~Logger() { start(""); }

  ofstream file;
  Tie in, out;

public:
  static void start(const std::string& fname) {

    static Logger l;

	if (!fname.empty() && !l.file.is_open()){
        l.file.open(fname, ifstream::out);
        cin.rdbuf(&l.in);
        cout.rdbuf(&l.out);
    }
    else if (fname.empty() && l.file.is_open()){
        cout.rdbuf(l.out.buf);
        cin.rdbuf(l.in.buf);
        l.file.close();
    }
  }
};

} // namespace

/// engine_info() returns the full name of the current Stockfish version. This
/// will be either "Stockfish <Tag> DD-MM-YY" (where DD-MM-YY is the date when
/// the program was compiled) or "Stockfish <Version>", depending on whether
/// Version is empty.

const string engine_info(bool to_uci) {

  const string months("Jan Feb Mar Apr May Jun Jul Aug Sep Oct Nov Dec");
  string month, day, year;
  stringstream ss, date(__DATE__); // From compiler, format is "Sep 21 2008"

#ifdef VMPROTECT
  VMProtectBeginUltra("enginfo");

  ss << VMProtectDecryptStringA("SA Chess ") << VMProtectDecryptStringA("1.9");
#if EDITION_MAXTHREADS == 2
  ss << VMProtectDecryptStringA(" Dual Cores Edition ") << setfill('0');
#elif EDITION_MAXTHREADS == 4
  ss << VMProtectDecryptStringA(" Quad Cores Edition ") << setfill('0');

#elif EDITION_MAXTHREADS == 6
  ss << VMProtectDecryptStringA(" Six Cores Edition ") << setfill('0');

#elif EDITION_MAXTHREADS == 8
  ss << VMProtectDecryptStringA(" Octg Cores Edition ") << setfill('0');

#elif EDITION_MAXTHREADS == 12
  ss << VMProtectDecryptStringA(" 12 Cores Edition ") << setfill('0');

#elif EDITION_MAXTHREADS == 16
  ss << VMProtectDecryptStringA(" Hexa Cores Edition ") << setfill('0');

#elif EDITION_MAXTHREADS == 24
  ss << VMProtectDecryptStringA(" 24 Cores Edition ") << setfill('0');

#elif EDITION_MAXTHREADS == 32
  ss << VMProtectDecryptStringA(" 32 Cores Edition ") << setfill('0');

#elif EDITION_MAXTHREADS == 48
  ss << VMProtectDecryptStringA(" 48 Cores Edition ") << setfill('0');

#elif EDITION_MAXTHREADS == 64
  ss << VMProtectDecryptStringA(" 64 Cores Edition ") << setfill('0');

#elif EDITION_MAXTHREADS == 128
  ss << VMProtectDecryptStringA(" 128 Cores Edition ") << setfill('0');

#elif EDITION_MAXTHREADS == 256
  ss << VMProtectDecryptStringA(" 256 Cores Edition ") << setfill('0');

#else
  ss << VMProtectDecryptStringA(" Single Cores Edition ") << setfill('0');

#endif 
  //if (Version.empty()){
  date >> month >> day >> year;
  ss << VMProtectDecryptStringA("Build date:") << setw(2) << day << setw(2) << (1 + months.find(month) / 4) << year.substr(2);
  //}

  ss << (Is64Bit ? " 64 bit" : " 32 bit")
	  //<< (HasPext ? " BMI2" : (HasPopCnt ? " POPCNT" : ""))
	  << (HasSSE4 ? VMProtectDecryptStringA(" SSE4.2 ") : "")
	  << (HasPopCnt ? VMProtectDecryptStringA("POPCNT") : "")
	  << (to_uci ? VMProtectDecryptStringA("\nid author ") : VMProtectDecryptStringA(" by "))
	  //<< "T. Romstad, M. Costalba, J. Kiiski, G. Linscott";
	  << VMProtectDecryptStringA("Kyle Wu www.sachess.com ");

  VMProtectEnd();

#else


  ss << Version << setfill('0'); //日期数据缺位用0填充。
  if (Version.empty())
  {
	  date >> month >> day >> year;
  }



  if (to_uci)
  {

	  ss << "National Chess " << setw(2) << year << "/" << setw(2) << (1 + months.find(month) / 4) << "/" << setw(2) << day << (Is64Bit ? " win64" : " ")
		  << ((HasPopCnt ? " POPCNT" : "")) << " \n";
	  ss << "id author " << " Ma XiaoJian（QQ:2237556025）\n";
	  //ss << "id copyright " << "2018-2019 SanYuanXiangQi Team\n";  // "\n"为换行符，有此符本行结束，进入下一行。



  }

  else
  {
	  ss << "National Chess " << setw(2) << year << "/" << setw(2) << (1 + months.find(month) / 4) << "/" << setw(2) << day << (Is64Bit ? " win64" : "")
		  << ((HasPopCnt ? " POPCNT" : ""))
		  << " by " << "Ma XiaoJian \n"
		  << "init ok" ;
	 // ss << "CPU Brand : " << cpu_getbrand() << "\n";
	 // ss << "Total RAM : " << memory_getsize();
	 
  }


#endif




  return ss.str();
}


/// Debug functions used mainly to collect run-time statistics
static int64_t hits[2], means[2];

void dbg_hit_on(bool b) { ++hits[0]; if (b) ++hits[1]; }
void dbg_hit_on(bool c, bool b) { if (c) dbg_hit_on(b); }
void dbg_mean_of(int v) { ++means[0]; means[1] += v; }

void dbg_print() {

  if (hits[0])
      cerr << "Total " << hits[0] << " Hits " << hits[1]
           << " hit rate (%) " << 100 * hits[1] / hits[0] << endl;

  if (means[0])
      cerr << "Total " << means[0] << " Mean "
           << (double)means[1] / means[0] << endl;
}

#if defined(_CHESS_IO_WITH_STRING)
const int32_t   LINE_INPUT_MAX_CHAR = 16384;
static char     szInputBuffer[LINE_INPUT_MAX_CHAR];
static int32_t  nInputReadEnd = 0;
static char     szOutputBuffer[LINE_INPUT_MAX_CHAR];
static int32_t  nOutputReadEnd = 0;

const int32_t   c_MaxBufCnt = 128;
static char     InputBuff[c_MaxBufCnt][LINE_INPUT_MAX_CHAR];
static int32_t  InputWritePtr = 0, InputReadPtr = 0;
static char     OutputBuff[c_MaxBufCnt][LINE_INPUT_MAX_CHAR];
static int32_t  OutputWritePtr = 0, OutputReadPtr = 0;

static std::stringstream output_ss;
static CoutRedirection cout_redir(output_ss);

/* */
static bool CheckInput(void)
{
    if (InputReadPtr != InputWritePtr)
    {
        return true;
    }
    else
    {
        return false;
    }
}

/* */
static void ReadInputCore(void)
{
    strcpy(szInputBuffer, InputBuff[InputReadPtr]);
    InputReadPtr = (InputReadPtr + 1) % c_MaxBufCnt;
    nInputReadEnd = strlen(szInputBuffer);
}

/* */
void WriteInput(char *txt)
{
    strcpy(InputBuff[InputWritePtr], txt);
    InputWritePtr = (InputWritePtr + 1) % c_MaxBufCnt;
}

/* */
static bool GetInputBuffer(char *szLineStr)
{
    char    *lpFeedEnd;
    int     nFeedEnd;
    lpFeedEnd = (char *)memchr(szInputBuffer, '\n', nInputReadEnd);
    if (lpFeedEnd == NULL)
    {
        return false;
    }
    else
    {
        nFeedEnd = lpFeedEnd - szInputBuffer;
        memcpy(szLineStr, szInputBuffer, nFeedEnd);
        szLineStr[nFeedEnd] = '\0';
        nFeedEnd++;
        nInputReadEnd -= nFeedEnd;
        memcpy(szInputBuffer, szInputBuffer + nFeedEnd, nInputReadEnd);
        lpFeedEnd = (char *)strchr(szLineStr, '\r');
        if (lpFeedEnd != NULL)
        {
            *lpFeedEnd = '\0';
        }

        return true;
    }
}

/* */
static char *ReadInput(void)
{
    static char szLineStr[LINE_INPUT_MAX_CHAR];
    if (GetInputBuffer(szLineStr))
    {
        return szLineStr;
    }
    else if (CheckInput())
    {
        ReadInputCore();
        if (GetInputBuffer(szLineStr))
        {
            return szLineStr;
        }
        else if (nInputReadEnd == LINE_INPUT_MAX_CHAR)
        {
            memcpy(szLineStr, szInputBuffer, LINE_INPUT_MAX_CHAR - 1);
            szLineStr[LINE_INPUT_MAX_CHAR - 1] = '\0';
            szInputBuffer[0] = szInputBuffer[LINE_INPUT_MAX_CHAR - 1];
            nInputReadEnd = 1;
            return szLineStr;
        }
        else
        {
            return NULL;
        }
    }
    else
    {
        return NULL;
    }
}

/* */
static bool CheckOutput(void)
{
    if (OutputReadPtr != OutputWritePtr)
    {
        return true;
    }
    else
    {
        return false;
    }
}

/* */
static void ReadOutputCore(void)
{
    strcpy(szOutputBuffer, OutputBuff[OutputReadPtr]);
    OutputReadPtr = (OutputReadPtr + 1) % c_MaxBufCnt;
    nOutputReadEnd = strlen(szOutputBuffer);
}

/* */
static void WriteOutput(const char *txt)
{
    strcpy(OutputBuff[OutputWritePtr], txt);
    OutputWritePtr = (OutputWritePtr + 1) % c_MaxBufCnt;
}

/* */
static bool GetOutputBuffer(char *szLineStr)
{
    char    *lpFeedEnd;
    int     nFeedEnd;
    lpFeedEnd = (char *)memchr(szOutputBuffer, '\n', nOutputReadEnd);
    if (lpFeedEnd == NULL)
    {
        return false;
    }
    else
    {
        nFeedEnd = lpFeedEnd - szOutputBuffer;
        memcpy(szLineStr, szOutputBuffer, nFeedEnd);
        szLineStr[nFeedEnd] = '\0';
        nFeedEnd++;
        nOutputReadEnd -= nFeedEnd;
        memcpy(szOutputBuffer, szOutputBuffer + nFeedEnd, nOutputReadEnd);
        lpFeedEnd = (char *)strchr(szLineStr, '\r');
        if (lpFeedEnd != NULL)
        {
            *lpFeedEnd = '\0';
        }

        return true;
    }
}

/* */
char *ReadOutput(void)
{
    static char szLineStr[LINE_INPUT_MAX_CHAR];
    if (GetOutputBuffer(szLineStr))
    {
        return szLineStr;
    }
    else if (CheckOutput())
    {
        ReadOutputCore();
        if (GetOutputBuffer(szLineStr))
        {
            return szLineStr;
        }
        else if (nOutputReadEnd == LINE_INPUT_MAX_CHAR)
        {
            memcpy(szLineStr, szOutputBuffer, LINE_INPUT_MAX_CHAR - 1);
            szLineStr[LINE_INPUT_MAX_CHAR - 1] = '\0';
            szOutputBuffer[0] = szOutputBuffer[LINE_INPUT_MAX_CHAR - 1];
            nOutputReadEnd = 1;
            return szLineStr;
        }
        else
        {
            return NULL;
        }
    }
    else
    {
        return NULL;
    }
}

bool get_input(std::string &cmd)
{
    char *s;
    while ((s = ReadInput()) == NULL)
    {
        std::this_thread::sleep_for(std::chrono::milliseconds(10));
    }

    cmd = s;
    return true;
}

#else
bool get_input(std::string &cmd)
{
    if (getline(cin, cmd))
    {
        return true;
    }
    else
    {
        return false;
    }
}

#endif

/// Used to serialize access to std::cout to avoid multiple threads writing at
/// the same time.

std::ostream& operator<<(std::ostream& os, SyncCout sc) {

  static Mutex m;

  if (sc == IO_LOCK)
  {
      m.lock();
  }

  if (sc == IO_UNLOCK)
  {
#if defined(_CHESS_IO_WITH_STRING)
      auto line = output_ss.str();
      output_ss.str("");
      WriteOutput(line.c_str());
#endif
      m.unlock();
  }

  return os;
}


/// Trampoline helper to avoid moving Logger to misc.h
void start_logger(const std::string& fname) { Logger::start(fname); }

#if !defined(_WIN32)
//通过链接文件名获取被目标文件绝对路径
//为了防止buffer不够大，包装一下readlink()
char* getFilePathByLink(const char *filename)
{
    int size = 100;
    char *buffer = NULL;

    while (1)
    {
        buffer = (char *)realloc(buffer, size);
        //readlink()返回的路径名并没有以'\0'结尾
        int nchars = readlink(filename, buffer, size - 1);
        if (nchars < 0)
        {
            free(buffer);
            return NULL;
        }
        if (nchars <= size - 1) {
            buffer[nchars] = '\0';        //让路径名以'\0'结尾
            return buffer;
        }
        size *= 2;    //buffer空间不足，扩大为2倍
    }
}
#else
//----------------------------------------------------------------------- 
std::string UTF8_To_string(const std::string & str)
{
    int nwLen = MultiByteToWideChar(CP_UTF8, 0, str.c_str(), -1, NULL, 0);

    wchar_t * pwBuf = new wchar_t[nwLen + 1];//一定要加1，不然会出现尾巴 
    memset(pwBuf, 0, nwLen * 2 + 2);

    MultiByteToWideChar(CP_UTF8, 0, str.c_str(),(int) str.length(), pwBuf, nwLen);

    int nLen = WideCharToMultiByte(CP_ACP, 0, pwBuf, -1, NULL, NULL, NULL, NULL);

    char * pBuf = new char[nLen + 1];
    memset(pBuf, 0, nLen + 1);

    WideCharToMultiByte(CP_ACP, 0, pwBuf, nwLen, pBuf, nLen, NULL, NULL);

    std::string retStr = pBuf;

    delete[]pBuf;
    delete[]pwBuf;

    pBuf = NULL;
    pwBuf = NULL;

    return retStr;
}
////////////////////////////////////////////////////////////////////////// 


////////////////////////////////////////////////////////////////////////// 
//  [8/19/2009 Leezhm] 
//  translate ascii characters to utf-8 characters
//------------------------------------------------------------------------ 
std::string string_To_UTF8(const std::string & str)
{
    int nwLen = ::MultiByteToWideChar(CP_ACP, 0, str.c_str(), -1, NULL, 0);

    wchar_t * pwBuf = new wchar_t[nwLen + 1];//一定要加1，不然会出现尾巴 
    ZeroMemory(pwBuf, nwLen * 2 + 2);

    ::MultiByteToWideChar(CP_ACP, 0, str.c_str(), (int)str.length(), pwBuf, nwLen);

    int nLen = ::WideCharToMultiByte(CP_UTF8, 0, pwBuf, -1, NULL, NULL, NULL, NULL);

    char * pBuf = new char[nLen + 1];
    ZeroMemory(pBuf, nLen + 1);

    ::WideCharToMultiByte(CP_UTF8, 0, pwBuf, nwLen, pBuf, nLen, NULL, NULL);

    std::string retStr(pBuf);

    delete[]pwBuf;
    delete[]pBuf;

    pwBuf = NULL;
    pBuf = NULL;

    return retStr;
}

#endif

std::string get_exe_path()
{
#if defined(_WIN32)
    TCHAR file[MAX_PATH];
    GetModuleFileName(NULL, file, MAX_PATH);
    std::string path = file;
    size_t split = path.find_last_of('\\');
    return string_To_UTF8(path.substr(0, split + 1));
#else
    char* pathbuf = NULL;
    pathbuf = getFilePathByLink("/proc/self/exe");
    if (NULL == pathbuf) {
        printf("getFilePathByLink() Failed!\n");
        return(NULL);
    }

    char* last_slash = NULL;
    //找到最后一个'/',last_slash保存其地址
    last_slash = strrchr(pathbuf, '/');
    //如果是空，则未找到'/'
    if (last_slash == NULL) {
        printf("can not find '/'!\n");
        return(NULL);
    }

    int dir_len = 0;
    char* dir = NULL;
    dir_len = last_slash - pathbuf + 1;        //包括末尾的'/'
    dir = (char*)malloc(dir_len + 1);

    strncpy(dir, pathbuf, dir_len);
    dir[dir_len] = '\0';

    return dir;
#endif
}


/// prefetch() preloads the given address in L1/L2 cache. This is a non-blocking
/// function that doesn't stall the CPU waiting for data to be loaded from memory,
/// which can be quite slow.
#ifdef NO_PREFETCH

void prefetch(void*) {}

#else

void prefetch(void* addr) {

#  if defined(__INTEL_COMPILER)
   // This hack prevents prefetches from being optimized away by
   // Intel compiler. Both MSVC and gcc seem not be affected by this.
   __asm__ ("");
#  endif

#  if defined(__INTEL_COMPILER) || defined(_MSC_VER)
  _mm_prefetch((char*)addr, _MM_HINT_T0);		//CPUID Flags: SSE
#  else
  __builtin_prefetch(addr);
#  endif
}

#endif

namespace WinProcGroup {

#ifndef _WIN32

	void bindThisThread(size_t) {}

#else

	/// get_group() retrieves logical processor information using Windows specific
	/// API and returns the best group id for the thread with index idx. Original
	/// code from Texel by Peter Österlund.

	int get_group(size_t idx) {

		int threads = 0;
		int nodes = 0;
		int cores = 0;
		DWORD returnLength = 0;
		DWORD byteOffset = 0;

		// Early exit if the needed API is not available at runtime
		HMODULE k32 = GetModuleHandleA("Kernel32.dll");
		auto fun1 = (fun1_t)GetProcAddress(k32, "GetLogicalProcessorInformationEx");
		if (!fun1)
			return -1;

		// First call to get returnLength. We expect it to fail due to null buffer
		if (fun1(RelationAll, nullptr, &returnLength))
			return -1;

		// Once we know returnLength, allocate the buffer
		SYSTEM_LOGICAL_PROCESSOR_INFORMATION_EX *buffer, *ptr;
		ptr = buffer = (SYSTEM_LOGICAL_PROCESSOR_INFORMATION_EX*)malloc(returnLength);

		// Second call, now we expect to succeed
		if (!fun1(RelationAll, buffer, &returnLength))
		{
			free(buffer);
			return -1;
		}

		while (ptr->Size > 0 && byteOffset + ptr->Size <= returnLength)
		{
			if (ptr->Relationship == RelationNumaNode)
				nodes++;

			else if (ptr->Relationship == RelationProcessorCore)
			{
				cores++;
				threads += (ptr->Processor.Flags == LTP_PC_SMT) ? 2 : 1;
			}

			byteOffset += ptr->Size;
			ptr = (SYSTEM_LOGICAL_PROCESSOR_INFORMATION_EX*)(((char*)ptr) + ptr->Size);
		}

		free(buffer);

		std::vector<int> groups;

		// Run as many threads as possible on the same node until core limit is
		// reached, then move on filling the next node.
		for (int n = 0; n < nodes; n++)
			for (int i = 0; i < cores / nodes; i++)
				groups.push_back(n);

		// In case a core has more than one logical processor (we assume 2) and we
		// have still threads to allocate, then spread them evenly across available
		// nodes.
		for (int t = 0; t < threads - cores; t++)
			groups.push_back(t % nodes);

		// If we still have more threads than the total number of logical processors
		// then return -1 and let the OS to decide what to do.
		return idx < groups.size() ? groups[idx] : -1;
	}


	/// bindThisThread() set the group affinity of the current thread

	void bindThisThread(size_t idx) {

		// If OS already scheduled us on a different group than 0 then don't overwrite
		// the choice, eventually we are one of many one-threaded processes running on
		// some Windows NUMA hardware, for instance in fishtest. To make it simple,
		// just check if running threads are below a threshold, in this case all this
		// NUMA machinery is not needed.
		if (Threads.size() < 8)
			return;
		
		// Use only local variables to be thread-safe
		int group = get_group(idx);

		if (group == -1)
			return;

		// Early exit if the needed API are not available at runtime
		HMODULE k32 = GetModuleHandleA("Kernel32.dll");
		auto fun2 = (fun2_t)GetProcAddress(k32, "GetNumaNodeProcessorMaskEx");
		auto fun3 = (fun3_t)GetProcAddress(k32, "SetThreadGroupAffinity");
		
		if (!fun2 || !fun3)
			return;
		GROUP_AFFINITY affinity;
		if (fun2(group, &affinity))
			fun3(GetCurrentThread(), &affinity, nullptr);
	}

#endif

} // namespace WinProcGroup