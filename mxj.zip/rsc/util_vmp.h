#ifndef UTIL_VMP_H_INCLUDED
#define UTIL_VMP_H_INCLUDED


//#define  VMPROTECT

#if defined(VMPROTECT)



#include <string>
#include <fstream>
#include <iostream>
#include <istream>

#include <boost/algorithm/string.hpp>
#include <boost/lexical_cast.hpp>

#include "../../tools/vmprotect_demo/VMProtectSDK.h"


#ifdef _WIN64
#pragma comment(lib, "VMProtectSDK64.lib")
#else
#pragma comment(lib, "VMProtectSDK32.lib")
#endif

using namespace std;

namespace Utilvmp {

	//inline void marker_begin_lock(const std::string& markerName) {
	//	VMProtectBeginUltraLockByKey(markerName.c_str());
	//}

	inline bool is_protected() {
		return VMProtectIsProtected();
	}

	inline bool found_debugger() {
		return VMProtectIsDebuggerPresent(true);
	}

	inline bool found_vm() {
		return VMProtectIsVirtualMachinePresent();
	}

	inline bool check_crc() {
		return VMProtectIsValidImageCRC();
	}

	//const char* p = VMProtectDecryptStringA("abc");
	//VMProtectFreeString(p);

}

#endif
#endif
