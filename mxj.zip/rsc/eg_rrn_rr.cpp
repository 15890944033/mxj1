#include "endgame.h"

template<EndgameType E/*, typename T = eg_type<E>*/>
template<Color c>
inline void Endgame<E>::rrn_rr_total(const Position& pos, Score& score) const {
	const Color Them = c == WHITE ? BLACK : WHITE;

	//˫����û�б���˫��˫ʿ��һ������ʤ���۷�
	int pcStrong = pos.count(c, PAWN);
	if (pcStrong == 0) {
		int adStrong = pos.count(c, ADVISOR);
		int adWeak = pos.count(Them, ADVISOR);
		if (adStrong == 2 && adWeak == 2 && pos.count(Them, BISHOP) > 0) {
			Value v = -KNIGHT_END_80P;
			update_score(score, c,  v);
		}
	}



}

template<>
Value Endgame<KRRNKRR>::operator()(const Position& pos, Score& score) const {
	strongSide == WHITE ? rrn_rr_total<WHITE>(pos, score) : rrn_rr_total<BLACK>(pos, score);

	FUN_IMPL_DIFF_PIECES_ALL(krrn_krr)
}

//˫��ʤ����˫�� ���ͳ���˫ʿ
template<EndgameType E/*, typename T = eg_type<E>*/>
template<Color strong> inline Value Endgame<E>::krrn_krr_0p_0p(const Position& pos, Score& score) const {

	return VALUE_NONE;
}

template<EndgameType E/*, typename T = eg_type<E>*/>
template<Color strong> inline Value Endgame<E>::krrn_krr_1p_0p(const Position& pos, Score& score) const {

	return VALUE_NONE;
}

template<EndgameType E/*, typename T = eg_type<E>*/>
template<Color strong> inline Value Endgame<E>::krrn_krr_2p_0p(const Position& pos, Score& score) const {
	return VALUE_NONE;
}

template<EndgameType E/*, typename T = eg_type<E>*/>
template<Color strong> inline Value Endgame<E>::krrn_krr_0p_1p(const Position& pos, Score& score) const {
	return VALUE_NONE;
}

template<EndgameType E/*, typename T = eg_type<E>*/>
template<Color strong> inline Value Endgame<E>::krrn_krr_1p_1p(const Position& pos, Score& score) const {
	return VALUE_NONE;
}

template<EndgameType E/*, typename T = eg_type<E>*/>
template<Color strong> inline Value Endgame<E>::krrn_krr_2p_1p(const Position& pos, Score& score) const {
	return VALUE_NONE;
}

template<EndgameType E/*, typename T = eg_type<E>*/>
template<Color strong> inline Value Endgame<E>::krrn_krr_0p_2p(const Position& pos, Score& score) const {
	return VALUE_NONE;
}

template<EndgameType E/*, typename T = eg_type<E>*/>
template<Color strong> inline Value Endgame<E>::krrn_krr_1p_2p(const Position& pos, Score& score) const {
	return VALUE_NONE;
}

template<EndgameType E/*, typename T = eg_type<E>*/>
template<Color strong> inline Value Endgame<E>::krrn_krr_2p_2p(const Position& pos, Score& score) const {
	return VALUE_NONE;
}
